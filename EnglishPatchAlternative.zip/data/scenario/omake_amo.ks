﻿[_tb_system_call storage=system/_omake_amo.ks]

[load_memory name="name" cond="!f.name"]

[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[tb_start_tyrano_code]
[position layer="message0" frame="Message4.png"  height="258"  ]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Amoamo
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="amo1.webp"  wait="false"  ]
[wait  time="2000"  ]
[playbgm  volume="50"  time="3000"  loop="true"  storage="5_theater.ogg"  fadein="true"  ]
[flash_off  time="2000"  effect="fadeOut"  ]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Amoamo
Mmyu! They're pajamas,[r]but Amoamo's style made them gothic lolita fashion![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Amoamo
Luci-Luci used to be an Angel-chan,[r]so frilly outfits suit you~[p]
[_tb_end_text]

[bg  time="50"  method="crossfade"  storage="amo2.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Hadester
Yes, of course.[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="amo3.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Amoamo
But from your voice and your looks,[r]I guess Luci-Luci really is a boy after all~[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="amo4.webp"  wait="false"  ]
[playse  volume="100"  time="1000"  buf="4"  storage="hirameki.ogg"  ]
[tb_start_text mode=1 ]
#Amoamo
... Oh, that's right![p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="amo5.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah-Desta...[p]
[_tb_end_text]

[flash  time="0"  effect="fadeIn"  color="0xFFFFFF"  ]

[stopbgm  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="amo6.webp"  wait="false"  ]
[wait  time="100"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[playse  volume="100"  time="1000"  buf="4"  storage="gimon.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=50]Oh my![resetfont][p]
[_tb_end_text]

[playbgm  volume="50"  time="0"  loop="true"  storage="8_gag.ogg"  fadein="false"  ]
[playse  volume="100"  time=""  buf="5"  storage="amo.ogg"  loop="true"  fadein="false"  ]
[bg  time="100"  method="crossfade"  storage="amo7.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Hadester
Asmodeus, that tickles.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Amoamo
Mmyu~![r]No matter how much I grope,[r]it's totally flat down there~!?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Hadester
It's because I have no earthly desires.[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="1"  storage="sasu2.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=50]W-what... what are you doing!?[resetfont][p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="amo8.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Amoamo
Kupy-chan! What's going on down there~!?[r]Luci-Luci's got no androgynous cannon~!?[r][font size=25]They've got a hole in back, though~[resetfont][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Cupyah... angels throw away selfish wants[r]and go genderless.[r]Only then do they finally rank up.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Amoamo
You can't even eat or do naughty things~!?[r]Heaven's standards are so strict...[r]But if you've fallen, why is it still like that!?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Even after falling, you keep your angelic form[r]and wish for others' happiness.[r]Your heart must not have fallen, Desta.[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="amo9.webp"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="gimon.ogg"  ]
[stopbgm  time="1000"  fadeout="true"  ]
[stopse  time="500"  buf="5"  fadeout="true"  ]
[tb_start_text mode=1 ]
#Amoamo
Mmyu? So that means...[p]
[_tb_end_text]

[tb_hide_message_window  ]
[flash  time="1000"  effect="fadeIn"  color="0xFFFFFF"  ]

[bg  time="100"  method="crossfade"  storage="amo10.webp"  wait="false"  ]
[camera  time="10"  zoom="1.1"  wait="true"  layer="layer_camera"  ease_type="ease"  ]
[playse  volume="100"  time="1000"  buf="5"  storage="amo.ogg"  loop="true"  fadein="true"  ]
[playbgm  volume="30"  time="0"  loop="false"  storage="Honny_Trap.ogg"  ]
[reset_camera  time="20000"  wait="false"  layer="layer_camera"  ease_type="ease"  ]
[flash_off  time="500"  effect="fadeOut"  ]

[wait  time="1000"  ]
[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Amoamo
So all I have to do is awaken your desires~?[r]Luci-Luci, let's do something naughty together~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Desta, please run![p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Hadester
I'm not running. If you want to do something lewd,[r]go ahead. I won't give in to lust.[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="1"  storage="sasu.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
What is with you!?[r]Where does that mysterious confidence come from!?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Amoamo
Mmyu~♥ You'll be so much fun to defile~♥[r]Then, I'll dig in~...[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="1"  storage="sasu2.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=50]Please don't start some weird party![resetfont][p]
[_tb_end_text]

[tb_start_tyrano_code]
[position layer="message0" frame="Message.png"  height="258"  ]
[_tb_end_tyrano_code]

[tb_hide_message_window  ]
[stopbgm  time="1000"  fadeout="true"  ]
[stopse  time="1000"  buf="5"  fadeout="true"  ]
[open_omake  category="gallery"  name="amo"  ]
[jump  storage="collection_omake.ks"  target="*resume_to_ng"  ]
