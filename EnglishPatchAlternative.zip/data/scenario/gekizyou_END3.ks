﻿[_tb_system_call storage=system/_gekizyou_END3.ks]

[cm  ]
[bg_loop name="gekizyo2"]

[chara_show  name="劇場でび"  time="0"  wait="false"  storage="chara/15/dagya5.png"  width="564"  height="595"  left="355"  top="143"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[stopse  time="300"  buf="1"  fadeout="true"  ]
[call  storage="maku.ks"  target="*open_gekizyou"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="5_theater.ogg"  ]
[fadein_window  time="1000"  ]
[jump  storage="gekizyou_END3.ks"  target="*mitakotoaru"  cond="sf.omakes.length>0"  ]
[tb_start_text mode=1 ]
#Devilun
Ahem. Since this is your first time, I'll explain it to ya.[wait time=300][r]This is the post-ending bonus corner![p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Watch it or don't, your call.[wait time=300][r]Well, clear everything and maybe something good happens.[p]
[_tb_end_text]

*mitakotoaru

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.omakes.length > 0]Hey, you[delay speed=300]...[resetdelay][resetdelay][else]Anyway[delay speed=300]...[resetdelay][endif][p]

[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya4.png"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="劇場でび"  time="30"  cross="false"  storage="chara/15/dagya4.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=34]Why do you keep pawing at my horn[r]over and over and over? You pervert--![resetfont][p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
To you guys, this horn probably looks[r]like nothing but decoration.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
It's a vital organ for soaking up mana![r]For a demon, that's a sensitive spot![p]




[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya5.png"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
Normally I wouldn't[r]freak out this much from just being touched...[p]It's all 'cause of this tiny body...[r]I wanna have my old Demon Realm body back.[p]






[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya7.png"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
[font size=34]Get back out there and grab some mana,[r]you punk--![resetfont][p]






[_tb_end_text]

[jump  storage="gekizyou_END_menu.ks"  target=""  ]
