﻿[_tb_system_call storage=system/_kupya.ks]

[jump  storage="kupya.ks"  target="*talk"  ]
*modoru_hint

[eval exp="f.hintIdx++"]

[jump  target="modoru"  storage=""  ]
*modoru_oha

[eval exp="f.ohaIdx++"]

[jump  target="modoru"  storage=""  ]
*modoru

[tb_start_tyrano_code]
[if exp="f.kupya_owari >= 11"]
[_tb_end_tyrano_code]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/9.png"  ]
[tb_start_tyrano_code]
[else]
[_tb_end_tyrano_code]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_tyrano_code]
[endif]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#Kupyadel
[if exp="f.kupya_owari >= 11"]Spipyaa~......[else]Is there anything else?[endif][wait time=300]
[_tb_end_text]

*modoru_tap

*talk

[eval exp="f.hintIdx=0" cond="isNaN(f.hintIdx)"]

[eval exp="f.ohaIdx=0" cond="isNaN(f.ohaIdx)"]

[guard_click]

[glink  storage="kupya.ks"  x="400"  y="145"  width="66"  height="127"  target="*mimiate"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="808"  y="145"  width="66"  height="127"  target="*mimiate"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="529"  y="3"  width="217"  height="89"  target="*wa"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="472"  y="93"  width="330"  height="130"  target="*atama"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="359"  y="247"  width="152"  height="185"  target="*mimi"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="762"  y="247"  width="152"  height="185"  target="*mimi"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="594"  y="320"  width="84"  height="68"  target="*beru"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="578"  y="381"  width="126"  height="112"  target="*onaka"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="477"  y="380"  width="81"  height="137"  target="*hane"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="721"  y="380"  width="81"  height="137"  target="*hane"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[if exp="f.currentLoop>=2"]

[choice2 text1="Talk" target1="*oha" text2="Ask&nbsp;for&nbsp;advice" target2="*zyo" y="500"]

[else]

[choice2 text1="Talk" target1="*oha" text2="???" disabled2="true" graphic2="disabled" y="500"]

[endif]

[glink  name="waku,waku3"  font_color="white"  target="*kaeru"  x="520"  y="680"  width="240"  height="57"  graphic="ui/kupya1.png"  enterimg="ui/kupya2.png"  enterse="tap.ogg"  clickse="OK.ogg"  exp="dc.afterChoice2(false)"  ]
[s  ]
*hane

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
An angel's wings are so warm and nice,[r]just touching them makes you happy, right?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah!? Um...[r]There's nothing weird in them,[r]don't worry![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*mimi

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
These are my pride and joy--my fluffy, squishy banana ears![r]They're emergency rations to share with hungry kids~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
That was a lie~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*atama

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyahh~♥[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I just looove having my head patted, you know~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But please don't touch my bangs too much, okay?[r]I set them carefully every morning~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*wa

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
This halo is a precious gift from the Great Archangel[r]and means so much to me~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Lesser angels like me[r]can't get mana without it.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*mimiate

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
This?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/5.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
These are earmuffs![r]They're quite fashionable among angels, you know~[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
Do they... suit me?
[_tb_end_text]

[choice2 text1="Nod" target1="*1" text2="..." target2="*2" y="500"]

[s  ]
*1

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
Pyaa~♥ [emb exp="f.name"]-san, you have a good eye~
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*2

[tb_start_text mode=1 ]
#Kupyadel
In your heart, you're saying they suit me, aren't you?[r][if exp="f.currentLoop == 1]I may look like this, but I can use Evil Eye Scan, you know![else]My True Eye sees right through everything, you know![endif][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*beru

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="Bell.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Ring-a-ling~♪[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/5.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I gave you one of these, too, [emb exp="f.name"]-san[r]They're called lily-of-the-valley bells~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Ring it, and I'll come running whenever you need me,[r]so please don't hesitate to use it![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*onaka

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah!?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
The eye in my belly is really delicate,[r]so be gentle with it![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
... Don't go punching Devi-kun in the stomach, okay?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*oha

[call  storage="kupya_1.ks"  target="*oha"  cond="f.day==1"  ]
[call  storage="kupya_2.ks"  target="*oha"  cond="f.day==2"  ]
[call  storage="kupya_3.ks"  target="*oha"  cond="f.day==3"  ]
[jump  storage="kupya.ks"  target="*modoru_oha"  ]
*zyo

[iscript]
const hintAvailable = dc.hintAvailable(f, sf.endings)
if (hintAvailable.length == 0) {
f.hint = '_empty'
} else {
if (!hintAvailable[f.hintIdx]) {
f.hintIdx = 0
f.hintLooped = 1
}
f.hint = hintAvailable[f.hintIdx]
}
[endscript]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
A hint? Let's see...[if exp="f.hintLooped==1"][r]As I said before,[endif][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="&'END'+f.hint"  ]
*END_empty

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[jump  storage="kupya.ks"  target="*30_END"  cond="dc.endCount()>=dc.totalEndings()"  ]
[tb_start_text mode=1 ]
#Kupyadel
For now, I can't see any clear hints in particular.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But I can see them faintly,[r]so please try checking another date.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*30_END

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'm sorry, but I can't see anything[r]that even looks like a hint anymore...[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END1

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
How about you try [font color=0xEC6FC5 bold=true]not signing a contract[resetfont] with Devi-kun[r]and see what happens? Hee hee.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
You know Devi-kun's [font color=0xEC6FC5 bold=true]true name[resetfont], don't you?[r]Why not try [font color=0xEC6FC5 bold=true]calling that name again some other time[resetfont]?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END3

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devi-kun has a weak spot, you know♥Did you know that?[p]
How about [font color=0xEC6FC5 bold=true]rubbing it again and again[resetfont] for him?[r]Hee hee.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END4

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Being diligent is all well and good, but every now and then,[r]it's fine to [font color=0xEC6FC5 bold=true]give him a little neglect-play[resetfont], you know?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
You're probably mentally worn out, too, so in the meantime,[r][emb exp="f.name"]-san, please get some rest.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Just don't get desperate and drink[r][font color=0xEC6FC5 bold=true]wine[resetfont] like that teacher,[r]then snore yourself to sleep.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END5

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah... I want a [font color=0xEC6FC5 bold=true]Devi-kun plushie[resetfont], too~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END6

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.seibetu == 1]Why not use magic to become a [font color=0xEC6FC5 bold=true]girl[resetfont] for a change?[r]You might see things from a whole new perspective.[else]Hmm... Embrace love![endif][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=40][if exp="f.seibetu == 1]Embrace love~[else]Everyone has their own way of loving~[endif][resetfont][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=25]And... it might be rather fun to try matching with me... Hee hee.[resetfont][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END7

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
You don't have to lay a hand on him...[r]but [font color=0xEC6FC5 bold=true]try threatening him[resetfont]--you might discover something![p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END8

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Even while time is stopped, [font color=0xEC6FC5 bold=true]keep fighting back[resetfont]![r]Cupyah, cupyah! Fight![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Sometimes you need the strength[r]not to do what everyone else wants...[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END9

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Why not deliberately [font color=0xEC6FC5 bold=true]leave your mana below 100%[resetfont]?[r]I'm sure you'll get to see Devi-kun's angry face.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END10

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'll be blunt.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font color=0xEC6FC5 bold=true]Please cooperate with me[resetfont]♥[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END11

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Even in a false world created by someone else...[r]if you can be happy without realizing it,[r]I find myself thinking that might be enough.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/9.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
So if that's the path you want...[r]then you may [font color=0xEC6FC5 bold=true]choose not to cooperate with me[resetfont] after all.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END12

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Angels, demons, spirits--we make bodies out of mana.[r]If we're hurt, enough mana [font color=0xEC6FC5 bold=true]patches us up[resetfont],[r]but...[p]

[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I wonder what happens to Devi-kun[r]if he doesn't have [font color=0xEC6FC5 bold=true]enough mana[resetfont] at a time like this.[r]Hee hee... I'm curious![p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END13

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Try pulling [font color=0xEC6FC5 bold=true]that thing of Devi-kun's out for him[resetfont], please.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=40]It's a HORN![wait time=300]H[wait time=300]--ORN![resetfont][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END14

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
... When things get hard,[r]you're welcome to lean on me, you know.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
At times like that, [emb exp="f.name"]-san, I'll[r]wrap you up in my fluffy, squishy pride and joy![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
... But [font color=0xEC6FC5 bold=true]don't touch me too much[resetfont]--that's a no-no~[p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END15

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
That reminds me, I've heard that [font color=0xEC6FC5 bold=true]garlic[resetfont][r]is effective against demons... Have you ever tried it?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END16

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I wonder what would happen[r]if you didn't collect even [font color=0xEC6FC5 bold=true]1% of your mana[resetfont]? Cupyah![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END17

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Do you know what Devi-kun likes? According to my research,[r]he seems to like fluffy little ones with big, round eyes~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
He can't [font color=0xEC6FC5 bold=true]leave someone like that alone when they're[r]in trouble[resetfont] ...[r]he's such a kind soul~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Apparently, sexy older women aren't his type~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END18

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.neodebi_nade == 1]Seeing Neo-Devilun's reaction reminded me...[r]When I patted Devi-kun's head in the past,[r]he looked terribly annoyed.[else]Long ago, when I patted Devi-kun's head, he said,[r]"Don't treat me like a child!"[r]... and made it clear he didn't like it.[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
That's when I learned headpats[r]aren't always a good thing.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
So let's get creative.[r]He might like it better[r]if you [font color=0xEC6FC5 bold=true]touched somewhere other than his head[resetfont]![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
He might even snap, "There won't be a next time!" though...[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END19

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'd love to pile lots of toppings onto Devi-kun's horns[r]and [font color=0xEC6FC5 bold=true]have a proper taste[resetfont], wouldn't you?[p]

[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah...? I'm giving perfectly serious advice![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END20

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
When taking on something with a high danger rating,[r]it's better to keep some mana in reserve, but...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Why not try going in with [font color=0xEC6FC5 bold=true]no mana at all[resetfont] for a change?[r]You might gain a whole new perspective.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END21

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devi-kun's [font color=0xEC6FC5 bold=true]Evil Eye is beautiful[resetfont], isn't it...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But they say eyes are being sold[r]in Magirisia's black market... or so I've heard~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Eek, that's scary~[p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END22

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I think Devi-kun should interact with [font color=0xEC6FC5 bold=true]tiny bats[resetfont] more often~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END23

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If that [font color=0xEC6FC5 bold=true]wriggling tentacle[r]demon[resetfont] attacked me, I'd be utterly helpless![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Cupyah... I just remembered something from long ago...[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END24

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font color=0xEC6FC5 bold=true]Training[resetfont] and discipline are important, but...[r]it's important to relax and [font color=0xEC6FC5 bold=true]act silly[resetfont], too~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Ah, but don't taunt people, okay?[r]Especially [font color=0xEC6FC5 bold=true]crouch-spamming[resetfont]![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END25

[chara_show  name="クピャドエル"  time="1000"  wait="true"  storage="chara/14/11.png"  width="1280"  height="960"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If we use Devi-kun's Evil Eye[r]and [emb exp="f.name"]-san's Magic Eye together and [font color=0xEC6FC5 bold=true]cooperate[resetfont],[r]the path should open by itself![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*END33"  cond="sf.endings.includes('33')"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah...? And my True Eye can see another possibility,[r]too... but it doesn't look like a very good one~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
... Still, I'll go ahead and say this.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Don't do anything rash just because the path isn't opening.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
If something takes advantage of a half-hearted heart...[r]... I should stop there.[p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END33

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
... Just because you can start over,[r]please don't do anything cruel to Devi-kun.[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
Um...
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END26

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Would Devi-kun be happy if he lived[r]in the [font color=0xEC6FC5 bold=true]Fountain of Souls[resetfont], where the Spirit Gods reside?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END28

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/12.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
......[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I'm sorry, but [if exp="f.BBB_kidoku == 1"]the sight of Devi-kun being eaten[r][else]the sight of Devi-kun in his wedding clothes,[r]looking so sad,[r][endif]is burned vividly into my mind and won't leave me,[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Back then, if I had stopped Devi-kun[r]without calling his [font color=0xEC6FC5 bold=true]true name[resetfont]...[r]would things have turned out better?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[emb exp="f.name"]-san, you can try again.[r]So I can still... hold on to hope.[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
Cupyah... I mustn't let my smile fade.
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END27

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
... If I [font color=0xEC6FC5 bold=true]failed to stop Devi-kun[resetfont],[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
No, I shouldn't let myself think so negatively.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END29

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Would Devi-kun be happy if he could [font color=0xEC6FC5 bold=true]get married[resetfont][r]and experience love, I wonder...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
You know what they say--look the part first...[r]I believe marriage is an important ritual in that respect~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END30

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/8.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.wedding_kidoku == 1"]Or, [else]Back then, [endif]if someone had reached out a hand and said[r][font color=0xEC6FC5 bold=true]"Let's be friends"[resetfont]...[r]would things have turned out differently?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*ENDundefined

[tb_start_text mode=1 ]
#Kupyadel
I'll think about it for a little while,[r]so please ask me again later.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*complete

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Just where could Devi-kun possibly be saved?[r]When he becomes NEO Devilun? Or when we start over?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Honestly... Devi-kun really is such a handful, isn't he?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*kaeru

[eval exp="f.hintIdx=0"]

[eval exp="f.ohaIdx=0"]

[eval exp="f.hintLooped=0"]

[tb_eval  exp="f.kupya_tap=0"  name="kupya_tap"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.kupya_owari=0"  name="kupya_owari"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If you ever need anything,[r]just call for me, Kupyadel, the Angel of Love.[p]
[if exp="f.kupya_inori == 1][delay speed=100]... [resetdelay]Cupyah~[r]I'll be taking my leave now.[else]Cupyah~[delay speed=100]...[resetdelay][r]May eternal happiness be yours.[delay speed=100]...[resetdelay][endif][p]

[_tb_end_text]

[stopbgm  time="1000"  fadeout="true"  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya_modoru.ogg"  ]
[flash  time="1000"  effect="fadeIn"  color="0xFFFFFF"  ]

[chara_hide_all  time="0"  wait="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[tb_filter_grayscale  layer="0"  ]
[wait  time="800"  ]
[free_bg_layermode name="ring" time="0"]

[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[playse  volume="100"  time="0"  buf="1"  storage="doa2.ogg"  ]
[free_bg_layermode name="ring" time="1000"]

[wait  time="500"  ]
[tb_hide_message_window  ]
[jump  storage="kupya.ks"  target="*day3"  cond="f.day==3"  ]
[jump  storage="syoukan.ks"  target="*back_from_kupya"  ]
*day3

[jump  storage="syoukan_k.ks"  target="*back_from_kupya"  ]
