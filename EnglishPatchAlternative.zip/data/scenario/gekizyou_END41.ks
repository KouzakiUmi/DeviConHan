﻿[_tb_system_call storage=system/_gekizyou_END41.ks]

[cm  ]
[bg_loop name="gekizyo2"]

[chara_show  name="劇場でび"  time="0"  wait="false"  storage="chara/15/dagya53.png"  width="523"  height="551"  left="598"  top="164"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_show  name="ちび悪魔"  time="0"  wait="false"  storage="chara/72/14.png"  width="487"  height="475"  left="203"  top="221"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-10"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="3000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[stopse  time="300"  buf="1"  fadeout="true"  ]
[wait  time="500"  ]
[call  storage="maku.ks"  target="*open_gekizyou"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="5_theater.ogg"  ]
[fadein_window  time="1000"  ]
[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/15.png"  ]
[tb_start_text mode=1 ]
#Maneko
What IS this house?![r]I was sure it'd be some rich person's mansion...![p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya54.png"  ]
[tb_start_text mode=1 ]
#Devilun
Yo, Mammon, this place ain't got anything[r]but scraps of paper.[r]Go on, leave your mana and get out, get out.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/16.png"  ]
[tb_start_text mode=1 ]
#Maneko
Belphegor...[r]The whole Demon Realm is buzzing about you.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
You're a demon of Sloth,[r]so I figured you'd have gone over to some rich[r]contractor and spent your days lazing around...[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
How can you be THIS poor?![r]I can't even believe it![p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya41.png"  ]
[tb_start_text mode=1 ]
#Devilun
Mammon... money isn't everything in this world, y'know?[p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/15.png"  ]
[tb_start_text mode=1 ]
#Maneko
Grrr! Don't you talk down to me![r]That's the LAST thing I ever want to hear![p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-10"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="3000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/14.png"  ]
[tb_start_text mode=1 ]
#Maneko
... Y-you...[r]I heard you recently awakened an Evil God ability.[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya40.png"  ]
[tb_start_text mode=1 ]
#Devilun
That's right![r]If I wanted to,[r]I could grow roots that drain all the mana around me.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/16.png"  ]
[tb_start_text mode=1 ]
#Maneko
I-I can't believe a low-rank like you[r]had a power like that![p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya29.png"  ]
[tb_start_text mode=1 ]
#Devilun
Hope a new power sprouts in you too, besides[r]that copycat routine, lol.[p]

[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/15.png"  ]
[tb_start_text mode=1 ]
#Maneko
Nyaaah![r]I want to steal every last bit[r]of your luck AND your talent![p]

[_tb_end_text]

[jump  storage="gekizyou_END_menu.ks"  target=""  ]
