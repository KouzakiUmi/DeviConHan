﻿[_tb_system_call storage=system/_omake_BBB.ks]

[flash  time="0"  effect="fadeIn"  color="0xFFFFFF"  ]

[tb_start_text mode=1 ]
#Beelzebub
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="NISU1.webp"  wait="false"  ]
[playbgm  volume="50"  time="0"  loop="true"  storage="5_theater.ogg"  fadein="false"  ]
[playse  volume="100"  time="0"  buf="5"  loop="true"  storage="BBB7.ogg"  ]
[flash_off  time="2000"  effect="fadeOut"  ]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Beelzebub
That extra-garlic ramen really was delicious.[r]Bel's shocked face was quite something, too.[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="NISU2.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Beelzebub
Garlic[delay speed=100]...[resetdelay] Surely that won't smell, right?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
[delay speed=100]... [resetdelay]Let's go through the back door so no one spots us.[p]
[_tb_end_text]

[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[wait  time="100"  ]
[bg  time="0"  method="crossfade"  storage="NISU3.webp"  wait="true"  ]
[wait  time="100"  ]
[flash_off  time="0"  effect="fadeOut"  ]

[playse  volume="100"  time="0"  buf="4"  storage="pon2.ogg"  ]
[playse  volume="100"  time="0"  buf="5"  loop="true"  storage="BBB7_.ogg"  ]
[tb_start_text mode=1 ]
#Beelzebub
And the moment I said that, I got caught in his web.[p]
[_tb_end_text]

[wait  time="100"  ]
[flash  time="0"  effect="fadeIn"  color="0xFFFFFF"  ]

[stopbgm  time="0"  ]
[stopse  time="0"  buf="5"  ]
[playse  volume="100"  time="0"  buf="4"  storage="gimon.ogg"  ]
[flash_off  time="0"  effect="fadeOut"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
[delay speed=80]Lord Bub[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[flash  time="300"  effect="fadeIn"  color="0x000000"  ]

[bg  time="0"  method="crossfade"  storage="NISU4.webp"  wait="false"  ]
[camera  time="10"  zoom="1.1"  wait="false"  ]
[wait  time="500"  ]
[reset_camera  time="5000"  wait="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="NISU2.ogg"  ]
[playse  volume="100"  time="0"  buf="5"  storage="NISU3.ogg"  loop="true"  ]
[flash_off  time="2000"  effect="fadeOut"  ]

[wait  time="500"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Beelzebub
...[wait time=300]...[wait time=300]...[wait time=300] Nisrok[wait time=300][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
Welcome back,[wait time=300] and,[wait time=300][p]

[_tb_end_text]

[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[reset_camera  time="10"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="NISU5.webp"  wait="false"  ]
[wait  time="100"  ]
[flash_off  time="0"  effect="fadeOut"  ]

[playse  volume="100"  time="0"  buf="4"  storage="amo3.ogg"  loop="false"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
[font size=50]Excuse me.[resetfont][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
[font size=80]Guh![resetfont][p]


[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="NISU6.webp"  wait="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="NISU1.ogg"  loop="true"  ]
[tb_start_text mode=1 ]
#Nisrok
[delay speed=80]...[r]Ahh, eating that cheap Human Realm slop again.[r]Making a mess on the surface as always.[resetdelay][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
[delay speed=80]I told you time and again not to eat[r]anything but what I make, didn't I?[resetdelay][p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
Cough, hack[delay speed=100]...[resetdelay][r]Nisrok[delay speed=100]... [resetdelay]but still[delay speed=100]...[resetdelay][p]


[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="NISU7.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
[delay speed=80]... Good grief[resetdelay][p]


[_tb_end_text]

[stopse  time="1000"  buf="3"  fadeout="true"  ]
[stopse  time="1000"  buf="5"  fadeout="true"  ]
[flash  time="1000"  effect="fadeIn"  color="0xFFFFFF"  ]

[wait  time="500"  ]
[bg  time="100"  method="crossfade"  storage="NISU8.webp"  wait="false"  ]
[playse  volume="100"  time="1000"  buf="5"  storage="mori.ogg"  loop="true"  fadein="true"  ]
[flash_off  time="1000"  effect="fadeOut"  ]

[tb_start_text mode=1 ]
#Nisrok
I have had quite enough of hearing about[r]the wonders of junk food. Go and reflect on it.[p]

[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="NISU8_.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Beelzebub
[delay speed=80][font size=25]Ramen is... a nutritionally complete food...[resetfont][resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="NISU9.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
(Did he... share a meal with someone?)[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
(The pig feed masked it, but that faint berry scent...[r]Could that be the lesser demon Lord Bub mentioned--[r]the Great Demon candidate?)[p]
[_tb_end_text]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[bg  time="300"  method="crossfade"  storage="NISU10.webp"  wait="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="marusu.ogg"  ]
[tb_start_text mode=1 ]
#Nisrok
([delay speed=100]... tsk[resetdelay] Why won't you choose me for a Great Demon seat?[r]You made me fall. You built this paradise for me.)[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="NISU11.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
([delay speed=100]... [resetdelay]The fallen angels have disappeared[r]from this paradise lately.)[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
(They say that Lucifer has fallen,[r]and is planning to start a rebellion in the Demon Realm.)[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
(Could Lord Bub be afraid of that?[r]Is that why he treats us fallen angels like caged birds...[r]All of it because...[delay speed=100]... [resetdelay])[p]
[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="1000"  wait="false"  ]

[tb_start_text mode=1 ]
#Nisrok
(And yet, to think that I, of all people,[r]am less worthy of Lord Bub's trust[r]than some upstart lesser demon...[delay speed=100]... [resetdelay])[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
([delay speed=80]I hate it[delay speed=100]... [resetdelay]I hate it, hate it, hate it[resetdelay])[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="NISU12.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
([delay speed=300]... [resetdelay]That's it.)[p]
[_tb_end_text]

[free layer=4 name="kuro" time="100"  ]

[playse  volume="100"  time="0"  buf="4"  storage="hirameki.ogg"  ]
[tb_start_text mode=1 ]
#Nisrok
[delay speed=100]... [resetdelay]Um, Lord Bub.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
That Belphegor candidate you mentioned before[delay speed=100]...[resetdelay][r]Do let me meet them someday.[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="4"  storage="kawaii.ogg"  ]
[bg  time="100"  method="crossfade"  storage="NISU13.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Beelzebub
Oh! Nisrok![r]If that is your wish, I shall certainly bring them here[r]once it is officially settled.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
I want fallen angels and demons alike to get along.[r]Yes, yes![r]I truly hope this will be the first step toward that.[p]
[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="kuro.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
I shall look forward to it[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[stopse  time="1000"  buf="5"  fadeout="true"  ]
[open_omake  category="gallery"  name="NISU"  ]
[jump  storage="collection_omake.ks"  target="*resume_to_ng"  ]
