﻿TYRANO.kag.dc = {
  ...TYRANO.kag.dc,
  _ends: function () {
    const { f } = TYRANO.kag.stat,
      { sf } = TYRANO.kag.variable
    return {
      1: {
        category: 'normal',
        title: 'Speedrunner&nbsp;of&nbsp;Defeat',
        phrase: 'Are&nbsp;you&nbsp;doing&nbsp;a<br>speedrun&nbsp;of&nbsp;losing?<br>Are&nbsp;you&nbsp;stupid<br>or&nbsp;what?',
        timing: 'Devilun&nbsp;summoning&nbsp;scene',
        cond: 'Don\'t&nbsp;make&nbsp;a&nbsp;contract&nbsp;with&nbsp;Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 1,
      },
      2: {
        category: 'normal',
        title: 'Name&nbsp;of&nbsp;the&nbsp;Demon&nbsp;of&nbsp;Sloth',
        phrase: 'We&nbsp;just&nbsp;met,<br>what&nbsp;the&nbsp;heck<br>are&nbsp;you?!',
        timing: 'Devilun&nbsp;summoning&nbsp;scene',
        cond: 'When&nbsp;introducing&nbsp;yourself&nbsp;as&nbsp;a&nbsp;Summoner,&nbsp;say&nbsp;Devilun\'s&nbsp;true&nbsp;name.',
        hintCond: f =>
          f.currentLoop >= 1 &&
          f.day >= 0 &&
          (f.bel_name >= 1 || f.bel_name_first >= 1),
        bgType: 2,
      },
      3: {
        category: 'normal',
        title: 'Sensitive&nbsp;horns...♥',
        phrase: 'You&nbsp;knocked&nbsp;me&nbsp;out!<br>Don\'t&nbsp;touch&nbsp;my&nbsp;horns<br>again!',
        timing: 'Character&nbsp;selection&nbsp;scene',
        cond: 'Keep&nbsp;poking&nbsp;Devilun\'s&nbsp;horns',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 3,
      },
      4: {
        category: 'normal',
        title: 'Good&nbsp;Night&nbsp;Devilun',
        phrase: `Let's&nbsp;just&nbsp;call&nbsp;it<br>a&nbsp;night,<br>${f.name}.`,
        timing: 'Character&nbsp;selection&nbsp;scene',
        cond: 'Leave&nbsp;Devilun&nbsp;alone&nbsp;for&nbsp;a&nbsp;while',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 1,
      },
      5: {
        category: 'normal',
        title: 'Alice\'s&nbsp;plushie',
        phrase: 'Hand&nbsp;me&nbsp;over&nbsp;as-is?<br>As&nbsp;if!&nbsp;You&nbsp;idiot!!',
        timing: 'Day&nbsp;0:&nbsp;Alice',
        cond: 'Give&nbsp;Alice&nbsp;the&nbsp;plushie-fied&nbsp;Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 3,
      },
      6: {
        category: 'normal',
        title: 'Oops...&nbsp;I&nbsp;messed&nbsp;up.',
        phrase: 'Sorry&nbsp;for<br>interrupting.<br>...Enjoy&nbsp;yourself.',
        timing: 'Day&nbsp;0:&nbsp;Almaz',
        cond: 'Connect&nbsp;with&nbsp;Almaz&nbsp;while&nbsp;in&nbsp;female&nbsp;form.',
        hintCond: f => f.currentLoop >= 2 && f.day >= 0,
        bgType: 1,
      },
      7: {
        category: 'normal',
        title: 'Desperate&nbsp;Thunder',
        phrase: '*cough*...<br>That&nbsp;tingling&nbsp;sensation...<br>What&nbsp;on&nbsp;earth&nbsp;just&nbsp;happened...!?',
        timing: 'Day&nbsp;0:&nbsp;Rai',
        cond: 'Threaten&nbsp;Rai&nbsp;with&nbsp;a&nbsp;knife',
        hintCond: f => f.currentLoop >= 2 && f.day >= 0,
        bgType: 2,
      },
      8: {
        category: 'normal',
        title: 'Russian&nbsp;Joke',
        phrase: 'Dagya...?<br>W-What&nbsp;happened?',
        timing: 'Day&nbsp;0:&nbsp;Lapis',
        cond: 'Disobey&nbsp;Lapis',
        hintCond: f => f.currentLoop >= 3 && f.day >= 0,
        bgType: 1,
      },
      9: {
        category: 'normal',
        title: 'Mana&nbsp;deficiency...',
        phrase: 'If&nbsp;you&nbsp;can\'t&nbsp;even<br>gather&nbsp;this&nbsp;much,<br>you\'re&nbsp;disqualified<br>as&nbsp;a&nbsp;familiar.',
        timing: 'MP&nbsp;check',
        cond: 'Mana&nbsp;has&nbsp;not&nbsp;reached&nbsp;100%&nbsp;after&nbsp;finishing&nbsp;connections&nbsp;for&nbsp;3&nbsp;characters.',
        hintCond: f => f.currentLoop >= 1 && f.day >= 1,
        bgType: 1,
      },
      10: {
        category: 'normal',
        title: 'Angel&nbsp;Punching&nbsp;Bag',
        phrase: 'What&nbsp;a&nbsp;terrible<br>hobby&nbsp;you\'ve&nbsp;got!',
        timing: 'Day&nbsp;0:&nbsp;Bedroom',
        cond: 'Kupyadel&nbsp;catches&nbsp;Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 1,
        bgType: 3,
      },
      11: {
        category: 'normal',
        title: 'Artificial&nbsp;happiness',
        phrase: 'Don\'t&nbsp;brainwash&nbsp;me!<br>This&nbsp;is&nbsp;fake<br>happiness!',
        timing: 'Day&nbsp;0:&nbsp;Bedroom',
        cond: 'Refuse&nbsp;to&nbsp;cooperate&nbsp;when&nbsp;Kupyadel&nbsp;suggests&nbsp;working&nbsp;together.',
        hintCond: f => f.bel_name || f.bel_name_first,
        bgType: 2,
      },
      12: {
        category: 'normal',
        title: 'Irreparable',
        phrase: 'No&nbsp;mana...<br>Dagya...',
        timing: 'Day&nbsp;1:&nbsp;Fuuga',
        cond: 'Not&nbsp;enough&nbsp;MP&nbsp;to&nbsp;repair&nbsp;the&nbsp;wound.',
        hintCond: f => f.currentLoop >= 2 && f.day >= 1,
        bgType: 2,
      },
      13: {
        category: 'normal',
        title: 'Horn&nbsp;removal!★',
        phrase: 'You\'ve&nbsp;gone&nbsp;and<br>made&nbsp;my&nbsp;body<br>unable&nbsp;to&nbsp;recover<br>mana!',
        timing: 'Day&nbsp;1:&nbsp;Cheshika',
        cond: 'Have&nbsp;Cheshika&nbsp;pull&nbsp;out&nbsp;Devilun\'s&nbsp;horns',
        hintCond: f => f.currentLoop >= 2 && f.day >= 1,
        bgType: 2,
      },
      14: {
        category: 'normal',
        title: 'Angel\'s&nbsp;Salvation',
        phrase: 'That&nbsp;guy\'s&nbsp;gone...<br>Where\'d&nbsp;he&nbsp;run<br>off&nbsp;to?',
        timing: 'Conversation&nbsp;with&nbsp;Kupyadel',
        cond: 'Pester&nbsp;Kupyadel&nbsp;persistently',
        hintCond: f => f.currentLoop >= 1 && f.day >= 1,
        bgType: 1,
      },
      15: {
        category: 'normal',
        title: 'Demon&nbsp;Hiding&nbsp;in&nbsp;the&nbsp;Toilet',
        phrase: 'Garlic&nbsp;is&nbsp;no&nbsp;good<br>in&nbsp;this&nbsp;form...<br>not&nbsp;at&nbsp;all...',
        timing: 'Day&nbsp;1:&nbsp;Bedroom',
        cond: 'Choose&nbsp;"Extra-Garlic&nbsp;Ramen"&nbsp;for&nbsp;a&nbsp;midnight&nbsp;snack&nbsp;with&nbsp;Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 2,
        bgType: 2,
      },
      16: {
        category: 'normal',
        title: 'Return&nbsp;to&nbsp;the&nbsp;Demon&nbsp;Realm',
        phrase: 'I\'m&nbsp;heading&nbsp;back<br>to&nbsp;the&nbsp;Demon&nbsp;Realm.<br>....You\'ll&nbsp;remember&nbsp;this&nbsp;later.',
        timing: 'MP&nbsp;check&nbsp;(from&nbsp;day&nbsp;1&nbsp;onward)',
        cond: 'Mana&nbsp;is&nbsp;at&nbsp;0%&nbsp;after&nbsp;finishing&nbsp;connections&nbsp;for&nbsp;3&nbsp;characters.',
        hintCond: f => f.currentLoop >= 1 && f.day >= 2,
        bgType: 1,
      },
      17: {
        category: 'normal',
        title: 'Defeat&nbsp;by&nbsp;Law',
        phrase: 'What&nbsp;are&nbsp;you<br>getting&nbsp;arrested&nbsp;for,<br>you&nbsp;idiot?!',
        timing: 'Day&nbsp;2:&nbsp;Connie',
        cond: 'Lend&nbsp;Connie&nbsp;a&nbsp;hand',
        hintCond: f => f.currentLoop >= 1 && f.day >= 2,
        bgType: 2,
      },
      18: {
        category: 'normal',
        title: 'Landmine&nbsp;Player',
        phrase: 'Why\'s&nbsp;this&nbsp;gotta<br>spill&nbsp;over&nbsp;onto&nbsp;me<br>too?',
        timing: 'Day&nbsp;2:&nbsp;Allen',
        cond: 'Make&nbsp;Allen&nbsp;angry&nbsp;twice',
        hintCond: f => f.currentLoop >= 2 && f.day >= 2,
        bgType: 2,
      },
      19: {
        category: 'normal',
        title: 'Naughty&nbsp;Mint',
        phrase: 'Dagyaaah!&nbsp;My&nbsp;horns--!<br>Stop&nbsp;sucking&nbsp;on<br>my&nbsp;horns!',
        timing: 'Day&nbsp;2:&nbsp;Minty',
        cond: 'Lick&nbsp;the&nbsp;Cymint&nbsp;cream',
        hintCond: f => f.currentLoop >= 2 && f.day >= 2,
        bgType: 3,
      },
      20: {
        category: 'normal',
        title: 'Explosive&nbsp;Endings&nbsp;Are&nbsp;the&nbsp;Best.',
        phrase: 'No&nbsp;way.<br>Drop&nbsp;dead!',
        timing: 'Day&nbsp;2:&nbsp;Gaku',
        cond: 'Press&nbsp;Gaku\'s&nbsp;self-destruct&nbsp;switch',
        hintCond: f => f.currentLoop >= 2 && f.day >= 2,
        bgType: 2,
      },
      21: {
        category: 'normal',
        title: 'Eyeball&nbsp;Collector',
        phrase: 'Dagya!!!!!&nbsp;My&nbsp;eyes...!<br>My&nbsp;eyyyes!',
        timing: 'Day&nbsp;3:&nbsp;MuuMuu',
        cond: 'Get&nbsp;your&nbsp;eyeballs&nbsp;stolen&nbsp;by&nbsp;MuuMuu',
        hintCond: f => f.currentLoop >= 1 && f.day >= 3,
        bgType: 2,
      },
      22: {
        category: 'normal',
        title: 'Impaled&nbsp;bat',
        phrase:
          f.ruby === 1
            ? 'Those&nbsp;stupid<br>low-class&nbsp;demons...<br>They\'re&nbsp;so&nbsp;dumb&nbsp;it&nbsp;drives&nbsp;me&nbsp;nuts!'
            : f.ruby === 2
          ? sf.censorship
            ? 'You&nbsp;didn\'t&nbsp;have&nbsp;to&nbsp;■&nbsp;them<br>all&nbsp;at&nbsp;once...<br>Damn&nbsp;it.'
            : 'You&nbsp;didn\'t&nbsp;have&nbsp;to&nbsp;kill<br>them&nbsp;all&nbsp;at&nbsp;once...<br>Damn&nbsp;it.'
            : f.ruby === 3
            ? 'It\'s&nbsp;those&nbsp;weak<br>demons&nbsp;clinging<br>to&nbsp;me<br>that\'s&nbsp;the&nbsp;problem!'
            : f.ruby === 4
            ? 'He\'s&nbsp;so&nbsp;ready<br>to&nbsp;snap,<br>no&nbsp;need&nbsp;for<br>provocation&nbsp;magic...'
            : '',
        timing: 'Day&nbsp;3:&nbsp;Ruby',
        cond: 'Offend&nbsp;Ruby',
        hintCond: f => f.currentLoop >= 1 && f.day >= 3,
        bgType: 2,
      },
      23: {
        category: 'normal',
        title: 'Happy&nbsp;End♥',
        phrase: 'This&nbsp;isn\'t&nbsp;happy<br>at&nbsp;all...',
        timing: 'Day&nbsp;3:&nbsp;Amoamo',
        cond: 'Succumb&nbsp;to&nbsp;Amoamo\'s&nbsp;temptation',
        hintCond: f => f.currentLoop >= 2 && f.day >= 3,
        bgType: 3,
      },
      24: {
        category: 'normal',
        title: 'Let\'s&nbsp;stop&nbsp;provoking!',
        phrase: 'Provoking,&nbsp;you&nbsp;know!<br>...Can\'t&nbsp;stop,<br>right?&nbsp;♥',
        timing: 'Day&nbsp;3:&nbsp;Gawuros',
        cond: 'Don\'t&nbsp;take&nbsp;Gawuros\'s&nbsp;training&nbsp;seriously',
        hintCond: f => f.currentLoop >= 2 && f.day >= 3,
        bgType: 1,
      },
      25: {
        category: 'normal',
        title: 'One&nbsp;who&nbsp;burns&nbsp;with&nbsp;anger',
        phrase: `Gyaaah,&nbsp;it's&nbsp;hot!<br>It&nbsp;burns,&nbsp;${f.name}!`,
        timing: 'Day&nbsp;3:&nbsp;Lamia',
        cond: 'Be&nbsp;burned&nbsp;by&nbsp;Lamia\'s&nbsp;hellfire',
        hintCond: f => f.currentLoop >= 2 && f.day >= 3,
        bgType: 2,
      },
      26: {
        category: 'normal',
        title: 'Peter,&nbsp;Hero&nbsp;of&nbsp;the&nbsp;Spring',
        phrase: 'Dagyagyagyagya!<br>My&nbsp;tail&nbsp;isn\'t&nbsp;sealed<br>yet!',
        timing: 'Day&nbsp;3:&nbsp;Peter',
        cond: 'Call&nbsp;Devilun\'s&nbsp;true&nbsp;name&nbsp;and&nbsp;order&nbsp;him&nbsp;to&nbsp;help&nbsp;Peter',
        hintCond: f => f.currentLoop >= 3 && f.day >= 3,
        bgType: 2,
      },
      27: {
        category: 'normal',
        title: 'Neo&nbsp;Universe',
        phrase: '',
        timing: 'Day&nbsp;3:&nbsp;Finale',
        cond: 'Fail&nbsp;to&nbsp;stop&nbsp;NEO&nbsp;Devilun',
        hintCond: f => f.currentLoop >= 2,
      },
      28: {
        category: 'normal',
        title: 'Deep,&nbsp;deep&nbsp;regret',
        phrase: '',
        timing: 'Day&nbsp;3:&nbsp;Finale',
        cond: 'Stop&nbsp;NEO&nbsp;Devilun',
        hintCond: f => f.currentLoop >= 2,
      },
      29: {
        category: 'normal',
        title: 'There\'s&nbsp;no&nbsp;such&nbsp;thing&nbsp;as&nbsp;a&nbsp;happy&nbsp;marriage.',
        phrase: 'How&nbsp;could&nbsp;this<br>possibly&nbsp;be<br>happiness?!',
        timing: 'Day&nbsp;3:&nbsp;Finale',
        cond: 'Call&nbsp;Devilun\'s&nbsp;true&nbsp;name&nbsp;and&nbsp;command&nbsp;him&nbsp;to&nbsp;marry&nbsp;you',
        next: 'Chapter4_wedding2.ks',
        hintCond: f => f.currentLoop >= 2,
        bgType: 3,
      },
      30: {
        category: 'normal',
        title: 'Forget&nbsp;everything',
        timing: 'Day&nbsp;3:&nbsp;Finale',
        cond: 'Call&nbsp;Devilun\'s&nbsp;true&nbsp;name&nbsp;and&nbsp;command&nbsp;him&nbsp;to&nbsp;become&nbsp;your&nbsp;friend',
        hintCond: f => f.currentLoop >= 2,
      },
      31: {
        category: 'secret',
        title: 'Blue&nbsp;Exorcist',
        phrase: this.aibou()
          ? 'The&nbsp;bath&nbsp;temperature<br>is&nbsp;just&nbsp;right!?<br>What&nbsp;are&nbsp;you&nbsp;after,<br>you!?!?'
          : 'Summoning&nbsp;a&nbsp;demon<br>to&nbsp;<span&nbsp;style="font-family:KaiseiDecol-Bold">exorcise</span>?<br>Is&nbsp;that&nbsp;even<br>allowed?',
        timing: 'Day&nbsp;0:&nbsp;Summoning&nbsp;Devilun',
        cond: 'When&nbsp;introducing&nbsp;yourself&nbsp;as&nbsp;a&nbsp;Summoner&nbsp;in&nbsp;the&nbsp;early&nbsp;loops,&nbsp;say&nbsp;Devilun\'s&nbsp;true&nbsp;name.',
        bgType: 2,
      },
      32: {
        category: 'secret',
        title: 'Boron★',
        phrase: 'The&nbsp;world&nbsp;is...<br>wide,&nbsp;you&nbsp;know...',
        timing: 'Day&nbsp;0:&nbsp;Almaz',
        cond: sf.censorship
          ? 'In&nbsp;a&nbsp;■&nbsp;state,&nbsp;connecting&nbsp;with&nbsp;Almaz.'
          : 'In&nbsp;a&nbsp;futanari&nbsp;state,&nbsp;connecting&nbsp;with&nbsp;Almaz.',
        bgType: 1,
      },
      33: {
        category: 'secret',
        title: 'Trauma&nbsp;of&nbsp;Hellfire',
        phrase: `Gyaaah,&nbsp;it's&nbsp;hot!<br>It&nbsp;burns,&nbsp;${f.name}!`,
        timing: 'Day&nbsp;3:&nbsp;Lamia',
        cond: 'Try&nbsp;to&nbsp;become&nbsp;Lamia\'s&nbsp;familiar',
        bgType: 0,
      },
      34: {
        category: 'secret',
        title: 'Demon&nbsp;Belphegor',
        timing: 'Day&nbsp;3:&nbsp;Peter',
        cond: sf.censorship
          ? 'Devilun&nbsp;■s&nbsp;Peter.'
          : 'Devilun&nbsp;kills&nbsp;Peter.',
      },
      35: {
        category: 'secret',
        title: sf.censorship ? 'He&nbsp;went&nbsp;and&nbsp;■...' : 'He\'s&nbsp;dead...',
        timing: 'Day&nbsp;3:&nbsp;Finale',
        cond: 'Give&nbsp;Kupyadel&nbsp;a&nbsp;custard&nbsp;pie',
      },
      36: {
        category: 'secret',
        title: 'Angel&nbsp;of&nbsp;Vanity',
        timing: 'Day&nbsp;3:&nbsp;Finale',
        cond: 'Forget&nbsp;to&nbsp;give&nbsp;Kupyadel&nbsp;a&nbsp;custard&nbsp;pie',
      },
      37: {
        category: 'secret',
        title: 'A&nbsp;happy&nbsp;marriage&nbsp;♥',
        timing: 'Day&nbsp;3:&nbsp;Finale',
        cond: 'Obtain&nbsp;the&nbsp;ring,&nbsp;call&nbsp;Devilun\'s&nbsp;true&nbsp;name,&nbsp;and&nbsp;command&nbsp;him&nbsp;to&nbsp;marry&nbsp;you.',
      },
      38: {
        category: 'secret',
        title: 'Gluttony&nbsp;Mode&nbsp;ON',
        phrase: `Haven't&nbsp;seen&nbsp;this<br>side&nbsp;of&nbsp;Bub&nbsp;in<br>ages...<br>Wait,&nbsp;it's&nbsp;eating&nbsp;the<br>house?!?!`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Give&nbsp;fish&nbsp;and&nbsp;chips&nbsp;to&nbsp;BBB',
        bgType: 2,
      },
      39: {
        category: 'secret',
        title: 'Bound!&nbsp;Angel&nbsp;of&nbsp;the&nbsp;Demon&nbsp;Realm',
        phrase: `W-What&nbsp;am&nbsp;I&nbsp;being<br>shown&nbsp;here...<br>...I...`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Watch&nbsp;Kupyadel&nbsp;and&nbsp;Amoamo',
        bgType: 2,
      },
      40: {
        category: 'secret',
        title: 'Jealousy&nbsp;Digs&nbsp;Its&nbsp;Own&nbsp;Grave',
        phrase: `You&nbsp;jealous&nbsp;of<br>yours&nbsp;truly?<br>Heh&nbsp;heh&nbsp;heh,&nbsp;serves<br>you&nbsp;right.`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Pointing&nbsp;a&nbsp;mirror&nbsp;at&nbsp;Nazar&nbsp;and&nbsp;receiving&nbsp;the&nbsp;Evil&nbsp;Eye&nbsp;of&nbsp;Envy',
        bgType: 1,
      },
      41: {
        category: 'secret',
        title: 'Penniless&nbsp;House',
        phrase: `...Tough&nbsp;break.`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Fail&nbsp;to&nbsp;see&nbsp;through&nbsp;Maneko\'s&nbsp;mimicry',
        bgType: 1,
      },
      42: {
        category: 'secret',
        title: 'Explosive&nbsp;Ending&nbsp;2',
        phrase: `What&nbsp;the&nbsp;hell&nbsp;is<br>a&nbsp;2?!&nbsp;That's&nbsp;the<br>worst!<br>Drop&nbsp;dead!`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Cast&nbsp;alcohol&nbsp;magic&nbsp;on&nbsp;D&nbsp;Red',
        bgType: 2,
      },
      43: {
        category: 'secret',
        title: 'Grim&nbsp;Reaper\'s&nbsp;Salvation',
        phrase: `What&nbsp;was&nbsp;that&nbsp;just<br>now?!<br>That&nbsp;was&nbsp;pure&nbsp;force<br>majeure!`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Summon&nbsp;Hadester',
        bgType: 2,
      },
      44: {
        category: 'secret',
        title: 'Forced&nbsp;Deportation&nbsp;to&nbsp;the&nbsp;Demon&nbsp;Realm',
        phrase: `Home&nbsp;sweet&nbsp;home!<br>I'm&nbsp;back!<br>Like&nbsp;hell&nbsp;I&nbsp;am,<br>damn&nbsp;it!`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Command&nbsp;Devilun&nbsp;"House"',
        bgType: 3,
      },
      45: {
        category: 'secret',
        title: 'Case&nbsp;closed★',
        phrase: `That&nbsp;Doel&nbsp;bastard...<br>You&nbsp;better&nbsp;reflect<br>on&nbsp;what&nbsp;you&nbsp;did!`,
        timing: 'Connection&nbsp;with&nbsp;a&nbsp;demon',
        cond: 'Clear&nbsp;all&nbsp;the&nbsp;demon&nbsp;connections.',
        next: 'Devil_Chapter3.ks',
        bgType: 2,
      },
    }
  },
  endKeys: function (category) {
    return Object.entries(this._ends())
      .filter(([_, e]) => e.category == category)
      .map(([key, _]) => key)
  },
  end: function (no) {
    return this._ends()[no]
  },
  hintAvailable: function (f, seen) {
    return Object.entries(this._ends())
      .filter(
        ([key, end]) => !seen.includes(key) && end.hintCond && end.hintCond(f)
      )
      .map(([key, _]) => key)
  },
  endCategoryData: () => [
    {
      name: 'normal',
      text: $.lang('collection')['ending']['normal'],
    },
    {
      name: 'secret',
      text: $.lang('collection')['ending']['secret'],
    },
  ],
  endCategoryNames: function () {
    const available = this.secretEndOpenInCollection()
      ? this.endCategoryData()
      : this.endCategoryData().filter(e => e.name == 'normal')
    return available.map(c => c.name)
  },
  endCategory: function (name) {
    return this.endCategoryData().find(c => c.name === name)
  },
  secretEndOpenInCollection: function () {
    return TYRANO.kag.dc.aibou()
  },
  endCount: function () {
    const { secretEndOpen, endings } = TYRANO.kag.variable.sf
    return secretEndOpen
      ? endings.length
      : endings.filter(no => this._ends()[no].category == 'normal').length
  },
  collectedEndCount: function () {
    const { collectedEndings } = TYRANO.kag.variable.sf
    return this.secretEndOpenInCollection()
      ? collectedEndings.length
      : collectedEndings.filter(no => this._ends()[no].category == 'normal')
          .length
  },
  totalEndings: function () {
    const { secretEndOpen } = TYRANO.kag.variable.sf
    const ends = Object.values(TYRANO.kag.dc._ends())
    const available = secretEndOpen
      ? ends
      : ends.filter(e => e.category == 'normal')
    return available.length
  },
  collectedTotalEndings: function () {
    const ends = Object.values(TYRANO.kag.dc._ends())
    const available = this.secretEndOpenInCollection()
      ? ends
      : ends.filter(e => e.category == 'normal')
    return available.length
  },
}
