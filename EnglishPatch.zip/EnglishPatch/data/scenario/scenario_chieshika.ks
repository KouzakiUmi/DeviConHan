[_tb_system_call storage=system/_scenario_chieshika.ks]

[cm  ]
[tb_ptext_hide  time="0"  ]
[tb_image_hide  time="1000"  ]
[bg  time="0"  method="crossfade"  storage="haikei2.webp"  ]
[call  storage="mp.ks"  target="*show"  ]
[call  storage="phase.ks"  target="*show_top"  ]
[chara_show  name="プレイヤー"  zindex="2"  layer="1"  time="0"  wait="false"  storage="chara/2/te.png"  width="1280"  height="960"  ]
[chara_show  name="チェシカ"  time="0"  wait="false"  storage="chara/40/2.png"  width="634"  height="769"  left="377"  top="29"  reflect="false"  ]
[lbgm str="3_connection_communication.ogg" vol="50" loop="true" time="0" buf="0"]

[layermode_movie  mode="screen"  speed="1"  volume="100"  loop="false"  time="0"  wait="false"  video="kiri2.mp4"  ]
[call  storage="maku.ks"  target="*open"  ]
[bg_layermode  name="mahou"  folder="bgimage"  storage="haikei_mahou2.webp"  mode="color-dodge"]

[wait  time="700"  ]
[free_bg_layermode  name="mahou"  time="5000"  ]

*x

[tb_start_text mode=1 ]
#Cheshika
[_tb_end_text]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Cheshika
[font size=40]Whoa, I really[r]got summoned--![resetfont][p]

[_tb_end_text]

[tb_start_tyrano_code]
[play_apng name="debi_fuki_show" layer="0" x="7" y="308" width="384" height="400"]
[_tb_end_tyrano_code]

[wait  time="350"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/21.png"  width="383"  height="400"  left="7"  top="308"  ]
[tb_start_tyrano_code]
[free_apng name="debi_fuki_show" ]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
Look at that huge, fluffy tail...[r]What brings you here to get summoned?[p]

[_tb_end_text]

[jump  storage="scenario_chieshika.ks"  target="*Alice_OK"  cond="f.Alice_nabe>=1"  ]
*Alice_NO

[chara_mod  name="チェシカ"  time="80"  cross="false"  storage="chara/40/3.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Alice said a demon was peeking at her through a crystal.[r]She told me to come check it out![p]



[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/21.png"  ]
[tb_start_text mode=1 ]
#Devilun
Alice? The one next to this guy?[r]I think I peeked out of a crystal yesterday.[p]

[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/1.png"  ]
[tb_start_text mode=1 ]
#Cheshika
I can't believe you really peeked at her...[r]You perverted demon--prepare yourself![p]

[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/67.png"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
So you came all this way to punish us?[r]Hmph. Fine by me... I'll beat you senseless![p]

[_tb_end_text]

[jump  storage="scenario_chieshika.ks"  target="*YES_jump"  ]
*Alice_OK

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/1.png"  ]
[tb_start_text mode=1 ]
#Cheshika
How dare you kidnap Alice yesterday![r]I'm here to take you on![p]



[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/9.png"  ]
[playse  volume="100"  time="0"  buf="3"  storage="aseru.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
Alice...? So you know who shoved that thing[r]up my ass yesterday!?[p]


[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/63.png"  ]
[tb_start_text mode=1 ]
#Devilun
Damn it... Now you're making me summon a tabby.[r]What are you plotting...? I'll punish you![p]


[_tb_end_text]

*YES_jump

[tb_hide_message_window  ]
[chara_hide  name="コマでび"  time="80"  wait="false"  pos_mode="false"  ]
[eval exp="f.zyagan_count = 0"]

*zyagan1_modoru

[choice2 text1="Paper&nbsp;Fan&nbsp;Spell" target1="*ha" text2="Confession&nbsp;Spell" target2="*ho"]

[zyagan target="*zyagan1,*zyagan1_2serihu" borders="25, 31, 37, 43"]

[s  ]
*zyagan1

[mp_check]

[s  cond="!f.mp_check_pass"  ]
[call  storage="zyagan.ks"  target=""  ]
[tb_start_text mode=1 ]
#Cheshika
[_tb_end_text]

[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/fu_te.png"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/4.png"  ]
[bg  time="0"  method="crossfade"  storage="haikei_zyagan_Small.webp"  ]
[call  storage="me.ks"  target="*meopen"  ]
[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Cheshika
Alice said some demons can read minds, right?[r]If my plan gets seen through, that'd be bad![p]

[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/5.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Ah, don't think about it, don't think about it![r][font size=40]Don't think about anything![resetfont][p]


[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="hirameki.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/6.png"  ]
[tb_start_text mode=1 ]
#Cheshika
That's it. I should think of something nasty[r]so I won't mind if he reads it.[p]



[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="pi.ogg"  ]
[tb_start_text mode=4 ]
#Cheshika
■■■■■■■■■■■■■■■■■■■■■■[wait time=300][er]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="80"  wait="false"  storage="chara/10/85.png"  width="383"  height="400"  left="7"  top="308"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
[font face="DZUYOKU"][font size=80]Knock it off![resetfont][p]



[_tb_end_text]

[jump  storage="scenario_chieshika.ks"  target="*zyagan1_modoru_2"  ]
*zyagan1_2serihu

[mp_check]

[s  cond="!f.mp_check_pass"  ]
[call  storage="zyagan.ks"  target=""  ]
[tb_start_text mode=1 ]
#Cheshika
[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/7.png"  ]
[bg  time="0"  method="crossfade"  storage="haikei_zyagan.webp"  ]
[call  storage="me.ks"  target="*meopen"  ]
[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Cheshika
He just struck the lamest double peace-sign pose...[r]Is that the mind-reading power Alice mentioned?[p]
[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/9.png"  ]
[tb_start_text mode=1 ]
#Cheshika
If you're reading my mind right now, please--[r]go easy on me![p]
[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/10.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Gasp... If that's the case,[r]he just read what I shouldn't have thought of.[p]
[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/8.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Uhhh...[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="kawaii2.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/11.png"  ]
[tb_start_text mode=1 ]
#Cheshika
It was a super-cool double peace-sign pose★[p]
[_tb_end_text]

[tb_start_tyrano_code]
[play_apng name="debi_fuki_show" layer="0" x="7" y="308" width="384" height="400"]
[_tb_end_tyrano_code]

[wait  time="350"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/99.png"  width="383"  height="400"  left="7"  top="308"  ]
[tb_start_tyrano_code]
[free_apng name="debi_fuki_show" ]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" x="0"]
[frame p="50%" x="3"]
[frame p="100%" x="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="100" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
Hey, [emb exp="f.name"]![r]A paper fan's too gentle. Go all out.[p]

[_tb_end_text]

*zyagan1_modoru_2

[tb_hide_message_window  ]
[call  storage="me.ks"  target="*me_ENDtozi"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_hide  name="コマでび"  time="0"  wait="false"  pos_mode="false"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/3.png"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/te.png"  ]
[bg  time="0"  method="crossfade"  storage="haikei2.webp"  ]
[call  storage="me.ks"  target="*me_ENDake"  ]
[jump  storage="scenario_chieshika.ks"  target="*zyagan1_modoru"  ]
*ha

[achieve_sticker no=83]

[playse  volume="80"  time="0"  buf="2"  storage="ashi.ogg"  ]
[camera  time="1000"  zoom="1.3"  wait="false"  y="90"  ease_type="ease"  layer="base"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  y="90"  ease_type="ease"  layer="0"  ]
[wait  time="100"  ]
[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/che_1.png"  ]
[wait  time="800"  ]
[chara_show  name="TAP"  time="500"  wait="false"  storage="chara/18/TAP.png"  width="262"  height="131"  left="503"  top="78"  reflect="false"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/12.png"  ]
[playse  volume="100"  time="0"  buf="3"  storage="aseru.ogg"  ]
[tb_show_message_window  ]
[tb_start_text mode=4 ]
#Cheshika
W-what...?[r]You're not hitting me with that fan, are you?
[_tb_end_text]

[clickable  storage="scenario_chieshika.ks"  x="381"  y="10"  width="625"  height="729"  target="*hari"  _clickable_img=""  ]
[s  ]
*hari

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[playse  volume="100"  time="0"  buf="1"  storage="hari2.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/13.png"  ]
[wait  time="200"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=4 ]
#Cheshika
[font size=40]Ow![r]I'm against violence![resetfont]
[_tb_end_text]

[clickable  storage="scenario_chieshika.ks"  x="381"  y="10"  width="625"  height="729"  target="*hari2"  _clickable_img=""  ]
[s  ]
*hari2

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[playse  volume="100"  time="0"  buf="1"  storage="hari.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/16.png"  ]
[wait  time="350"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=4 ]
#Cheshika
Well, that didn't really hurt.[r]Punishing me with a paper fan is kind of lame...

[_tb_end_text]

[clickable  storage="scenario_chieshika.ks"  x="381"  y="10"  width="625"  height="729"  target="*hari3"  _clickable_img=""  ]
[s  ]
*hari3

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[camera  time="0"  zoom="1.3"  wait="false"  y="40"  ease_type="ease"  layer="base"  ]
[camera  time="0"  zoom="1.5"  wait="false"  y="40"  ease_type="ease"  layer="0"  ]
[playse  volume="100"  time="0"  buf="1"  storage="hari3.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/2.png"  ]
[wait  time="350"  ]
[chara_hide  name="TAP"  time="0"  wait="false"  pos_mode="false"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[playse  volume="100"  time="0"  buf="3"  storage="sasu2.ogg"  ]
[tb_start_text mode=1 ]
#Cheshika
[font size=40]Owwww! That made a huge noise![r]All right, I get it! You're so persistent![resetfont][p]


[_tb_end_text]

[playse  volume="100"  time="0"  buf="4"  storage="AURA_NG.ogg"  ]
[chara_show  name="感情オーラ1"  time="1000"  wait="false"  storage="chara/11/moya1-1.png"  width="319"  height="139"  left="329"  top="143"  reflect="false"  ]
[chara_move  name="プレイヤー"  anim="true"  time="1000"  effect="easeOutCubic"  wait="false"  left="1"  top="0"  width="1280"  height="960"  ]
[reset_camera  time="1000"  wait="false"  layer="base"  ]
[reset_camera  time="1000"  wait="false"  layer="0"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/12.png"  ]
[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/te.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Jeez...[r]I hate persistent people.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Cheshika
You want me to tell you the real reason[r]I came here... or was dragged here, right?[p]
[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/15.png"  ]
[tb_start_text mode=1 ]
#Cheshika
The truth is...[p]


[_tb_end_text]

[playse  volume="100"  time="0"  buf="4"  storage="hirameki.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/14.png"  ]
[tb_start_text mode=1 ]
#Cheshika
[if exp="f.Alice_nabe >= 1]Alice told me to get a piece of a demon's body.[r]Because she'd forgotten to[r]collect[r]an[r]ingredient for her potion.[else]Alice told me to identify the peeping[r]demon[r]and,[r]while I was at it,[r]bring back a piece of a demon's body for potion ingredients.[endif][p]That's why I'm here.[p]


[_tb_end_text]

[tb_start_tyrano_code]
[play_apng name="debi_fuki_show" layer="0" x="7" y="308" width="384" height="400"]
[_tb_end_tyrano_code]

[wait  time="350"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/19.png"  width="383"  height="400"  left="7"  top="308"  ]
[tb_start_tyrano_code]
[free_apng name="debi_fuki_show" ]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
Oh, is that so? I see~♪[r]Thanks for the explanation...[p]


[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/99.png"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]You think I'd say that!?[r]You're plotting something outrageous![resetfont][p]



[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/15.png"  ]
[tb_start_text mode=4 ]
#Cheshika
Hmph,
[_tb_end_text]

[jump  storage="scenario_chieshika.ks"  target="*ha_jamp"  ]
*ho

[playse  volume="80"  time="0"  buf="2"  storage="ashi.ogg"  ]
[camera  time="1000"  zoom="1.3"  wait="false"  y="90"  ease_type="ease"  layer="base"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  y="90"  ease_type="ease"  layer="0"  ]
[wait  time="100"  ]
[chara_move  name="プレイヤー"  anim="true"  time="300"  effect="easeOutCubic"  wait="false"  left="0"  top="39"  width="1280"  height="960"  ]
[wait  time="800"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/12.png"  ]
[playse  volume="100"  time="0"  buf="3"  storage="aseru.ogg"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Cheshika
W-what the hell...?[r]Why are you getting so close?[p]
[_tb_end_text]

[tb_hide_message_window  ]
[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[playse  volume="100"  time="0"  buf="3"  storage="fuga2.ogg"  ]
[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/che_2.png"  ]
[stopbgm  time="0"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[wait  time="600"  ]
[l  ]
[playse  volume="100"  time="0"  buf="3"  storage="gimon.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/18.png"  ]
[lbgm str="3_connection_communication.ogg" vol="50" loop="true" time="0" buf="0"]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Cheshika
Gaaah! W-wha...[r][font size=40]What are you holding!?[resetfont][p]

[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Cheshika
All right, I'll tell you the real reason! I will![r]S-so calm down... okay...?[p]


[_tb_end_text]

[chara_show  name="感情オーラ1"  time="1000"  wait="false"  storage="chara/11/moya1.png"  width="400"  height="174"  left="282"  top="107"  reflect="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="AURA_OK.ogg"  ]
[chara_move  name="プレイヤー"  anim="true"  time="300"  effect="easeInOutCubic"  wait="false"  ]
[reset_camera  time="1000"  wait="false"  layer="base"  ]
[reset_camera  time="1000"  wait="false"  layer="0"  ]
[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/te.png"  ]
[tb_start_tyrano_code]
[play_apng name="debi_fuki_show" layer="0" x="7" y="308" width="384" height="400"]
[_tb_end_tyrano_code]

[wait  time="350"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/16.png"  width="383"  height="400"  left="7"  top="308"  ]
[tb_start_tyrano_code]
[free_apng name="debi_fuki_show" ]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
So that's what you call a confession spell...[font size=25] It's just brute force.[resetfont][r]Even if it's only a prop, you're pretty damn brutal.[p]




[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/63.png"  ]
[tb_start_text mode=1 ]
#Devilun
But the emotional aura born of fear is vivid.[r]Very good--keep it up![p]





[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/67.png"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
So? Why did you come here to be summoned?[p]
[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/16.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Well, the truth is[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="4"  storage="hirameki.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/3.png"  ]
[tb_start_text mode=1 ]
#Cheshika
[if exp="f.Alice_nabe >= 1]Alice told me to get a piece of a demon's body.[r]Because she forgot to collect it for her potion.[else]Alice told me to identify the peeping[r]demon[r]and,[r]while I was at it,[r]bring back a piece of a demon's body for potion ingredients.[endif][p]That's why I'm here.[p]

[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/19.png"  ]
[tb_start_text mode=1 ]
#Devilun
Oh, so that's how it is~♪[r]Thanks for explaining...[p]


[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/99.png"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]You think I'd say that!?[r]You're plotting something outrageous![resetfont][p]



[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/15.png"  ]
[tb_start_text mode=4 ]
#Cheshika
Tch...
[_tb_end_text]

[tb_filter_blur  layer="all"  ]
*ha_jamp

[tb_start_text mode=1 ]
#Cheshika
You've seen through my plan. I have no choice.[r]Time to use that trick![p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="wind2.ogg"  ]
[chara_mod  name="チェシカ"  time="100"  cross="false"  storage="chara/40/17.png"  ]
[tb_start_text mode=1 ]
#Cheshika
[font size=40]Behold my secret technique![resetfont][p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/85.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]H-he turned transparent![resetfont][r]But I think you messed it up![p]



[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="wind3.ogg"  ]
[chara_mod  name="チェシカ"  time="100"  cross="false"  storage="chara/40/19.png"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Cheshika
[font size=40]Seriously!?[resetfont][p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="aseru.ogg"  ]
[chara_hide  name="チェシカ"  time="1000"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#Devilun
I shouldn't have told him...[r]He suddenly disappeared.[p]





[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/91.png"  ]
[tb_start_text mode=1 ]
#Devilun
So he can turn invisible.[r]But what good is that supposed to do...[wait time=300][p]



[_tb_end_text]

[tb_eval  exp="f.photoDeviPose=0"  name="photoDeviPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="コマでび"  time="0"  wait="false"  pos_mode="false"  ]
[stopbgm  time="0"  ]
[chara_show  name="サブでび"  time="0"  wait="false"  storage="chara/30/c4.png"  width="488"  height="530"  left="347"  top="204"  reflect="false"  ]
[chara_show  name="透過チェシカ"  time="0"  wait="false"  storage="chara/70\/c1.png"  width="241"  height="189"  left="793"  top="219"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="c"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="透過チェシカ" keyframe="c" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[playse  volume="100"  time="0"  buf="3"  storage="gimon.ogg"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=1 ]
#Devilun
Gah...[p]



[_tb_end_text]

[lbgm str="3_connection_communication.ogg" vol="50" loop="true" time="0" buf="0"]

[tb_start_text mode=1 ]
#Cheshika
Gotcha![r]Nyashishi... You underestimated me.[p]



[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="5"  storage="tuno.ogg"  loop="true"  ]
[chara_mod  name="サブでび"  time="0"  cross="false"  storage="chara/30/c5.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]D-don't! Don't handle my horns so roughly![r]Treat them with care, I said![resetfont][p]



[_tb_end_text]

[chara_mod  name="透過チェシカ"  time="0"  cross="false"  storage="chara/70\/c2.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Just one! I only need one![r]I wonder if I can pull this horn out...[p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[font size=32]It won't come out, idiot![resetfont]I'm not a reindeer![r]They don't grow back, either--I've only got these two![p]
[_tb_end_text]

[chara_mod  name="透過チェシカ"  time="0"  cross="false"  storage="chara/70\/c3.png"  ]
[tb_start_text mode=1 ]
#Cheshika
You say that, but it'll probably pop right out~?[r]Demon horns are valuable in Magirisia, I hear.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[font size=32]Eek... seriously!?[resetfont]I've been thinking this for a while now,[r]but the people of the Human Realm are downright dangerous![p]

[_tb_end_text]

[chara_mod  name="透過チェシカ"  time="0"  cross="false"  storage="chara/70\/c4.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Let's try pulling a little harder...[r][font size=40]Nngh![p]

[_tb_end_text]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[chara_mod  name="サブでび"  time="0"  cross="false"  storage="chara/30/c6.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font face="DZUYOKU"][font size=75]Stop! Stooop![r]Don't pull![resetfont][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[font size=40][font face="DZUYOKU"][if exp="f.ject_tasuke== 1]This happened last time, too![r][endif]Quit standing there and help me, [emb exp="f.name"]![resetfont][p]


[_tb_end_text]

[tb_hide_message_window  ]
[choice2 text1="Pulling&nbsp;Spell" target1="*hi" text2="Copy&nbsp;Spell" target2="*co"]

[s  ]
*hi

[playse  volume="100"  time="0"  buf="3"  storage="sasu2.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[chara_mod  name="サブでび"  time="0"  cross="false"  storage="chara/30/c5.png"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
[font face="DZUYOKU"][font size=40]Hey! You bastard![r]Don't lend a hand![resetfont][p]





[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[font face="DZUYOKU"][font size=40]Fgyuu! It's stronger than before![r]I'm gonna die! I'm gonna die![resetfont][p]




[_tb_end_text]

[chara_mod  name="透過チェシカ"  time="0"  cross="false"  storage="chara/70\/c5.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Yeah, that's it![r]Start closer to the root![p]

[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font face="DZUYOKU"][font size=56]Hiiieeeeeee![resetfont][p]




[_tb_end_text]

[chara_mod  name="透過チェシカ"  time="0"  cross="false"  storage="chara/70\/c2.png"  ]
[playse  volume="100"  time="0"  buf="5"  storage="tuno2.ogg"  loop="true"  ]
[chara_mod  name="サブでび"  time="0"  cross="false"  storage="chara/30/c7.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Oh, it feels like it's about to come out![p]

[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="sasu2.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font face="DZUYOKU"][font size=56]Fgyuaaahhh![resetfont][p]


[_tb_end_text]

[hide_photo_button]

[chara_mod  name="サブでび"  time="0"  cross="false"  storage="chara/30/c8.png"  ]
[wait  time="150"  ]
[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[stopbgm  time="0"  ]
[stopse  time="1000"  buf="5"  ]
[chara_hide_all  time="0"  wait="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[tb_image_hide  time="0"  ]
[bg  time="0"  method="crossfade"  storage="kuro.webp"  ]
[call  storage="mp.ks"  target="*hide"  ]
[call  storage="phase.ks"  target="*hide"  ]
[playse  volume="100"  time="0"  buf="3"  storage="pon.ogg"  ]
[wait  time="1000"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=1 ]
#Devilun
[font face="YOWAKU"]Aa............[resetfont][wait time=200][p]



[_tb_end_text]

[stopse  time="0"  buf="5"  ]
[tb_eval  exp="f.photoDeviPose=1"  name="photoDeviPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[ending no="13"]

*co

[tb_eval  exp="f.photoDeviPose=1"  name="photoDeviPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[stopse  time="0"  buf="5"  ]
[chara_hide  name="サブでび"  time="0"  wait="false"  pos_mode="false"  ]
[chara_hide  name="透過チェシカ"  time="0"  wait="false"  pos_mode="false"  ]
[wait  time="200"  ]
[playse  volume="100"  time="0"  buf="1"  storage="hirameki.ogg"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[chara_show  name="感情オーラ2"  time="1000"  wait="false"  storage="chara/12/moya2.png"  width="358"  height="179"  left="738"  top="238"  reflect="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="AURA_OK.ogg"  ]
[chara_show  name="チェシカ"  time="800"  wait="false"  storage="chara/40/20.png"  width="666"  height="808"  left="377"  top="29"  reflect="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="wind2.ogg"  ]
[tb_start_text mode=1 ]
#Cheshika
Oh! Thanks![r]You should've told me you had a spare![p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[_tb_end_text]

[tb_start_tyrano_code]
[play_apng name="debi_fuki_show" layer="0" x="7" y="308" width="384" height="400"]
[_tb_end_tyrano_code]

[wait  time="350"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/30.png"  width="383"  height="400"  left="7"  top="308"  ]
[tb_start_tyrano_code]
[free_apng name="debi_fuki_show" ]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
[font face="YOWAKU"]Haa... haaah... thank goodness...[resetfont][r]What did you think demon horns were made of...?[p]

[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/14.png"  ]
[tb_start_text mode=1 ]
#Devilun
The Copy Spell's just a prop anyway.[r]Good thing that guy seems like an idiot.[p]



[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/30.png"  ]
[stopbgm  time="0"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/14.png"  ]
[playse  volume="100"  time="0"  buf="3"  storage="gimon.ogg"  ]
[tb_start_text mode=1 ]
#Cheshika
All right, then. Next up: body hair![p]



[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/95.png"  ]
[lbgm str="3_connection_communication.ogg" vol="50" loop="true" time="0" buf="0"]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="sasu2.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]You use hair in potions, too!?[resetfont][p]



[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/1.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Yeah! Next, use the hair-clipper spell![r]Where should I shave?[p]

[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/14.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Pick a recommended spot![p]


[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/95.png"  ]
[playse  volume="100"  time="0"  buf="3"  storage="sasu.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=43]Don't say it like we're at a butcher shop![resetfont][p]

[_tb_end_text]

[tb_hide_message_window  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/fu_te2.png"  ]
[chara_hide  name="コマでび"  time="80"  wait="false"  pos_mode="false"  ]
[eval exp="f.zyagan_count = 0"]

*zyagan3_modoru

[choice2 text1="Crotch&nbsp;Hair" target1="*oma" text2="Tail&nbsp;Hair" target2="*shi"]

[zyagan target="*zyagan3" borders="150, 156, 162, 168"]

[s  ]
*zyagan3

[mp_check]

[s  cond="!f.mp_check_pass"  ]
[call  storage="zyagan.ks"  target=""  ]
[tb_start_text mode=1 ]
#Cheshika
[_tb_end_text]

[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/fu_te.png"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/4.png"  ]
[bg  time="0"  method="crossfade"  storage="haikei_zyagan.webp"  ]
[call  storage="me.ks"  target="*meopen"  ]
[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Cheshika
Alice said she wanted a fluffy part, I think...[p]
[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/7.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Don't tell me she's so obsessed with fluffy tails[r]she wants to do something with demon hair, too.[p]
[_tb_end_text]

[call  storage="me.ks"  target="*me_ENDtozi"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/1.png"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/fu_te2.png"  ]
[bg  time="0"  method="crossfade"  storage="haikei2.webp"  ]
[call  storage="me.ks"  target="*me_ENDake"  ]
[jump  storage="scenario_chieshika.ks"  target="*zyagan3_modoru"  ]
*oma

[tb_eval  exp="f.photoPose=0"  name="photoPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="idou.ogg"  ]
[chara_show  name="サブでび"  time="0"  wait="false"  storage="chara/30/ashi.png"  width="972"  height="360"  left="144"  top="608"  reflect="false"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/1.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
Jeez... be careful, will you?[r]Why am I doing this pet-like nonsense...[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="5"  storage="bari.ogg"  loop="true"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="aseru.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
W-wait... of all places,[r]why are you shaving there...?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
I've got an Evil Eye on my belly, you know?[r]Is that your way of being considerate?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[font face="YOWAKU"]Still, this is kind of embarrassing...[resetfont][p]


[_tb_end_text]

[playse  volume="100"  time="0"  buf="1"  storage="sasu.ogg"  ]
[quake  time="300"  count="3"  hmax="15"  wait="false"  vmax="0"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]A-aren't you shaving too much?[r]Hey, that's enough!?[resetfont][p]

[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/12.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Hurry up![p]

[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="サブでび"  time="0"  wait="false"  pos_mode="false"  ]
[chara_show  name="プレイヤー"  zindex="2"  layer="1"  time="0"  wait="false"  storage="chara/2/te.png"  width="1280"  height="960"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/15.png"  width="383"  height="400"  left="7"  top="308"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/21.png"  ]
[stopse  time="0"  buf="5"  ]
[playse  volume="100"  time="0"  buf="3"  storage="idou.ogg"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="20"  effect="fadeOut"  ]

[tb_eval  exp="f.photoPose=1"  name="photoPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_start_text mode=1 ]
#Devilun
There. Satisfied now?[r]For mana, I can spare a few hairs![p]

[_tb_end_text]

[chara_show  name="感情オーラ3"  time="1000"  wait="false"  storage="chara/13/moya3-3.png"  width="460"  height="200"  left="312"  top="455"  reflect="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="AURA_NG.ogg"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/16.png"  ]
[tb_eval  exp="f.che_mata=1"  name="che_mata"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_start_text mode=1 ]
#Cheshika
It's kind of short and poor quality.[r]And it has a distinctive smell...[font size=25] Still, I'll take it.[resetfont][p]

[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/103.png"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="sasu2.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=56]You baaaastard![resetfont][r]Give it back! Give me back my crotch hair![p]

[_tb_end_text]

[chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/91.png"  ]
[jump  storage="scenario_chieshika.ks"  target="*mata_jamp"  ]
*shi

[tb_eval  exp="f.photoPose=0"  name="photoPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[playse  volume="100"  time="0"  buf="3"  storage="idou.ogg"  ]
[chara_show  name="サブでび"  time="0"  wait="false"  storage="chara/30/ashi.png"  width="972"  height="360"  left="144"  top="608"  reflect="false"  ]
[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/1.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
Jeez... do it properly, will you?[r]Why am I doing this pet-like nonsense...[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="5"  storage="bari.ogg"  loop="true"  ]
[tb_start_text mode=1 ]
#Devilun
Oh, tail hair. There's plenty of that,[r]so it's a safe choice.[p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
...Hey, don't take a whole clump[r]all at once, okay?[p]




[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="サブでび"  time="0"  wait="false"  pos_mode="false"  ]
[chara_show  name="プレイヤー"  zindex="2"  layer="1"  time="0"  wait="false"  storage="chara/2/te.png"  width="1280"  height="960"  ]
[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/15.png"  width="383"  height="400"  left="7"  top="308"  ]
[stopse  time="0"  buf="5"  ]
[playse  volume="100"  time="0"  buf="3"  storage="idou.ogg"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="20"  effect="fadeOut"  ]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/21.png"  ]
[tb_eval  exp="f.photoPose=1"  name="photoPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_start_text mode=1 ]
#Devilun
Hmph. You'd better be grateful![p]

[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/14.png"  ]
[chara_show  name="感情オーラ3"  time="1000"  wait="false"  storage="chara/13/moya3.png"  width="400"  height="200"  left="312"  top="455"  reflect="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="AURA_OK.ogg"  ]
[tb_start_text mode=1 ]
#Cheshika
[font size=40]Thanks![resetfont][r]It's so fluffy and looks like good quality![p]


[_tb_end_text]

[chara_show  name="コマでび"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/10/7.png"  width="383"  height="400"  left="7"  top="308"  ]
*mata_jamp

[achieve_sticker no="28"]

[tb_start_text mode=1 ]
#Devilun
It's give and take. I've given you this much,[r]so now I'll take plenty of mana from you![p]

[_tb_end_text]

[kyushu]

[tb_show_message_window  ]
[tb_start_tyrano_code]
[anim layer="message0" time="300" opacity="255"]
[anim name="fixlayer" time="300" opacity="255"]
[wait time="300"]
[_tb_end_tyrano_code]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/12.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Whoa, I'm suddenly feeling dizzy...[r]I'll get back to Alice for a healing potion.[p]


[_tb_end_text]

[chara_mod  name="チェシカ"  time="0"  cross="false"  storage="chara/40/14.png"  ]
[tb_start_text mode=1 ]
#Cheshika
Well, I got the ingredient she asked for.[r]She's sure to be happy! Nyashishi![p]


[_tb_end_text]

[tb_hide_message_window  ]
[stopse  time="0"  buf="5"  ]
[tb_start_text mode=1 ]
#Devilun
[_tb_end_text]

[call  storage="maku.ks"  target="*close"  ]
[chara_hide_all  time="0"  wait="false"  ]
[tb_eval  exp="f.photoDeviPose=0"  name="photoDeviPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="scenario_chieshika.ks"  target="*mata"  cond="f.che_mata==1"  ]
[chara_show  name="でびるん"  time="0"  wait="false"  storage="chara/1/5.png"  width="1280"  height="960"  ]
[tb_start_tyrano_code]
[keyframe name="fuwa"]
[frame p="0%" y="0"]
[frame p="50%" y="-50"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="でびるん" keyframe="fuwa" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[playbgm  volume="50"  time="0"  loop="true"  storage="1_debirun_no_theme.ogg"  ]
[call  storage="maku.ks"  target="*open"  ]
[wait  time="1000"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Devilun
Body hair grows back, so I suppose it's fine...[r]But this is a one-time deal! Jeez...[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/12.png"  ]
[tb_start_text mode=1 ]
#Devilun
Tail hair grows back especially fast, you know?[r]A little shaving won't make it run out.[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
Hm? What's with that look?[r]You're not plotting something weird, are you?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Trying to make pocket money by selling demon hair...[r]A broke magic student would think of that.[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/10.png"  ]
[camera  time="1000"  zoom="1.3"  wait="false"  x="0"  y="50"  rotate="0"  layer="base"  ease_type="ease"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  x="0"  y="50"  rotate="0"  layer="0"  ease_type="ease"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  x="0"  y="50"  rotate="0"  layer="1"  ease_type="ease"  ]
[tb_start_text mode=1 ]
#Devilun
Kufufu, you fool. I'll never let you do that♥[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/11.png"  ]
[tb_start_text mode=1 ]
#Devilun
If you want money, sell your own soul[r]to the Great Demon of Greed! Gyahaha![p]

[_tb_end_text]

[iscript]
// 全部見たら記録する（初回だけ）
if (f.chara && !f.finished.includes(f.chara.name)) {
f.finished = [...f.finished, f.chara.name];
}
[endscript]

[tb_hide_message_window  ]
[call  storage="maku.ks"  target="*close"  ]
[chara_hide  name="でびるん"  time="0"  wait="false"  pos_mode="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[free_layermode  time="1000"  wait="true"  ]
[jump  storage="syoukan.ks"  target=""  ]
*mata

[chara_show  name="でびるん"  time="0"  wait="false"  storage="chara/1/h1.png"  width="1280"  height="960"  ]
[tb_start_tyrano_code]
[keyframe name="fuwa"]
[frame p="0%" y="0"]
[frame p="50%" y="-50"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="でびるん" keyframe="fuwa" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[playbgm  volume="50"  time="0"  loop="true"  storage="1_debirun_no_theme.ogg"  ]
[call  storage="maku.ks"  target="*open"  ]
[wait  time="1000"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Devilun
Body hair grows back, so I suppose it's fine...[r]But this is a one-time deal! Jeez...[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/h2.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=200]......[resetdelay]What is it?[p]


[_tb_end_text]

[tb_hide_message_window  ]
[chara_show  name="TAP"  time="500"  wait="false"  storage="chara/18/TAP.png"  width="262"  height="131"  left="516"  top="432"  reflect="false"  ]
[clickable  storage="scenario_chieshika.ks"  x="524"  y="492"  width="229"  height="224"  target="*debi"  _clickable_img=""  ]
[s  ]
*debi

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="TAP"  time="200"  wait="false"  pos_mode="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="mp.ogg"  ]
[playse  volume="100"  time="0"  buf="3"  storage="aseru.ogg"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/h3.png"  ]
[tb_show_message_window  ]
[flash_off  time="20"  effect="fadeOut"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]Stop fixating on my crotch![resetfont][r]What the hell is wrong with you...?[p]
[_tb_end_text]

[tb_hide_message_window  ]
[chara_show  name="TAP"  time="500"  wait="false"  storage="chara/18/TAP.png"  width="262"  height="131"  left="516"  top="432"  reflect="false"  ]
[clickable  storage="scenario_chieshika.ks"  x="524"  y="492"  width="229"  height="224"  target="*debi2"  _clickable_img=""  ]
[s  ]
*debi2

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="TAP"  time="200"  wait="false"  pos_mode="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="mp.ogg"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/h4.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_show_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="sasu2.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]DAGYA!? I thought it was just drafty--[r]but I'm completely bald![resetfont][p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/h5.png"  ]
[tb_start_text mode=4 ]
#Devilun
Damn it... this is all your fault, you know.[r]My dignity is disappearing by the second.

[_tb_end_text]

[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/fu_te2.png"  ]
[tb_start_tyrano_code]
[preload  storage="./data/image/waku2.png"  ]
[glink name="waku_small" font_color="white" storage="" target="*debirun" face="KaiseiDecol-Bold"  text="Hair-Growth&nbsp;Spell" x="464" y="490" width="352" height="79" size="30" graphic="ui/waku_small.png" enterimg="ui/waku_small_.png" enterse="tap.ogg" clickse="OK.ogg"]
[_tb_end_tyrano_code]

[s  ]
*debirun

[tb_hide_message_window  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="hazikeru.ogg"  ]
[tb_start_tyrano_code]
[play_apng name="kemuri" layer="1" x="0" y="0" width="1280" height="960" mode="screen" free="true"]
[_tb_end_tyrano_code]

[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/te.png"  ]
[wait  time="300"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/6.png"  ]
[wait  time="500"  ]
[playse  volume="100"  time="0"  buf="3"  storage="hirameki.ogg"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]Huh! It's grown back![resetfont][p]

[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="kawaii.ogg"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/11.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=40]DAGYA--thank goodness![resetfont][p]



[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/1.png"  ]
[tb_start_text mode=1 ]
#Devilun
You can be thoughtful sometimes, can't you?[r]I may have misjudged you.[p]


[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  storage="gimon.ogg"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/12.png"  ]
[tb_start_text mode=1 ]
#Devilun
...Ngyah? Wait, this is all because[r]you shaved me here first, didn't you?[p]

[_tb_end_text]

[camera  time="1000"  zoom="1.5"  wait="false"  x="0"  y="50"  rotate="0"  layer="0"  ease_type="ease"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
Hey, apologize. Stop making trouble just to fix it.[r]Are you listening? Hey![p]
[_tb_end_text]

[tb_eval  exp="f.chieshika=1"  name="chieshika"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[iscript]
// 全部見たら記録する（初回だけ）
if (f.chara && !f.finished.includes(f.chara.name)) {
f.finished = [...f.finished, f.chara.name];
}
[endscript]

[tb_hide_message_window  ]
[call  storage="maku.ks"  target="*close"  ]
[chara_hide  name="でびるん"  time="0"  wait="false"  pos_mode="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[free_layermode  time="1000"  wait="true"  ]
[jump  storage="syoukan.ks"  target=""  ]
