[_tb_system_call storage=system/_AAAA_debi_sample.ks]

[playbgm  volume="50"  time="0"  loop="true"  storage="1_debirun_no_theme.ogg"  ]
[bg  time="0"  method="crossfade"  storage="haikei2.webp"  ]
[chara_show  name="でびるん"  time="0"  wait="false"  storage="chara/1/1.png"  width="1280"  height="960"  ]
[tb_start_tyrano_code]
[keyframe name="fuwa"]
[frame p="0%" y="0"]
[frame p="50%" y="-50"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="でびるん" keyframe="fuwa" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[call  storage="maku.ks"  target="*open"  ]
[wait  time="1500"  ]
[fadein_window time=1000]

[tb_start_text mode=1 ]
#Devilun
What's this easing thing?[p]


[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/1.png"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  layer="layer_camera"  ease_type="ease"  y="50"  ]
[tb_start_text mode=1 ]
#Devilun
Ease[p]


[_tb_end_text]

[reset_camera  time="500"  wait="false"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/11.png"  ]
[tb_start_text mode=1 ]
#Devilun
Hmm. Looks pretty good.[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/1.png"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  layer="layer_camera"  ease_type="linear"  y="50"  ]
[tb_start_text mode=1 ]
#Devilun
Linear[p]


[_tb_end_text]

[reset_camera  time="500"  wait="false"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
Hmm. Kinda lame without any change of pace.[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/1.png"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  layer="layer_camera"  ease_type="ease-in"  y="50"  ]
[tb_start_text mode=1 ]
#Devilun
Ease in[p]


[_tb_end_text]

[reset_camera  time="500"  wait="false"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/17.png"  ]
[tb_start_text mode=1 ]
#Devilun
Hmm. So it starts out moving slowly?[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/1.png"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  layer="layer_camera"  ease_type="ease-out"  y="50"  ]
[tb_start_text mode=1 ]
#Devilun
Ease out[p]


[_tb_end_text]

[reset_camera  time="500"  wait="false"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/6.png"  ]
[tb_start_text mode=1 ]
#Devilun
Huh? I'm starting to lose track of the difference.[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/1.png"  ]
[camera  time="1000"  zoom="1.5"  wait="false"  layer="layer_camera"  ease_type="ease-in-out"  y="50"  ]
[tb_start_text mode=1 ]
#Devilun
Ease in out[p]


[_tb_end_text]

[reset_camera  time="500"  wait="false"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/5.png"  ]
[tb_start_text mode=1 ]
#Devilun
I dunno... Ease is probably the safest choice, right?[p]

[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/10.png"  ]
[tb_start_text mode=1 ]
#Devilun
Got it? Bayachao. Make a good game and[r]don't slack on worshipping me and spreading the word. Or else, drop dead.[p]

[_tb_end_text]

