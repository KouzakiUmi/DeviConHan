[_tb_system_call storage=system/_gekizyou_END3.ks]

[cm  ]
[bg_loop name="gekizyo2"]

[chara_show  name="劇場でび"  time="0"  wait="false"  storage="chara/15/dagya5.png"  width="564"  height="595"  left="355"  top="143"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[stopse  time="300"  buf="1"  fadeout="true"  ]
[call  storage="maku.ks"  target="*open_gekizyou"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="5_theater.ogg"  ]
[fadein_window  time="1000"  ]
[jump  storage="gekizyou_END3.ks"  target="*mitakotoaru"  cond="sf.omakes.length>0"  ]
[tb_start_text mode=1 ]
#Devilun
Ahem. Since this is your first time here, I'll[r]explain it to you.[r][wait time=300]This is the post-ending bonus corner![p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Whether you watch it or not is up to you[r]Well, [wait time=300]maybe something good will happen[r]if[r]you[r]complete everything[p]
[_tb_end_text]

*mitakotoaru

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.omakes.length > 0]Hey, you[delay speed=300]...[resetdelay][resetdelay][else]Anyway[delay speed=300]...[resetdelay][endif][p]

[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya4.png"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="劇場でび"  time="30"  cross="false"  storage="chara/15/dagya4.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=34]Why do you keep pawing at my horn over and over and over?[r]You pervert--![resetfont][p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
To you guys, my horn probably looks like nothing[r]more than an ornament[r]but that's not all it is[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
It's an important organ for absorbing mana![r]For a demon, it's a very sensitive area![p]




[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya5.png"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
Normally, I wouldn't react so[r]sensitively to a mere touch...[p]It's all because of this tiny body...[r]I wanna hurry up and look like I[r]did in the Demon Realm again[p]






[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya7.png"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Devilun
[font size=34]Let's get back out there and collect some mana already[r]you punk--![resetfont][p]






[_tb_end_text]

[jump  storage="gekizyou_END_menu.ks"  target=""  ]
