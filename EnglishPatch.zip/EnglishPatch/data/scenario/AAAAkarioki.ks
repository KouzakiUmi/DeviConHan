[_tb_system_call storage=system/_AAAAkarioki.ks]

[tb_start_text mode=1 ]
#Devilun
[if exp="f.point == 0]... Seriously?[endif][p]
[_tb_end_text]

[mind_voice  color="0x56b0af"  name="Devilun"  text="Yo, Bub... Though without the Evil Eye, they won't hear me."  face="craftmincho"  ]
[reset_mind_voice  ]
[jump  storage="Devil_Hardester.ks"  target="*trueEND"  cond="dc.aibou()"  ]
[comment  c="↑トゥルーエンド行った分岐"  ]
[comment  c="カメラ装飾"  ]
[camera  time="1000"  zoom="1.1"  wait="false"  layer="layer_camera"  ]
[reset_camera  time="5000"  wait="false"  layer="layer_camera"  ]
[memory name="kupya_meteor" val="1"]

[tb_start_tyrano_code]
[position layer="message0" frame="Message3.png"  height="258"  ]
[_tb_end_tyrano_code]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[tb_start_text mode=1 ]
#Difficult Kanji
SCOPE [font face="KaiseiDecol-Bold"]LICK[resetfont] [font face="KaiseiDecol-Bold"]DEEPEN THE BOND[resetfont][p]
[_tb_end_text]

[tb_start_text mode=1 ]
[p]
[ruby text="⠀"][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Strength and Weakness
[font face="DZUYOKU"]AAA[resetfont][p]
[font face="YOWAKU"]AAA[resetfont][p]
[font face="kowai"]AAA[resetfont][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#&f.debiName
[r][playse  volume="100"  time="0"  buf="3"  storage="bane.ogg"  ][font size=45]WEAK[wait time=400][playse  volume="100"  time="0"  buf="3"  storage="bane.ogg"  ]LING[wait time=400][resetfont][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Camera State
[if exp="f.cameraEnable"]Camera On[else]Camera Off[endif] [p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Third Character
[if exp="f.finished.length==2"]When it's the third one[else]Otherwise[endif] [p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Font Size
[font size=50][resetfont][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0]Not killed[else]Killed[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.epilogue == 0]Not visited[else]Visited[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0][emb exp="f.name"][else]Wimp[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Wait
[delay speed=100]...[resetdelay][p]
[wait time=300][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Make Text Huge
[font size=50]![resetfont][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Name String
[emb exp="f.name"]♥[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Loop 1 Only
[if exp="f.currentLoop == 1]First time[else]Not the first time[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Male/Female Branch
[if exp="f.seibetu == 1]Bro[else]Sis[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Bouncy Devilun Panel ↓
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Side-to-Side Shaking Devilun Panel ↓
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" x="0"]
[frame p="50%" x="3"]
[frame p="100%" x="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="100" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Color
[font color=0xEC6FC5 bold=true]Sloth[resetfont][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Red
[font color=0xFF0000][p]
[resetfont][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Stop/Play BGM

[_tb_end_text]

[stopbgm  time="0"  ]
[tb_start_text mode=1 ]
#Gauge Movement

[_tb_end_text]

[tb_start_text mode=1 ]
#If Statement
[if exp="f.end_complete == 1"]-kun[else]-san[endif][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#If Statement
[if exp="f.seibetu == 1"]-kun[else]-san[endif][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#If Statement
[if exp="dc.aibou()"]True ending reached[else]True ending not reached[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Neo
[font color=0xab0009 bold=true][quake_text][delay speed=100][if exp="dc.aibou()"]True ending reached[else]True ending not reached[endif][resetdelay][free_quake_text][resetfont][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#If Syntax
[if exp="f.syo == 1"][else]Summoner[endif][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#If Syntax
[if exp="f.hutanari == 1"]Futanari[else]Not futanari[endif][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#System Variable If Statement
[if exp="sf.hensuu == 1"]This number[else]Any other number[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Shake
[quake_text]I'm used to it now[free_quake_text][p]
[_tb_end_text]

[call  storage="mp.ks"  target="*update"  ]
[tb_start_text mode=1 ]
↓ Fade-In/Out Image[p]

[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[flash_off  time="20"  effect="fadeOut"  ]

[flash  time="80"  effect="fadeIn"  color="0xFFFFFF"  ]

[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=1 ]
#↓ Zooming Hand
[_tb_end_text]

[chara_move  name="プレイヤー"  anim="true"  time="1000"  effect="easeOutCubic"  wait="false"  left="1"  top="-184"  width="1234"  height="925"  ]
[chara_move  name="プレイヤー"  anim="true"  time="1000"  effect="easeOutCubic"  wait="false"  left="1"  top="0"  width="1280"  height="960"  ]
[lbgm str="3_connection_communication.ogg" vol="50" loop="true" time="0" buf="0"]

[tb_start_text mode=1 ]
#↓ Volume 0

[_tb_end_text]

[lbgmvol vol="0"]

[lbgmvol vol="50"]

[tb_start_text mode=1 ]
#Resume Mid-Track
[_tb_end_text]

[lbgmstop]

[lbgmresume str="3_connection_communication.ogg"]

[tb_start_text mode=1 ]
#Hide Menu
[_tb_end_text]

[disable_menu_button]

[enable_menu_button]

[tb_start_text mode=1 ]
#Hide Skip Button
[_tb_end_text]

[disable_skip_button visible="true"]

[enable_skip_button visible="true"]

[tb_start_text mode=1 ]
#Stop Skipping
[_tb_end_text]

[skipstop]

[tb_start_text mode=1 ]
#Hide Photo Button
[_tb_end_text]

[hide_photo_button]

[show_photo_button  visible="true"]

[tb_start_text mode=1 ]
#Photo Pose Off
[_tb_end_text]

[tb_eval  exp="f.photoPose=0"  name="photoPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.photoPose=1"  name="photoPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_start_text mode=1 ]
#Hide Devilun Photo
[_tb_end_text]

[tb_eval  exp="f.photoDeviPose=0"  name="photoDeviPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.photoDeviPose=1"  name="photoDeviPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_start_text mode=1 ]
#Hide Non-Fixed Pose (Hide Summoner in Back)
[_tb_end_text]

[tb_eval  exp="f.photoNonFixedPose=0"  name="photoNonFixedPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.photoNonFixedPose=1"  name="photoNonFixedPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_start_tyrano_code]
[if exp="f.gauru==1"]
#Gawuros
Use the Magic Eye properly![p]
[elsif exp="f.gauru==2"]
#Gawuros
Use the Evil Eye properly![r]Two[p]
[elsif exp="f.gauru==3"]
#Gawuros
Use the Magic Eye properly![r]Three[p]
[elsif exp="f.gauru==4"]
#Gawuros
Stop taunting me with those squats![p]
[elsif exp="f.gauru==5"]
#Gawuros
You're playing around, aren't you?[r]...with me.[p]
[elsif exp="f.gauru==6"]
#Gawuros
Heh, you're an interesting [if exp="f.seibetu == 1]guy[else]girl[endif]...[p]
[elsif exp="f.gauru==7"]
#Gawuros
Those bangs of yours...[r]look pretty slick![p]
[elsif exp="f.gauru==8"]
#Gawuros
...It's about time we faced[r]what's on my mind.[p]
[elsif exp="f.gauru==9"]
#Gawuros
My favorite food is menma.[p]
[elsif exp="f.gauru==10"]
#Gawuros
Time for a little punishment, huh?[p]
[elsif exp="f.gauru==11"]
#Gawuros
I'm gonna count down, okay!?[p]
[elsif exp="f.gauru==12"]
#Gawuros
[font size=50]Three![resetfont][p]
[elsif exp="f.gauru==13"]
#Gawuros
[font size=60]Two![resetfont][p]
[elsif exp="f.gauru==14"]
#Gawuros
[font size=70]One![resetfont][p]
[elsif exp="f.gauru==15"]
#Gawuros
[jump  storage="scenario_gauru.ks"  target="*15"  cond=""  ][p]
[else]
#Gawuros
...[p]
[endif]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Show Inner Voice
[_tb_end_text]

[mind_voice  color="0x56b0af"  name="Devilun"  text="Playing at being a succubus...<br>You're greedy enough to moonlight as the Demon of Greed..."  face="craftmincho"  ]
[reset_mind_voice  ]
[mind_voice  color="0xfffb7a"  name="Cupy"  text="I promise... I'll find it..."  face="KaiseiDecol-Bold"  ]
[tb_start_text mode=1 ]
#Hide Inner Voice
[_tb_end_text]

[reset_mind_voice  ]
[tb_start_text mode=1 ]
#Darken with Window Visible
[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="0"  wait="false"  ]

[free layer=4 name="kuro" time="0"  ]

[tb_start_tyrano_code]
[if exp="f.currentLoop == 3"]
#Kupyadel
!
[elsif exp="f.currentLoop == 4"]
#Kupyadel
!
[else]
#Kupyadel
...
[endif]
[p]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[if exp="f.kupya_owari == 0"]
#Kupyadel
I don't have anything left to talk about nowww.[r]Please understand meee.
[elsif exp="f.kupya_owari == 1"]
#Kupyadel
My talk deck is totally empty nowww.
[elsif exp="f.kupya_owari == 2"]
#Kupyadel
Shall we talk about the weather?
[elsif exp="f.kupya_owari == 3"]
#Kupyadel
[emb exp="f.name"][r]You could bring up a topic once in a whileee.
[elsif exp="f.kupya_owari == 4"]
#Kupyadel
[emb exp="f.name"][r]You're surprisingly needy, aren't youuu?
[elsif exp="f.kupya_owari == 5"]
#Kupyadel
You need to give Devilun some attention, too, okayyy?
[elsif exp="f.kupya_owari == 6"]
#Kupyadel
I wanna give Devilun's horns[r]a little poke-poke, toooo!
[elsif exp="f.kupya_owari == 7"]
#Kupyadel
If you want some advice,[r]just let me know, okay?
[elsif exp="f.kupya_owari == 8"]
#Kupyadel
Cupyaa~ I'm getting sleepy...
[elsif exp="f.kupya_owari == 9"]
#Kupyadel
With a face like this, I can nap in church[r]without anyone noticing, you knowww.
[elsif exp="f.kupya_owari == 10"]
#Kupyadel
Snooo~[delay speed=100]...[resetdelay]
[elsif exp="f.kupya_owari == 11"]
#Kupyadel
Snooo~[delay speed=100]......[resetdelay]
[elsif exp="f.kupya_owari == 12"]
#Kupyadel
With a face like this, I can nap in church[r]without anyone noticing, you knowww.
[elsif exp="f.kupya_owari == 13"]
#Kupyadel
You decide if I'm really asleep or just pretendinggg.
[elsif exp="f.kupya_owari == 14"]
#Kupyadel
Snooo~[delay speed=100]...[resetdelay]
[else]
#Kupyadel
Snooo~[delay speed=100]......[resetdelay]
[endif]
[p]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Pendulum
[_tb_end_text]

[comment  c="小"  ]
[swing  name="でび縛り"  angle="1"  axis="181,0"  time="2000"  easing="sine"]

[comment  c="中"  ]
[swing  name="でび縛り"  angle="3"  axis="181,0"  time="2000"  easing="sine"]

[comment  c="大"  ]
[swing  name="でび縛り"  angle="7"  axis="181,0"  time="2000"  easing="sine"]

[tb_start_text mode=1 ]
#Unlock Character
[_tb_end_text]

[collect_character name="めだま"]

[comment  c="カメラ有効化"  ]
[memory name="cameraEnable" val="1"]

[eval exp="sf.albumEnable=1"]

[iscript]
// カメラ未解禁の場合はスキップボタンを移動する
$('.skip_button,.skipping').css('left', '916px')
[endscript]

[show_photo_button  visible="true"]

[comment  c="カメラ有効化"  ]
