[_tb_system_call storage=system/_kupya.ks]

[jump  storage="kupya.ks"  target="*talk"  ]
*modoru_hint

[eval exp="f.hintIdx++"]

[jump  target="modoru"  storage=""  ]
*modoru_oha

[eval exp="f.ohaIdx++"]

[jump  target="modoru"  storage=""  ]
*modoru

[tb_start_tyrano_code]
[if exp="f.kupya_owari >= 11"]
[_tb_end_tyrano_code]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/9.png"  ]
[tb_start_tyrano_code]
[else]
[_tb_end_tyrano_code]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_tyrano_code]
[endif]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
#Kupyadel
[if exp="f.kupya_owari >= 11"]Spipyaa~......[else]Is there anything else?[endif][wait time=300]
[_tb_end_text]

*modoru_tap

*talk

[eval exp="f.hintIdx=0" cond="isNaN(f.hintIdx)"]

[eval exp="f.ohaIdx=0" cond="isNaN(f.ohaIdx)"]

[guard_click]

[glink  storage="kupya.ks"  x="400"  y="145"  width="66"  height="127"  target="*mimiate"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="808"  y="145"  width="66"  height="127"  target="*mimiate"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="529"  y="3"  width="217"  height="89"  target="*wa"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="472"  y="93"  width="330"  height="130"  target="*atama"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="359"  y="247"  width="152"  height="185"  target="*mimi"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="762"  y="247"  width="152"  height="185"  target="*mimi"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="594"  y="320"  width="84"  height="68"  target="*beru"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="578"  y="381"  width="126"  height="112"  target="*onaka"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="477"  y="380"  width="81"  height="137"  target="*hane"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[glink  storage="kupya.ks"  x="721"  y="380"  width="81"  height="137"  target="*hane"  graphic="toumei.png"  size="0"  exp="dc.afterChoice2(false)"  ]
[if exp="f.currentLoop>=2"]

[choice2 text1="Talk" target1="*oha" text2="Ask&nbsp;for&nbsp;advice" target2="*zyo" y="500"]

[else]

[choice2 text1="Talk" target1="*oha" text2="???" disabled2="true" graphic2="disabled" y="500"]

[endif]

[glink  name="waku,waku3"  font_color="white"  target="*kaeru"  x="520"  y="680"  width="240"  height="57"  graphic="ui/kupya1.png"  enterimg="ui/kupya2.png"  enterse="tap.ogg"  clickse="OK.ogg"  exp="dc.afterChoice2(false)"  ]
[s  ]
*hane

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
An angel's wings are warm and soothing enough[r]to make you feel happy just by touching them, aren't they?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah!? Um... There aren't any strange[r]ingredients in them,[r]so please don't worry![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*mimi

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
These are my pride and joy--my fluffy,[r]squishy banana ears![r]They're emergency rations to share with hungry kids~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
That was a lie~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*atama

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyahh~♥[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I just love having my head patted~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But please don't touch my bangs too much, okay?[r]I set them carefully every morning~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*wa

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah... [p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
This halo is a precious gift from the Great Archangel[r]and means so much to me~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Without it, lesser angels like me[r]can't receive our mana supply.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*mimiate

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
This?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/5.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
These are earmuffs![r]They're quite fashionable among angels, you know~[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
Do they... suit me?
[_tb_end_text]

[choice2 text1="Nod" target1="*1" text2="..." target2="*2" y="500"]

[s  ]
*1

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
Pyaa~♥ [emb exp="f.name"], you have a good eye~[r]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*2

[tb_start_text mode=1 ]
#Kupyadel
In your heart, you're saying they suit me, aren't you?[r][if exp="f.currentLoop == 1]I may look like this, but I can use Evil Eye Scan, you know![else]My True Eye sees right through everything, you know![endif][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*beru

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="Bell.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Ring-a-ling~♪[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/5.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I gave you one of these, too, [emb exp="f.name"][r]They're called lily-of-the-valley bells~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Ring it, and I'll come running whenever you need me,[r]so please don't hesitate to use it![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*onaka

[tb_eval  exp="f.kupya_tap+=1"  name="kupya_tap"  cmd="+="  op="t"  val="1"  ]
[jump  storage="kupya_tap_no.ks"  target=""  cond="f.kupya_tap>6"  ]
[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya.ogg"  loop="false"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[wait  time="800"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah!?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
The eye in my belly is very delicate,[r]so please handle it with care![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...a stomach punch to Devilun[r]is a no-no, okay?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru"  ]
*oha

[call  storage="kupya_1.ks"  target="*oha"  cond="f.day==1"  ]
[call  storage="kupya_2.ks"  target="*oha"  cond="f.day==2"  ]
[call  storage="kupya_3.ks"  target="*oha"  cond="f.day==3"  ]
[jump  storage="kupya.ks"  target="*modoru_oha"  ]
*zyo

[iscript]
const hintAvailable = dc.hintAvailable(f, sf.endings)
if (hintAvailable.length == 0) {
f.hint = '_empty'
} else {
if (!hintAvailable[f.hintIdx]) {
f.hintIdx = 0
f.hintLooped = 1
}
f.hint = hintAvailable[f.hintIdx]
}
[endscript]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
A hint? Let's see...[if exp="f.hintLooped==1"][r]As I said before,[endif][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="&'END'+f.hint"  ]
*END_empty

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[jump  storage="kupya.ks"  target="*30_END"  cond="dc.endCount()>=dc.totalEndings()"  ]
[tb_start_text mode=1 ]
#Kupyadel
For now, I can't see any[r]clear hints in particular.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But I can see them faintly, so[r]please try checking another date.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*30_END

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'm sorry, but I can't see any[r]hint-like things anymore...[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END1

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Why not start by [font color=0xEC6FC5 bold=true]not signing a contract[resetfont] with Devilun[r]and see what happens? Hee hee.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
You know Devilun's [font color=0xEC6FC5 bold=true]true name[resetfont], don't you? Why not try[r][font color=0xEC6FC5 bold=true]calling him at another opportunity[resetfont]?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END3

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devilun has a weak spot, you know♥[r]Did you know that?[p]
How about [font color=0xEC6FC5 bold=true]rubbing it again and again[resetfont][r]for him? Hee hee.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END4

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Being diligent is all well and good,[r]but every now and then, Devilun could be[r][font color=0xEC6FC5 bold=true]left hanging[resetfont]... It's okay, you know?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
You're probably mentally worn out, too, so[r]in the meantime,[r][emb exp="f.name"], please get some rest.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Just don't give in to despair and drink[r][font color=0xEC6FC5 bold=true]wine[resetfont] like that teacher, then snore yourself to sleep.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END5

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah... I want a [font color=0xEC6FC5 bold=true]Devilun[r]plushie[resetfont], too~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END6

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.seibetu == 1]Why not use magic to become a [font color=0xEC6FC5 bold=true]girl[resetfont] for a change?[r]You might see things from a whole new perspective.[else]Hmm... Embrace love![endif][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=40][if exp="f.seibetu == 1]Embrace love~[else]Everyone has their own way of loving~[endif][resetfont][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=25]And... it might be rather fun to[r]try matching with me... Hee hee.[resetfont][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END7

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
You don't have to lay a hand on him...[r]but [font color=0xEC6FC5 bold=true]try threatening him[resetfont]--you might discover something![p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END8

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Even while time is stopped, [font color=0xEC6FC5 bold=true]keep fighting back[resetfont]![r]Cupyah, cupyah! Fight![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
The strength not to let others dictate your actions...[r]may be necessary sometimes.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END9

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Why not deliberately [font color=0xEC6FC5 bold=true]leave your mana below 100%[resetfont]?[r]I'm sure you'll get to see Devilun's angry face.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END10

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'll be blunt.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font color=0xEC6FC5 bold=true]Please cooperate with me[resetfont]♥[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END11

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Even in a false world created by someone else...[r]if you can be happy without realizing it,[r]I find myself thinking that might be enough.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/9.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
So if that's the path you want...[r]then you may [font color=0xEC6FC5 bold=true]choose not to cooperate with me[resetfont] after all.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END12

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Angels, demons, and fairies take physical form from mana,[r]so even when we're injured,[r]we can [font color=0xEC6FC5 bold=true]repair ourselves[resetfont] as long as we[r]have[r]enough mana, but...[p]

[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I wonder what happens to Devilun[r]if he doesn't have [font color=0xEC6FC5 bold=true]enough mana[resetfont] at a time like this.[r]Hee hee... I'm curious![p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END13

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Try pulling [font color=0xEC6FC5 bold=true]that thing of Devilun's[r]out for him[resetfont], please.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=40]It's a HORN![wait time=300]H[wait time=300]--ORN![resetfont][p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END14

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...When things get hard, you can[r]lean on me if you like.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
At times like that, [emb exp="f.name"], I'll[r]wrap you up in my proud, fluffy, squishy body![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...But [font color=0xEC6FC5 bold=true]don't touch me too much[resetfont]--that's a no-no~[p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END15

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Come to think of it, I've heard[r]that [font color=0xEC6FC5 bold=true]garlic[resetfont] is effective against demons...[r]Have you ever tried it?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END16

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I wonder what would happen if you[r][font color=0xEC6FC5 bold=true]didn't collect even 1% of your mana[resetfont]?[r]Cupyah![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END17

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Do you know what Devilun likes? According to my research,[r]he seems to like fluffy little ones with big, bright eyes~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
He can't [font color=0xEC6FC5 bold=true]leave someone like that alone[r]when[r]they're in trouble[resetfont][r]...he's such a kind soul~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Apparently, sexy older women aren't[r]his type~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END18

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.neodebi_nade == 1]Seeing Neo-Devilun's reaction reminded me...[r]When I patted Devilun's head in the past,[r]he looked terribly annoyed.[else]Long ago, when I patted Devilun's head, he said,[r]"Don't treat me like a child!"[r]...and made it clear he didn't like it.[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
That's when I learned that having one's head patted[r]isn't necessarily a pleasant experience.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
So let's get creative.[r]He might like it better if you [font color=0xEC6FC5 bold=true][r]touched[r]somewhere[r]other than his head[resetfont]![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
He might even snap, "There won't be a next time!"[r]though...[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END19

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'd love to pile lots of toppings onto Devilun's horns[r]and [font color=0xEC6FC5 bold=true]have a proper taste[resetfont], wouldn't you?[p]

[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah...? I'm giving perfectly[r]serious advice![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END20

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
When taking on something with a high danger rating,[r]it's better to keep some mana[r]in reserve, but...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Why not try going in with [font color=0xEC6FC5 bold=true]no mana at all[resetfont] for a change?[r]You might gain a whole new perspective.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END21

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devilun's [font color=0xEC6FC5 bold=true]Evil Eye is beautiful[resetfont], isn't it...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But they say eyes are being sold in[r]Magirisia's black market...[r]or so I've heard~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Eek, that's scary~[p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END22

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I think Devilun should [font color=0xEC6FC5 bold=true]interact with tiny bats[resetfont][r]more often~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END23

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If that [font color=0xEC6FC5 bold=true]wriggling tentacle[r]demon[resetfont] attacked me, I'd be utterly helpless![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Cupyah... I just remembered something from long ago...[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END24

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font color=0xEC6FC5 bold=true]Training[resetfont] and discipline are important, but...[r]it's important to relax and [font color=0xEC6FC5 bold=true]act silly[resetfont], too~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Ah, but don't taunt people, okay?[r]Especially [font color=0xEC6FC5 bold=true]crouch-spamming[resetfont]![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END25

[chara_show  name="クピャドエル"  time="1000"  wait="true"  storage="chara/14/11.png"  width="1280"  height="960"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If we both make full use of Devilun's Evil Eye[r]and [emb exp="f.name"]'s Magic Eye,[r]and [font color=0xEC6FC5 bold=true]cooperate[resetfont], the way forward should open on its own![p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*END33"  cond="sf.endings.includes('33')"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah...? And my True Eye can see another[r]possibility, too...[r]but it doesn't look like a very good one~[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...Still, I'll take the liberty of[r]offering some advice.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Please refrain from acting rashly simply because[r]the way isn't opening.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
If something were to take advantage of such a[r]wavering heart...[r]...I should say no more.[p]

[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END33

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...Just because you can start over,[r]please don't do anything cruel to Devilun.[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
Um...
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END26

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Would Devilun be happy if he lived in the [font color=0xEC6FC5 bold=true]Fountain of Souls[resetfont],[r]where the Spirit Gods reside?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END28

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/12.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
......[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I'm sorry, but [if exp="f.BBB_kidoku == 1"]the sight of Devilun being eaten[r][else]the sight of Devilun in his wedding clothes,[r]looking so sad,[r][endif]is burned vividly into my mind and won't leave me.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Back then, if I had stopped Devilun[r]without calling his [font color=0xEC6FC5 bold=true]true name[resetfont]...[r]would things have turned out better?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[emb exp="f.name"], you can try again.[r]So I can still... hold on to hope.[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
Cupyah... I mustn't let my smile fade.[r]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END27

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...If I [font color=0xEC6FC5 bold=true]failed to stop Devilun[resetfont]...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
No, I shouldn't let myself think so negatively.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END29

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Would Devilun be happy if he could [font color=0xEC6FC5 bold=true][r]get[r]married[resetfont][r]and experience love,[r]I wonder...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
People do say, "Start with the form," so...[r]I believe marriage is an important ritual in that respect~[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*END30

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/8.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.wedding_kidoku == 1"]Or, [else]Back then, [endif]if someone had reached out a hand and said[r][font color=0xEC6FC5 bold=true]"Let's be friends"[resetfont]...[r]would things have turned out differently?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*ENDundefined

[tb_start_text mode=1 ]
#Kupyadel
I'll think about it for a little while, so[r]please ask me again later.[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*complete

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Just where could Devilun possibly be saved?[r]In the Neo-Devilun era? Or after starting over once more?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Honestly... Devilun really is such a handful, isn't he?[p]
[_tb_end_text]

[jump  storage="kupya.ks"  target="*modoru_hint"  ]
*kaeru

[eval exp="f.hintIdx=0"]

[eval exp="f.ohaIdx=0"]

[eval exp="f.hintLooped=0"]

[tb_eval  exp="f.kupya_tap=0"  name="kupya_tap"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.kupya_owari=0"  name="kupya_owari"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If you ever need anything,[r]just call for me, Kupyadel, the Angel of Love.[p]
[if exp="f.kupya_inori == 1][delay speed=100]...[resetdelay]Cupyah~[r]I'll be taking my leave now.[else]Cupyah~[delay speed=100]...[resetdelay][r]May eternal happiness be yours.[delay speed=100]...[resetdelay][endif][p]

[_tb_end_text]

[stopbgm  time="1000"  fadeout="true"  ]
[playse  volume="100"  time="0"  buf="3"  storage="kupya_modoru.ogg"  ]
[flash  time="1000"  effect="fadeIn"  color="0xFFFFFF"  ]

[chara_hide_all  time="0"  wait="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[tb_filter_grayscale  layer="0"  ]
[wait  time="800"  ]
[free_bg_layermode name="ring" time="0"]

[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[playse  volume="100"  time="0"  buf="1"  storage="doa2.ogg"  ]
[free_bg_layermode name="ring" time="1000"]

[wait  time="500"  ]
[tb_hide_message_window  ]
[jump  storage="kupya.ks"  target="*day3"  cond="f.day==3"  ]
[jump  storage="syoukan.ks"  target="*back_from_kupya"  ]
*day3

[jump  storage="syoukan_k.ks"  target="*back_from_kupya"  ]
