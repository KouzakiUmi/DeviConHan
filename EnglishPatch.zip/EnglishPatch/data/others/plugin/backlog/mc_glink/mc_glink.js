// English patch: localize choice entries shown in the backlog.
// Based on the game's original mc_glink plugin.

;(function () {
  TYRANO.kag.tmp.memocho = TYRANO.kag.tmp.memocho || {}
  TYRANO.kag.tmp.memocho.log = TYRANO.kag.tmp.memocho.log || {}

  TYRANO.kag.tmp.memocho.log.glink_name = TYRANO.kag.stat.mp.log_name || ''
  TYRANO.kag.tmp.memocho.log.glink_mark =
    TYRANO.kag.stat.mp.glink_mark ||
    TYRANO.kag.stat.mp.mark ||
    TYRANO.kag.tmp.memocho.log.mark ||
    ':'

  if (typeof window.MEMOCHO === 'undefined') window.MEMOCHO = {}

  MEMOCHO.glink_log = function (pm) {
    if (!pm.text) return

    let log_text = ''
    const rawName = pm.log_name || TYRANO.kag.tmp.memocho.log.glink_name
    const name = rawName === '選択' ? 'Choice' : rawName
    let mark = pm.mark || TYRANO.kag.tmp.memocho.log.glink_mark

    if (name) {
      if (mark) mark = ' data-mark="' + mark + '"'
      log_text =
        '<b class="backlog_chara_name glink" ' + mark + '>' + name + '</b>'
    }

    log_text += '<span class="backlog_text glink">' + pm.text + '</span>'

    TYRANO.kag.stat.log_write &&
      TYRANO.kag.variable.tf.system.backlog.push(log_text)
  }
})()
