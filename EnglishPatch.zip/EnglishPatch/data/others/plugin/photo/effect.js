TYRANO.kag.dc = {
  ...TYRANO.kag.dc,
  photoEffects: () => [
    {},
    {
      name: 'Lovey-dovey',
      file: 'lovelove',
      mode: 'screen',
    },
    {
      name: 'Heart',
      file: 'heart',
      mode: 'color-dodge',
    },
    {
      name: 'Sparkle',
      file: 'kirakira',
      mode: 'color-dodge',
    },
    {
      name: 'Fluffy',
      file: 'howahowa',
      mode: 'screen',
    },
    {
      name: 'Focus lines',
      file: 'syuutyuu',
      mode: 'screen',
    },
    {
      name: 'Rainbow',
      file: 'rainbow',
      mode: 'color-dodge',
    },
    {
      name: 'Refreshing',
      file: 'sawayaka',
      mode: 'color-dodge',
    },
  ],
}
