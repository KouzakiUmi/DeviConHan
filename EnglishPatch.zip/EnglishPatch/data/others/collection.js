/**
 * name: 名前
 * no: アイコン番号（data/image/collection_chara/icon 参照）
 * description: 説明
 * sex: 性別（1: オス、2: メス、3: 両性、4: 不明）
 * breed: 種族
 * category: カテゴリ（'beast' / 'fairy' / 'demon' / 'debirun'）
 * alts: 表情差分数（差分を追加したらここも増やすこと）
 */
TYRANO.kag.dc = {
  ...TYRANO.kag.dc,
  collectionCharaData: () => [
    {
      name: 'リリカ',
	  zh_name:'Ririka',
      no: '01',
      description:
        'An always-upbeat gyaru. Designer for the fashion brand "SAVANNA," with impeccable taste. She believes she came from space.',
      sex: 2,
      breed: 'Giraffe',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ペイン',
	  zh_name:'Payne',
      no: '02',
      description:
        'A lively prince of a kingdom.<br>He sneaks out of the castle and loves munching on his favorite baguette while having adventures.<br>He\'s a bit bad at studying.',
      sex: 1,
      breed: 'Fennec',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ティング',
	  zh_name:'Ting',
      no: '03',
      description:
        'A modest and quiet prince of a nation.<br>He is Payne\'s brother. Since childhood, he has had a frail constitution and is confined to the castle. He excels at ice magic and magical pharmacology.',
      sex: 1,
      breed: 'Fennec',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ジェクト',
	  zh_name:'Ject',
      no: '04',
      description:
        'An electronic-power modeler who can copy and manipulate people or objects. He\'s confident and otaku-ish, gets breathless at the drop of a hat, and tends to wet himself when he\'s too absorbed in his work.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'アリス',
	  zh_name:'Alice',
      no: '05',
      description:
        'A girl researching magical pharmacology.<br>Her hobby is collecting rare mushrooms. Surly, but she can\'t resist fluffy things.<br>Quite the taskmaster.',
      sex: 2,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'コハク',
	  zh_name:'Kohaku',
      no: '06',
      description:
        'A mischievous nine-tailed fox. Can shapeshift freely. Usually sealed in the killing stone on their forehead. Dislikes eggplant.',
      sex: 4,
      breed: 'Fox',
      category: 'beast',
      alts: 6,
    },
    {
      name: 'アルマース',
	  zh_name:'Almaz',
      no: '07',
      description:
        'A cool musician in daily life. Received elite education from a young age, and his piano skills are top-notch. But unfortunately, he\'s an extreme womanizer. Harsh on men.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ライ',
	  zh_name:'Rai',
      no: '08',
      description:
        'A timid crybaby boy who trains hard to become stronger. He can call down lightning only in moments of absolute peril. His favorite food is fried shrimp.',
      sex: 1,
      breed: 'Lion',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ラピス',
	  zh_name:'Lapis',
      no: '09',
      description:
        'A part-time instructor at Solciere Magic Academy. From a family of great mages, he can use magic that stops time for a few seconds.<br>Has a sweet tooth and loves cocoa.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'サフィール',
	  zh_name:'Saphir',
      no: '10',
      description:
        'A narcissistic noble youth. Though a swordsman, he dislikes sweating, so he avoids fighting. He often stays at a villa in the south.<br>Popular enough to have a fan club.',
      sex: 1,
      breed: 'Horse',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'マルス',
	  zh_name:'Mars',
      no: '11',
      description:
        'A new teacher at Solciere Magic Academy. Kind-hearted and caring toward students, but lacks confidence and tends to think negatively. Often relies on alcohol and becomes a crying drunk.',
      sex: 1,
      breed: 'Rabbit',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ネゼル',
	  zh_name:'Nesseru',
      no: '12',
      description:
        'A friendly bird-handling lady. Born with the Evil Eye, she has the ability to converse with monsters. Loves her partner, the mahorou Hololu, and her husband Guman.',
      sex: 2,
      breed: 'Wolf',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ルナ',
	  zh_name:'Luna',
      no: '13',
      description:
        'A moon-ring dolphin girl living in an undersea kingdom. Curious by nature, with a habit of putting anything in her mouth. Loves her husband, the shark Sharky.',
      sex: 2,
      breed: 'Dolphin',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'フウガ',
	  zh_name:'Fuuga',
      no: '14',
      description:
        'A tiger boy who uses dual swords. He trains every day with his familiar, the Wind Fairy Sylphy. He looks cool at first glance, but he\'s actually shy and a bit absent-minded.',
      sex: 1,
      breed: 'Tiger',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'チェシカ',
	  zh_name:'Cheshika',
      no: '15',
      description:
        'A chatty, silly clown. Alice\'s test subject and errand boy. He\'s afraid of water and doesn\'t bathe, so his tail smells a bit.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'マキ',
	  zh_name:'Maki',
      no: '16',
      description:
        'A journalist who publishes the \'Arcan News\' throughout Magirisia. Always moving quickly around various places for scoops. \'Wow!\' is her catchphrase. Childhood friend of Connie.',
      sex: 2,
      breed: 'Ring-tailed lemur',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ミーティア',
	  zh_name:'Meteor',
      no: '17',
      description:
        'A first-year at Solciere Magic Academy. Not good at using magic, and for now can only produce a small star-shaped light. Has a habit of speaking in broken phrases.',
      sex: 2,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'コニー',
	  zh_name:'Connie',
      no: '18',
      description:
        'A police dog who patrols for the Magic Police. Polite and dedicated to her work, but a clumsy troublemaker. Poor eyesight, but a very sharp sense of smell.',
      sex: 2,
      breed: 'Dog',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'エメロード',
	  zh_name:'Emeraude',
      no: '19',
      description:
        'A kind-hearted young nobleman... but he dotes on his little sister Hisui to an extreme degree, a total sis-con. He\'s good at cooking and prepares meals without relying on the mansion\'s servants.',
      sex: 1,
      breed: 'Dog',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'アレン',
	  zh_name:'Allen',
      no: '20',
      description:
        'A goody-two-shoes rabbit boy. Despite appearances, he\'s the eldest of four siblings, responsible and polite. He\'s troubled by his two-faced nature.',
      sex: 1,
      breed: 'Rabbit',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ミンティ',
	  zh_name:'Minty',
      no: '21',
      description:
        'A pastry chef working at the Western confectionery shop "Chocolagne." Skilled at making sweets with mint. Her motto is "If they hit you, hit back."',
      sex: 2,
      breed: 'Rabbit',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ガク',
	  zh_name:'Gakuloid',
      no: '22',
      description:
        'A super robot powered by magical science that converts mana into electricity inside his body. He can also ingest food, but recharging via the cable in his tail is most efficient.',
      sex: 1,
      breed: 'Robot',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'パンプティ',
	  zh_name:'Pampty',
      no: '23',
      description:
        'A mysterious boy skilled in pantomime. Lately, he\'s been working hard to find new acts, and he\'s really into hypnotism. He sees Cheshika as a rival. He loves egg dishes.',
      sex: 1,
      breed: 'Lizard',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ルビー',
	  zh_name:'Ruby',
      no: '24',
      description:
        'A wicked and ruthless noble youth. Always walks with his servant bat. Once angered, he\'s a violent brute who won\'t stop. A mama\'s boy who swears loyalty to his mother.',
      sex: 1,
      breed: 'Tiger',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ジュエリーピンク',
	  zh_name:'Jewelry Pink',
      no: '25',
      description:
        'A maid serving Saphir. Skilled at his work, a formidable fighter, and a master of the Kamamaki Kick. Loves Saphir more than anything in this world. Smells of perfume.',
      sex: 1,
      breed: 'Horse',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ガウルォス',
	  zh_name:'Gawuros',
      no: '26',
      description:
        'A masked wolf who usually acts the fool.<br>Has the Evil Eye, granting the ability to peer into others\' memories. Fuuga\'s master, and together they wander the lands of Magirisia.',
      sex: 1,
      breed: 'Wolf',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ラミア',
	  zh_name:'Lamia',
      no: '27',
      description:
        'A girl from a family of sorcerers who sealed a Western dragon. She never stops smiling, but she\'s short-tempered and her attitude changes drastically when angry. She likes to burn monsters alive and eat them.',
      sex: 2,
      breed: 'Snake',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ピーター',
	  zh_name:'Peter',
      no: '28',
      description:
        'Guardian of the Fountain of Souls, a sanctuary where demon gods dwell. As a child, wandered into the fountain\'s forest and now lives surrounded by friend Belbel and the demon gods.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'クピャドエル',
	  zh_name:'Kupyadel',
      no: '01',
      description:
        'An angel who keeps their eyes closed at all times, as if hiding their true heart. The eye on their belly is unstable, but it has the power to see through to the truth. Their hobby is binding. They refer to themself as \'watakushi\'.',
      sex: 3,
      breed: 'Angel of Love',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'でかクピャ',
	  zh_name:'Big Cupya',
      no: '02',
      description:
        'A form grown by gaining mana. Prone to self-loathing over impulses unbefitting an angel, with a habit of hiding true feelings. Has a scar on the neck given by Devilun. First person: Boku.',
      sex: 3,
      breed: 'Angel of Love',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'シルフィ',
	  zh_name:'Sylphy',
      no: '03',
      description:
        'Fuuga\'s contracted fairy. The scarf he received at the time of the contract is his treasure. His dream is to one day gain power and grow big. He loves the handmade rice balls Fuuga makes.',
      sex: 1,
      breed: 'Wind Fairy',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'ベルベル',
	  zh_name:'Belbel',
      no: '04',
      description:
        'Peter\'s contracted fairy. She sheltered young Peter as he wandered the forest of trees, showing her caring nature. Her dream is to one day become a Great Fairy like Lady Fairydou.',
      sex: 2,
      breed: 'Bell Fairy',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'ムゥムゥ',
	  zh_name:'MuuMuu',
      no: '05',
      description:
        'A jeweler running a magic stone shop. Can assume true form using mana stored in a lamp. Can\'t resist expensive treasures. Catchphrase: Genius!',
      sex: 1,
      breed: 'Lamp Fairy',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'ミカエル',
	  zh_name:'Michael',
      no: '06',
      description:
        'The archangel who leads the Celestial Army. They can see through the eyes of all angels. They value justice, order, and fairness, and watch over Magirisia.',
      sex: 4,
      breed: 'Archangel',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'BBB',
	  zh_name:'BBB',
      no: '01',
      description:
        'A chimera of a fly and a termite. Since developing a taste for fine food, he\'s been gentle, but food-related stimulation brings out his gluttonous form, Gluttony, and sends him on a rampage.',
      sex: 1,
      breed: 'Demon of Gluttony',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'あもあも',
	  zh_name:'Amoamo',
      no: '02',
      description:
        'A chimera of a sea angel, sea hare, and scorpion. They can inject various toxins from their tail, are free-spirited, like to meddle and fuss over others, and hate ugly things.',
      sex: 3,
      breed: 'Demon of Lust',
      category: 'demon',
      alts: 9,
    },
    {
      name: 'ナザール',
	  zh_name:'Nazar',
      no: '03',
      description:
        'A chimera of sea snake, reindeer, crow, and dog. Self-conscious about his face, he hides it with bangs. Jealous and doesn\'t talk to anyone. Likes blueberries.',
      sex: 1,
      breed: 'Demon of Envy',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'マネコ',
	  zh_name:'Maneko',
      no: '04',
      description:
        'A former low-ranking cat demon. Having experienced extreme poverty, she still can\'t shake her penny-pinching habits. She oversees trade between the Human Realm and the Demon Realm.',
      sex: 2,
      breed: 'Demon of Greed',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'D・Red',
	  zh_name:'D Red',
      no: '05',
      description:
        'A chimera of a dragon and a pangolin. His body is ironclad, and he constantly uses evil god abilities to turn his insides into an arsenal. An extreme military maniac, especially fond of tanks.',
      sex: 1,
      breed: 'Demon of Wrath',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'ハーデスター',
	  zh_name:'Hadester',
      no: '06',
      description:
        'The fallen form of Archangel Lucifer. They consider death a salvation and have become a reaper who harvests lives to create a cycle of happiness. They call the Summoner \'King\' and worship them.',
      sex: 4,
      breed: 'Fallen Angel of Pride',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'クピデル',
	  zh_name:'Cupidel',
      no: '07',
      description:
        'Kupyadel\'s fallen form. Even if it\'s a false happiness, it\'s considered salvation, and if you\'re gazed upon by those eyes, your soul is trapped in a false paradise, and your body becomes a living corpse and rots away.',
      sex: 3,
      breed: 'Fallen Angel of Vanity',
      category: 'demon',
      alts: 1,
    },
    {
      name: 'ココヨ',
	  zh_name:'Kokoyo',
      no: '08',
      description:
        'A bat-type lower-class demon. Good at flattering, but tends to blurt out true feelings. At an age where she worries about being provincial.',
      sex: 2,
      breed: 'Weak Bat',
      category: 'demon',
      alts: 3,
    },
    {
      name: 'ザッス',
	  zh_name:'Zass',
      no: '09',
      description:
        'A bat-type lower-class demon. Bad at flattering and says everything honestly. Loves to eat.',
      sex: 1,
      breed: 'Weak Bat',
      category: 'demon',
      alts: 3,
    },
    {
      name: '  ',
	  zh_name:'  ',
      no: '00',
      description:
        'The form of a god encountered when failing to stop without calling the true name. They dislike having their name defined. They have a habit of counting from zero.',
      sex: 4,
      breed: '  ',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'ザコでび',
	  zh_name:'Zako Devi',
      no: '01',
      description:
        'The form of a bat lower-class demon. When mana is extremely depleted, he reverts to this form. It\'s the most common demon race and is weak in winter.',
      sex: 1,
      breed: 'Demon of Sloth',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'でびるん',
	  zh_name:'Devilun',
      no: '02',
      description:
        'A small form lacking mana. Lazy and prone to slacking off. Easily influenced and swept along by others. Catchphrase: dagya-. First person: Oresama.',
      sex: 1,
      breed: 'Demon of Sloth',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'デカでび',
	  zh_name:'Big Devi',
      no: '03',
      description:
        'The true form grown by gaining mana. Demon Realm dialect fades, first person becomes Oresama. Likes raspberry pie and Abracadabra-men. Nicknamed Bel by demons.',
      sex: 1,
      breed: 'Demon of Sloth',
      category: 'debirun',
      alts: 6,
    },
    {
      name: 'ネオでびるん',
	  zh_name:'Neo Devilun',
      no: '04',
      description:
        'The new form that gathered all the mana in Magirisia. Their will has been taken over by the Evil Eye, and they have almost no senses other than sight. The face on their head is now just a decoration.',
      sex: 4,
      breed: 'Sloth Demon King',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'べるるん',
	  zh_name:'Belrun',
      no: '05',
      description:
        'A form created by calling his true name and forcibly making him fall into the light. Wrapped in a white wedding dress, his horns are bleached pure white. He\'d probably look good in a cow bikini too.',
      sex: 1,
      breed: 'Demon of Sloth',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'めだま',
	  zh_name:'Eyeball',
      no: '06',
      description:
        'The form of the core that succeeded in stopping without calling the true name. With tears of regret in their eyes, they wither away in the warm hands of the Summoner at the end. Even if you realize it now, it\'s too late.',
      sex: 4,
      breed: 'Devilun',
      category: 'debirun',
      alts: 3,
    },
  ],
  collectionCharaNames: function (category) {
    return this.collectionCharaData()
      .filter(c => c.category == category && c.no != '00') // 00だけ除外する（特殊表示）
      .map(c => c.name)
  },
  collectionChara: function (name) {
    return this.collectionCharaData().find(c => c.name === name)
  },
  collectionCharaCategoryData: function () {
    return ['beast']
      .concat(
        this.allCharasOpenInCollection() ? ['fairy', 'demon', 'debirun'] : []
      )
      .map(name => ({
        name,
        text: $.lang('collection')['chara'][name],
      }))
  },
  collectionCharaCategoryNames: function () {
    return this.collectionCharaCategoryData().map(c => c.name)
  },
  collectionCharaCategory: function (name) {
    return this.collectionCharaCategoryData().find(c => c.name === name)
  },
  allCharasOpenInCollection: function () {
    const { collectedCharacters } = TYRANO.kag.variable.sf
    return collectedCharacters.includes('ムゥムゥ')
  },
  characterCount: function () {
    const { allCharactersOpen, characters } = TYRANO.kag.variable.sf
    if (allCharactersOpen) return characters.filter(c => c != '  ').length

    const allNames = this.collectionCharaNames('beast')
    return characters.filter(c => allNames.includes(c)).length
  },
  collectedCharacterCount: function () {
    const { collectedCharacters } = TYRANO.kag.variable.sf
    if (this.allCharasOpenInCollection())
      return collectedCharacters.filter(c => c != '  ').length

    const beasts = this.collectionCharaNames('beast')
    return collectedCharacters.filter(c => beasts.includes(c)).length
  },
  totalCharacters: function () {
    const charas = TYRANO.kag.dc.collectionCharaData()
    const available = TYRANO.kag.variable.sf.allCharactersOpen
      ? charas.filter(c => c.name != '  ')
      : charas.filter(c => c.category == 'beast')
    return available.length
  },
  collectedTotalCharacters: function () {
    const charas = TYRANO.kag.dc.collectionCharaData()
    if (this.allCharasOpenInCollection())
      return charas.filter(c => c.name != '  ').length

    return charas.filter(c => c.category == 'beast').length
  },
}
;(function () {
  TYRANO.kag.variable.sf.characters = Array.from(
    new Set(
      TYRANO.kag.variable.sf.characters.map(c =>
        c == 'D・RED' ? 'D・Red' : c,
      ),
    ),
  )
  TYRANO.kag.variable.sf.collectedCharacters = Array.from(
    new Set(
      TYRANO.kag.variable.sf.collectedCharacters.map(c =>
        c == 'D・RED' ? 'D・Red' : c,
      ),
    ),
  )
})()
