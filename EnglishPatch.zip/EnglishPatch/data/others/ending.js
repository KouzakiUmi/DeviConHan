TYRANO.kag.dc = {
  ...TYRANO.kag.dc,
  _ends: function () {
    const { f } = TYRANO.kag.stat,
      { sf } = TYRANO.kag.variable
    return {
      1: {
        category: 'normal',
        title: 'Speedrunner of Defeat',
        phrase: 'Are you doing a<br>speedrun of losing?<br>Are you stupid<br>or what?',
        timing: 'Devilun summoning scene',
        cond: 'Don\'t make a contract with Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 1,
      },
      2: {
        category: 'normal',
        title: 'Name of the Demon of Sloth',
        phrase: 'We just met,<br>what the heck<br>are you?!',
        timing: 'Devilun summoning scene',
        cond: 'When introducing yourself as a Summoner, say Devilun\'s true name.',
        hintCond: f =>
          f.currentLoop >= 1 &&
          f.day >= 0 &&
          (f.bel_name >= 1 || f.bel_name_first >= 1),
        bgType: 2,
      },
      3: {
        category: 'normal',
        title: 'Sensitive horns...♥',
        phrase: 'You knocked me out!<br>Don\'t touch my horns<br>again!',
        timing: 'Character selection scene',
        cond: 'Keep poking Devilun\'s horns',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 3,
      },
      4: {
        category: 'normal',
        title: 'Good Night Devilun',
        phrase: `Let's just call it<br>a night,<br>${f.name}.`,
        timing: 'Character selection scene',
        cond: 'Leave Devilun alone for a while',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 1,
      },
      5: {
        category: 'normal',
        title: 'Alice\'s plushie',
        phrase: 'Just hand it over.<br>As if! You idiot!!',
        timing: 'Day 0: Alice',
        cond: 'Give Alice the plushie-fied Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 0,
        bgType: 3,
      },
      6: {
        category: 'normal',
        title: 'Oops... I messed up.',
        phrase: 'Sorry for<br>interrupting.<br>...Enjoy yourself.',
        timing: 'Day 0: Almaz',
        cond: 'Connect with Almaz while in female form.',
        hintCond: f => f.currentLoop >= 2 && f.day >= 0,
        bgType: 1,
      },
      7: {
        category: 'normal',
        title: 'Desperate Thunder',
        phrase: '*cough*...<br>That tingling sensation...<br>What on earth just happened...!?',
        timing: 'Day 0: Rai',
        cond: 'Threaten Rai with a knife',
        hintCond: f => f.currentLoop >= 2 && f.day >= 0,
        bgType: 2,
      },
      8: {
        category: 'normal',
        title: 'Russian Joke',
        phrase: 'Dagya...?<br>W-What happened?',
        timing: 'Day 0: Lapis',
        cond: 'Disobey Lapis',
        hintCond: f => f.currentLoop >= 3 && f.day >= 0,
        bgType: 1,
      },
      9: {
        category: 'normal',
        title: 'Mana deficiency...',
        phrase: 'If you can\'t even<br>gather this much,<br>you\'re disqualified<br>as a familiar.',
        timing: 'MP check',
        cond: 'Mana has not reached 100% after finishing connections for 3 characters.',
        hintCond: f => f.currentLoop >= 1 && f.day >= 1,
        bgType: 1,
      },
      10: {
        category: 'normal',
        title: 'Angel Punching Bag',
        phrase: 'What a terrible<br>hobby you\'ve got!',
        timing: 'Day 0: Bedroom',
        cond: 'Kupyadel catches Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 1,
        bgType: 3,
      },
      11: {
        category: 'normal',
        title: 'Artificial happiness',
        phrase: 'Don\'t brainwash me!<br>This is fake<br>happiness!',
        timing: 'Day 0: Bedroom',
        cond: 'Refuse to cooperate when Kupyadel suggests working together.',
        hintCond: f => f.bel_name || f.bel_name_first,
        bgType: 2,
      },
      12: {
        category: 'normal',
        title: 'Irreparable',
        phrase: 'No mana...<br>Dagya...',
        timing: 'Day 1: Fuuga',
        cond: 'Not enough MP to repair the wound.',
        hintCond: f => f.currentLoop >= 2 && f.day >= 1,
        bgType: 2,
      },
      13: {
        category: 'normal',
        title: 'Horn removal!★',
        phrase: 'You\'ve gone and<br>made my body<br>unable to recover<br>mana!',
        timing: 'Day 1: Cheshika',
        cond: 'Have Cheshika pull out Devilun\'s horns',
        hintCond: f => f.currentLoop >= 2 && f.day >= 1,
        bgType: 2,
      },
      14: {
        category: 'normal',
        title: 'Angel\'s Salvation',
        phrase: 'That guy\'s gone...<br>Where\'d he run<br>off to?',
        timing: 'Conversation with Kupyadel',
        cond: 'Pester Kupyadel persistently',
        hintCond: f => f.currentLoop >= 1 && f.day >= 1,
        bgType: 1,
      },
      15: {
        category: 'normal',
        title: 'Demon Hiding in the Toilet',
        phrase: 'Garlic is no good<br>in this form...<br>not at all...',
        timing: 'Day 1: Bedroom',
        cond: 'Choose "Extra-Garlic Ramen" for a midnight snack with Devilun',
        hintCond: f => f.currentLoop >= 1 && f.day >= 2,
        bgType: 2,
      },
      16: {
        category: 'normal',
        title: 'Return to the Demon Realm',
        phrase: 'I\'m heading back<br>to the Demon Realm.<br>...I\'ll remember this.',
        timing: 'MP check (from day 2 onward)',
        cond: 'Mana is at 0% after finishing connections for 3 characters.',
        hintCond: f => f.currentLoop >= 1 && f.day >= 2,
        bgType: 1,
      },
      17: {
        category: 'normal',
        title: 'Defeat by Law',
        phrase: 'What are you<br>getting arrested for,<br>you idiot?!',
        timing: 'Day 2: Connie',
        cond: 'Lend Connie a hand',
        hintCond: f => f.currentLoop >= 1 && f.day >= 2,
        bgType: 2,
      },
      18: {
        category: 'normal',
        title: 'Landmine Player',
        phrase: 'Why\'s this gotta<br>spill over onto me<br>too?',
        timing: 'Day 2: Allen',
        cond: 'Make Allen angry twice',
        hintCond: f => f.currentLoop >= 2 && f.day >= 2,
        bgType: 2,
      },
      19: {
        category: 'normal',
        title: 'Naughty Mint',
        phrase: 'Dagyaaah! My horns--!<br>Stop sucking on<br>my horns!',
        timing: 'Day 2: Minty',
        cond: 'Lick the Cymint cream',
        hintCond: f => f.currentLoop >= 2 && f.day >= 2,
        bgType: 3,
      },
      20: {
        category: 'normal',
        title: 'Explosive Endings Are the Best.',
        phrase: 'No way.<br>Drop dead!',
        timing: 'Day 2: Gakuloid',
        cond: 'Press Gakuloid\'s self-destruct switch',
        hintCond: f => f.currentLoop >= 2 && f.day >= 2,
        bgType: 2,
      },
      21: {
        category: 'normal',
        title: 'Eyeball Collector',
        phrase: 'Dagya!!!!! My eyes...!<br>My eyyyes!',
        timing: 'Day 3: MuuMuu',
        cond: 'Get your eyeballs stolen by MuuMuu',
        hintCond: f => f.currentLoop >= 1 && f.day >= 3,
        bgType: 2,
      },
      22: {
        category: 'normal',
        title: 'Impaled bat',
        phrase:
          f.ruby === 1
            ? 'You weakling<br>low-class demons...<br>I hate those idiots!'
            : f.ruby === 2
          ? sf.censorship
            ? 'You didn\'t have to ■ them<br>all at once...<br>Damn it.'
            : 'You didn\'t have to kill<br>them all at once...<br>Damn it.'
            : f.ruby === 3
            ? 'It\'s those weak<br>demons clinging<br>to me<br>that\'s the problem!'
            : f.ruby === 4
            ? 'He\'s so ready<br>to snap,<br>no need for<br>provocation magic...'
            : '',
        timing: 'Day 3: Ruby',
        cond: 'Offend Ruby',
        hintCond: f => f.currentLoop >= 1 && f.day >= 3,
        bgType: 2,
      },
      23: {
        category: 'normal',
        title: 'Happy End♥',
        phrase: 'This isn\'t happy<br>at all...',
        timing: 'Day 3: Amoamo',
        cond: 'Succumb to Amoamo\'s temptation',
        hintCond: f => f.currentLoop >= 2 && f.day >= 3,
        bgType: 3,
      },
      24: {
        category: 'normal',
        title: 'Let\'s stop provoking!',
        phrase: 'Provoking, you know!<br>...Can\'t stop,<br>right? ♥',
        timing: 'Day 3: Gawuros',
        cond: 'Don\'t take Gawuros\'s training seriously',
        hintCond: f => f.currentLoop >= 2 && f.day >= 3,
        bgType: 1,
      },
      25: {
        category: 'normal',
        title: 'One who burns with anger',
        phrase: `Gyaaah, it's hot!<br>It burns, ${f.name}!`,
        timing: 'Day 3: Lamia',
        cond: 'Be burned by Lamia\'s hellfire',
        hintCond: f => f.currentLoop >= 2 && f.day >= 3,
        bgType: 2,
      },
      26: {
        category: 'normal',
        title: 'Peter, Hero of the Spring',
        phrase: 'Dagyagyagyagya!<br>My tail isn\'t sealed<br>yet!',
        timing: 'Day 3: Peter',
        cond: 'Call Devilun\'s true name and order him to help Peter',
        hintCond: f => f.currentLoop >= 3 && f.day >= 3,
        bgType: 2,
      },
      27: {
        category: 'normal',
        title: 'Neo Universe',
        phrase: '',
        timing: 'Day 3: Finale',
        cond: 'Fail to stop Neo Devilun',
        hintCond: f => f.currentLoop >= 2,
      },
      28: {
        category: 'normal',
        title: 'Deep, deep regret',
        phrase: '',
        timing: 'Day 3: Finale',
        cond: 'Stop Neo Devilun',
        hintCond: f => f.currentLoop >= 2,
      },
      29: {
        category: 'normal',
        title: 'There\'s no such thing as a happy marriage.',
        phrase: 'How could this<br>possibly be<br>happiness?!',
        timing: 'Day 3: Finale',
        cond: 'Call Devilun\'s true name and command him to marry you',
        next: 'Chapter4_wedding2.ks',
        hintCond: f => f.currentLoop >= 2,
        bgType: 3,
      },
      30: {
        category: 'normal',
        title: 'Forget everything',
        timing: 'Day 3: Finale',
        cond: 'Call Devilun\'s true name and command him to become your friend',
        hintCond: f => f.currentLoop >= 2,
      },
      31: {
        category: 'secret',
        title: 'Blue Exorcist',
        phrase: this.aibou()
          ? 'The bath temperature<br>is just right!?<br>What are you after,<br>you!?!?'
          : 'Summoning a demon<br>to <span style="font-family:KaiseiDecol-Bold">exorcise</span>?<br>Is that even<br>allowed?',
        timing: 'Day 0: Summoning Devilun',
        cond: 'When introducing yourself as a Summoner in the early loops, say Devilun\'s true name.',
        bgType: 2,
      },
      32: {
        category: 'secret',
        title: 'Boron★',
        phrase: 'The world is...<br>wide, you know...',
        timing: 'Day 0: Almaz',
        cond: sf.censorship
          ? 'In a ■ state, connecting with Almaz.'
          : 'In a futanari state, connecting with Almaz.',
        bgType: 1,
      },
      33: {
        category: 'secret',
        title: 'Trauma of Hellfire',
        phrase: `Gyaaah, it's hot!<br>It burns, ${f.name}!`,
        timing: 'Day 3: Lamia',
        cond: 'Try to become Lamia\'s familiar',
        bgType: 0,
      },
      34: {
        category: 'secret',
        title: 'Demon Belphegor',
        timing: 'Day 3: Peter',
        cond: sf.censorship
          ? 'Devilun ■s Peter.'
          : 'Devilun kills Peter.',
      },
      35: {
        category: 'secret',
        title: sf.censorship ? '■... it\'s done.' : 'He\'s dead...',
        timing: 'Day 3: Finale',
        cond: 'Give Kupyadel a custard pie',
      },
      36: {
        category: 'secret',
        title: 'Angel of Vanity',
        timing: 'Day 3: Finale',
        cond: 'Forget to give Kupyadel a custard pie',
      },
      37: {
        category: 'secret',
        title: 'A happy marriage ♥',
        timing: 'Day 3: Finale',
        cond: 'Obtain the ring, call Devilun\'s true name, and command them to marry you.',
      },
      38: {
        category: 'secret',
        title: 'Gluttony Mode ON',
        phrase: `Haven't seen this<br>side of Bub in<br>ages...<br>Wait, it's eating the<br>house?!?!`,
        timing: 'Connection with a demon',
        cond: 'Give fish and chips to BBB',
        bgType: 2,
      },
      39: {
        category: 'secret',
        title: 'Bound! Angel of the Demon Realm',
        phrase: `W-What am I being<br>shown here...<br>This is too much for<br>me...`,
        timing: 'Connection with a demon',
        cond: 'Watch Kupyadel and Amoamo',
        bgType: 2,
      },
      40: {
        category: 'secret',
        title: 'Jealousy Digs Its Own Grave',
        phrase: `You jealous of<br>yours truly?<br>Heh heh heh, serves<br>you right.`,
        timing: 'Connection with a demon',
        cond: 'Pointing a mirror at Nazar and receiving the Evil Eye of Envy',
        bgType: 1,
      },
      41: {
        category: 'secret',
        title: 'Penniless House',
        phrase: `...Tough break.`,
        timing: 'Connection with a demon',
        cond: 'Fail to see through Maneko\'s mimicry',
        bgType: 1,
      },
      42: {
        category: 'secret',
        title: 'Explosive Punchline 2',
        phrase: `What the hell is<br>a 2?! That's the<br>worst!<br>Drop dead!`,
        timing: 'Connection with a demon',
        cond: 'Cast alcohol magic on D Red',
        bgType: 2,
      },
      43: {
        category: 'secret',
        title: 'Grim Reaper\'s Salvation',
        phrase: `What was that just<br>now?!<br>That was pure force<br>majeure!`,
        timing: 'Connection with a demon',
        cond: 'Summon Hadester',
        bgType: 2,
      },
      44: {
        category: 'secret',
        title: 'Forced Deportation to the Demon Realm',
        phrase: `We're home!<br>Honey, I'm back!<br>Like hell I am,<br>damn it!`,
        timing: 'Connection with a demon',
        cond: 'Command Devilun "House"',
        bgType: 3,
      },
      45: {
        category: 'secret',
        title: 'Case closed★',
        phrase: `That Doel bastard...<br>You better reflect<br>on what you did!`,
        timing: 'Connection with a demon',
        cond: 'Complete the connection with a demon.',
        next: 'Devil_Chapter3.ks',
        bgType: 2,
      },
    }
  },
  endKeys: function (category) {
    return Object.entries(this._ends())
      .filter(([_, e]) => e.category == category)
      .map(([key, _]) => key)
  },
  end: function (no) {
    return this._ends()[no]
  },
  hintAvailable: function (f, seen) {
    return Object.entries(this._ends())
      .filter(
        ([key, end]) => !seen.includes(key) && end.hintCond && end.hintCond(f)
      )
      .map(([key, _]) => key)
  },
  endCategoryData: () => [
    {
      name: 'normal',
      text: $.lang('collection')['ending']['normal'],
    },
    {
      name: 'secret',
      text: $.lang('collection')['ending']['secret'],
    },
  ],
  endCategoryNames: function () {
    const available = this.secretEndOpenInCollection()
      ? this.endCategoryData()
      : this.endCategoryData().filter(e => e.name == 'normal')
    return available.map(c => c.name)
  },
  endCategory: function (name) {
    return this.endCategoryData().find(c => c.name === name)
  },
  secretEndOpenInCollection: function () {
    return TYRANO.kag.dc.aibou()
  },
  endCount: function () {
    const { secretEndOpen, endings } = TYRANO.kag.variable.sf
    return secretEndOpen
      ? endings.length
      : endings.filter(no => this._ends()[no].category == 'normal').length
  },
  collectedEndCount: function () {
    const { collectedEndings } = TYRANO.kag.variable.sf
    return this.secretEndOpenInCollection()
      ? collectedEndings.length
      : collectedEndings.filter(no => this._ends()[no].category == 'normal')
          .length
  },
  totalEndings: function () {
    const { secretEndOpen } = TYRANO.kag.variable.sf
    const ends = Object.values(TYRANO.kag.dc._ends())
    const available = secretEndOpen
      ? ends
      : ends.filter(e => e.category == 'normal')
    return available.length
  },
  collectedTotalEndings: function () {
    const ends = Object.values(TYRANO.kag.dc._ends())
    const available = this.secretEndOpenInCollection()
      ? ends
      : ends.filter(e => e.category == 'normal')
    return available.length
  },
}
