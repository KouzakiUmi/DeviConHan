window.tyrano_lang = {
  word: {
    go_title: 'Return to title?',
    close_confirm: 'Yawn... I guess it\'s about time to take a break.',
    load_data: 'Load this save data?',
    load_data_kill:
      '<span style="color: red;font-family: kowai">Load this save data...?</span>',
    load_auto_save:
      'Load autosave data?<br>Last autosave time:<br>$time',
    load_auto_save_tutorial:
      'Press <span style="color:#2ea6b7;">Go Back a Bit</span> in the top right to restart from just before.',
    overwrite_save: 'Overwrite and save?',
    overwrite_save_kill:
      '<span style="color: red;font-family: kowai">Overwrite and save...?</span>',
    stop_save: 'You shouldn\'t save in a place like this.',
    exit_game: 'Close the window and quit, okay?',
    not_saved: 'NO SAVE',
    delete_photo: 'Do you really want to delete this photo?',
    save_photo: 'Please select the output destination.',
    photo_saved: 'Saved!',
    photo_save_failed: 'Save failed...',
    quit_deco: 'Stop decorating and return to the album?',
    delete_all_data:
      'Your collection records will be kept, but everything else will be rewound. Are you sure?',
    delete_all_data_confirm:
      '<span style="text-decoration: underline">Final Confirmation</span><br>Once your save data is gone, it can\'t be restored.<br>If you still want to continue, press "OK".',
    delete_all_data_kill_1:
      '<span style="color: red;font-family: kowai">I\'ll never let you go.</span>',
    delete_all_data_kill_2:
      '<span style="color: red;font-family: kowai">It\'s too late for all of that now.</span>',
    delete_all_data_kill_3:
      '<span style="color: red;font-family: kowai">Hey, do it again.</span>',
    album_full: 'There\'s no more space in the album.<br>Please delete some photos.',
    tag: 'Tags',
    not_exists: 'does not exist',
    error: 'An error occurred. Please check the script.',
    label: 'Label',
    label_double: 'appears multiple times in the same scenario file',
    error_occurred: 'An error occurred',
    save_file_violation_1:
      'Did you tamper with the save data? Never start from anything other than the record you\'ve walked.',
    save_file_violation_2: 'Can I load the save data and start the game?',
    save_file_violation_3:
      'Startup aborted. Please delete the save data and start again.',
    steam_login_failed: 'Please launch from Steam',
    lord: 'I\'m glad I met you',
    reset_devi: 'What are you spacing out for? Let\'s go drain some mana already.',
    double_start: 'I\'ve already started.',
    reload: 'Reload',
    yes: 'Do it',
    no: 'I won\'t.',
    nod: 'Nod',
    silent: '...',
    ok: 'OK',
    cancel: 'Cancel',
    collection: {
      chara: {
        beast: '<ruby>Beast<rt>&nbsp;</rt></ruby>',
        debirun: '<ruby>Devilun<rt>&nbsp;</rt></ruby>',
        demon: '<ruby>Demon / Fallen Angel<rt>&nbsp;</rt></ruby>',
        fairy: '<ruby>Fairy / Angel<rt>&nbsp;</rt></ruby>',
      },
      ending: {
        normal: 'Ending',
        secret: 'Secret',
      },
    },
    subtitle: {
      name: '~The Quest for the True Name~',
      end: '~Quest for the Ending~',
      kanou: '~Quest for Possibility~',
      bel: '~Belphegor\'s Quest~',
    },
    kill_load: 'I Will Never Forgive You',
  },

  novel: {
    file_menu_button_save: 'menu_button_save.gif',
    file_menu_button_load: 'menu_button_load.gif',
    file_menu_button_message_close: 'menu_message_close.gif',
    file_menu_button_skip: 'menu_button_skip.gif',
    file_menu_button_title: 'menu_button_title.gif',
    file_menu_button_close: 'menu_button_close.png',
    file_menu_bg: 'menu_bg.jpg',
    file_save_bg: 'menu_save_bg.jpg',
    file_load_bg: 'menu_load_bg.jpg',
    file_button_menu: 'button_menu.png',
    error_occurred: 'error occurred',
  },
}
