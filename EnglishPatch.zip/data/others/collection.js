﻿/**
 * name: 名前
 * no: アイコン番号（data/image/collection_chara/icon 参照）
 * description: 説明
 * sex: 性別（1: オス、2: メス、3: 両性、4: 不明）
 * breed: 種族
 * category: カテゴリ（'beast' / 'fairy' / 'demon' / 'debirun'）
 * alts: 表情差分数（差分を追加したらここも増やすこと）
 */
TYRANO.kag.dc = {
  ...TYRANO.kag.dc,
  collectionCharaData: () => [
    {
      name: 'リリカ',
	  zh_name:'Ririka',
      no: '01',
      description:
        'An&nbsp;always-upbeat&nbsp;gyaru.&nbsp;Designer&nbsp;for&nbsp;the&nbsp;fashion&nbsp;brand&nbsp;"SAVANNA,"&nbsp;with&nbsp;impeccable&nbsp;taste.&nbsp;She&nbsp;believes&nbsp;she&nbsp;came&nbsp;from&nbsp;space.',
      sex: 2,
      breed: 'Giraffe',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ペイン',
	  zh_name:'Payne',
      no: '02',
      description:
        'A&nbsp;lively&nbsp;prince&nbsp;of&nbsp;a&nbsp;kingdom.<br>He&nbsp;sneaks&nbsp;out&nbsp;of&nbsp;the&nbsp;castle&nbsp;and&nbsp;loves&nbsp;munching&nbsp;on&nbsp;his&nbsp;favorite&nbsp;baguette&nbsp;while&nbsp;having&nbsp;adventures.<br>He\'s&nbsp;a&nbsp;bit&nbsp;bad&nbsp;at&nbsp;studying.',
      sex: 1,
      breed: 'Fennec',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ティング',
	  zh_name:'Ting',
      no: '03',
      description:
        'A&nbsp;modest&nbsp;and&nbsp;quiet&nbsp;prince&nbsp;of&nbsp;a&nbsp;nation.<br>He&nbsp;is&nbsp;Payne\'s&nbsp;brother.&nbsp;Since&nbsp;childhood,&nbsp;he&nbsp;has&nbsp;had&nbsp;a&nbsp;frail&nbsp;constitution&nbsp;and&nbsp;is&nbsp;confined&nbsp;to&nbsp;the&nbsp;castle.&nbsp;He&nbsp;excels&nbsp;at&nbsp;ice&nbsp;magic&nbsp;and&nbsp;magical&nbsp;pharmacology.',
      sex: 1,
      breed: 'Fennec',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ジェクト',
	  zh_name:'Ject',
      no: '04',
      description:
        'An&nbsp;electronic-power&nbsp;modeler&nbsp;who&nbsp;can&nbsp;copy&nbsp;and&nbsp;manipulate&nbsp;people&nbsp;or&nbsp;objects.&nbsp;He\'s&nbsp;confident&nbsp;and&nbsp;otaku-ish,&nbsp;gets&nbsp;breathless&nbsp;at&nbsp;the&nbsp;drop&nbsp;of&nbsp;a&nbsp;hat,&nbsp;and&nbsp;tends&nbsp;to&nbsp;wet&nbsp;himself&nbsp;when&nbsp;he\'s&nbsp;too&nbsp;absorbed&nbsp;in&nbsp;his&nbsp;work.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'アリス',
	  zh_name:'Alice',
      no: '05',
      description:
        'A&nbsp;girl&nbsp;researching&nbsp;magical&nbsp;pharmacology.<br>Her&nbsp;hobby&nbsp;is&nbsp;collecting&nbsp;rare&nbsp;mushrooms.&nbsp;Surly,&nbsp;but&nbsp;she&nbsp;can\'t&nbsp;resist&nbsp;fluffy&nbsp;things.<br>Quite&nbsp;the&nbsp;taskmaster.',
      sex: 2,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'コハク',
	  zh_name:'Kohaku',
      no: '06',
      description:
        'A&nbsp;mischievous&nbsp;nine-tailed&nbsp;fox.&nbsp;Can&nbsp;shapeshift&nbsp;freely.&nbsp;Usually&nbsp;sealed&nbsp;in&nbsp;the&nbsp;killing&nbsp;stone&nbsp;on&nbsp;their&nbsp;forehead.&nbsp;Dislikes&nbsp;eggplant.',
      sex: 4,
      breed: 'Fox',
      category: 'beast',
      alts: 6,
    },
    {
      name: 'アルマース',
	  zh_name:'Almaz',
      no: '07',
      description:
        'A&nbsp;cool&nbsp;musician&nbsp;in&nbsp;daily&nbsp;life.&nbsp;Received&nbsp;elite&nbsp;education&nbsp;from&nbsp;a&nbsp;young&nbsp;age,&nbsp;and&nbsp;his&nbsp;piano&nbsp;skills&nbsp;are&nbsp;top-notch.&nbsp;But&nbsp;unfortunately,&nbsp;he\'s&nbsp;an&nbsp;extreme&nbsp;womanizer.&nbsp;Harsh&nbsp;on&nbsp;men.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ライ',
	  zh_name:'Rai',
      no: '08',
      description:
        'A&nbsp;timid&nbsp;crybaby&nbsp;boy&nbsp;who&nbsp;trains&nbsp;hard&nbsp;to&nbsp;become&nbsp;stronger.&nbsp;He&nbsp;can&nbsp;call&nbsp;down&nbsp;lightning&nbsp;only&nbsp;in&nbsp;moments&nbsp;of&nbsp;absolute&nbsp;peril.&nbsp;His&nbsp;favorite&nbsp;food&nbsp;is&nbsp;fried&nbsp;shrimp.',
      sex: 1,
      breed: 'Lion',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ラピス',
	  zh_name:'Lapis',
      no: '09',
      description:
        'A&nbsp;part-time&nbsp;instructor&nbsp;at&nbsp;Solciere&nbsp;Magic&nbsp;Academy.&nbsp;From&nbsp;a&nbsp;family&nbsp;of&nbsp;great&nbsp;mages,&nbsp;he&nbsp;can&nbsp;use&nbsp;magic&nbsp;that&nbsp;stops&nbsp;time&nbsp;for&nbsp;a&nbsp;few&nbsp;seconds.<br>Has&nbsp;a&nbsp;sweet&nbsp;tooth&nbsp;and&nbsp;loves&nbsp;cocoa.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'サフィール',
	  zh_name:'Saphir',
      no: '10',
      description:
        'A&nbsp;narcissistic&nbsp;noble&nbsp;youth.&nbsp;Though&nbsp;a&nbsp;swordsman,&nbsp;he&nbsp;dislikes&nbsp;sweating,&nbsp;so&nbsp;he&nbsp;avoids&nbsp;fighting.&nbsp;He&nbsp;often&nbsp;stays&nbsp;at&nbsp;a&nbsp;villa&nbsp;in&nbsp;a&nbsp;tropical&nbsp;land.<br>Popular&nbsp;enough&nbsp;to&nbsp;have&nbsp;a&nbsp;fan&nbsp;club.',
      sex: 1,
      breed: 'Horse',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'マルス',
	  zh_name:'Mars',
      no: '11',
      description:
        'A&nbsp;new&nbsp;teacher&nbsp;at&nbsp;Solciere&nbsp;Magic&nbsp;Academy.&nbsp;Kind-hearted&nbsp;and&nbsp;caring&nbsp;toward&nbsp;students,&nbsp;but&nbsp;lacks&nbsp;confidence&nbsp;and&nbsp;tends&nbsp;to&nbsp;think&nbsp;negatively.&nbsp;Often&nbsp;relies&nbsp;on&nbsp;alcohol&nbsp;and&nbsp;becomes&nbsp;a&nbsp;crying&nbsp;drunk.',
      sex: 1,
      breed: 'Rabbit',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ネゼル',
	  zh_name:'Nesseru',
      no: '12',
      description:
        'A&nbsp;friendly&nbsp;bird-handling&nbsp;lady.&nbsp;Born&nbsp;with&nbsp;the&nbsp;Evil&nbsp;Eye,&nbsp;she&nbsp;has&nbsp;the&nbsp;ability&nbsp;to&nbsp;converse&nbsp;with&nbsp;monsters.&nbsp;Loves&nbsp;her&nbsp;partner,&nbsp;the&nbsp;mahorou&nbsp;Hololu,&nbsp;and&nbsp;her&nbsp;husband&nbsp;Guman.',
      sex: 2,
      breed: 'Wolf',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ルナ',
	  zh_name:'Luna',
      no: '13',
      description:
        'A&nbsp;moon-ring&nbsp;dolphin&nbsp;girl&nbsp;living&nbsp;in&nbsp;an&nbsp;undersea&nbsp;kingdom.&nbsp;Curious&nbsp;by&nbsp;nature,&nbsp;with&nbsp;a&nbsp;habit&nbsp;of&nbsp;putting&nbsp;anything&nbsp;in&nbsp;her&nbsp;mouth.&nbsp;Loves&nbsp;her&nbsp;husband,&nbsp;the&nbsp;shark&nbsp;Sharky.',
      sex: 2,
      breed: 'Dolphin',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'フウガ',
	  zh_name:'Fuuga',
      no: '14',
      description:
        'A&nbsp;tiger&nbsp;boy&nbsp;who&nbsp;uses&nbsp;dual&nbsp;swords.&nbsp;He&nbsp;trains&nbsp;every&nbsp;day&nbsp;with&nbsp;his&nbsp;familiar,&nbsp;the&nbsp;Wind&nbsp;Fairy&nbsp;Sylphy.&nbsp;He&nbsp;looks&nbsp;cool&nbsp;at&nbsp;first&nbsp;glance,&nbsp;but&nbsp;he\'s&nbsp;actually&nbsp;shy&nbsp;and&nbsp;a&nbsp;bit&nbsp;absent-minded.',
      sex: 1,
      breed: 'Tiger',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'チェシカ',
	  zh_name:'Cheshika',
      no: '15',
      description:
        'A&nbsp;chatty,&nbsp;silly&nbsp;clown.&nbsp;Alice\'s&nbsp;test&nbsp;subject&nbsp;and&nbsp;errand&nbsp;boy.&nbsp;He&nbsp;isn\'t&nbsp;fond&nbsp;of&nbsp;water&nbsp;and&nbsp;doesn\'t&nbsp;bathe,&nbsp;so&nbsp;his&nbsp;tail&nbsp;smells&nbsp;a&nbsp;bit.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'マキ',
	  zh_name:'Maki',
      no: '16',
      description:
        'A&nbsp;journalist&nbsp;who&nbsp;publishes&nbsp;the&nbsp;\'Arcan&nbsp;News\'&nbsp;throughout&nbsp;Magirisia.&nbsp;Always&nbsp;moving&nbsp;quickly&nbsp;around&nbsp;various&nbsp;places&nbsp;for&nbsp;scoops.&nbsp;\'Wow!\'&nbsp;is&nbsp;her&nbsp;catchphrase.&nbsp;Childhood&nbsp;friend&nbsp;of&nbsp;Connie.',
      sex: 2,
      breed: 'Ring-tailed&nbsp;lemur',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ミーティア',
	  zh_name:'Meteor',
      no: '17',
      description:
        'A&nbsp;first-year&nbsp;at&nbsp;Solciere&nbsp;Magic&nbsp;Academy.&nbsp;Not&nbsp;good&nbsp;at&nbsp;using&nbsp;magic,&nbsp;and&nbsp;for&nbsp;now&nbsp;can&nbsp;only&nbsp;produce&nbsp;a&nbsp;small&nbsp;star-shaped&nbsp;light.&nbsp;Has&nbsp;a&nbsp;habit&nbsp;of&nbsp;speaking&nbsp;in&nbsp;broken&nbsp;phrases.',
      sex: 2,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'コニー',
	  zh_name:'Connie',
      no: '18',
      description:
        'A&nbsp;police&nbsp;dog&nbsp;who&nbsp;patrols&nbsp;for&nbsp;the&nbsp;Magic&nbsp;Police.&nbsp;Polite&nbsp;and&nbsp;dedicated&nbsp;to&nbsp;her&nbsp;work,&nbsp;but&nbsp;a&nbsp;clumsy&nbsp;troublemaker.&nbsp;Poor&nbsp;eyesight,&nbsp;but&nbsp;a&nbsp;very&nbsp;sharp&nbsp;sense&nbsp;of&nbsp;smell.',
      sex: 2,
      breed: 'Dog',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'エメロード',
	  zh_name:'Emeraude',
      no: '19',
      description:
        'A&nbsp;kind-hearted&nbsp;young&nbsp;nobleman...&nbsp;but&nbsp;he&nbsp;dotes&nbsp;on&nbsp;his&nbsp;little&nbsp;sister&nbsp;Hisui&nbsp;to&nbsp;an&nbsp;extreme&nbsp;degree,&nbsp;a&nbsp;total&nbsp;sis-con.&nbsp;He\'s&nbsp;good&nbsp;at&nbsp;cooking&nbsp;and&nbsp;prepares&nbsp;meals&nbsp;without&nbsp;relying&nbsp;on&nbsp;the&nbsp;mansion\'s&nbsp;servants.',
      sex: 1,
      breed: 'Dog',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'アレン',
	  zh_name:'Allen',
      no: '20',
      description:
        'A&nbsp;goody-two-shoes&nbsp;rabbit&nbsp;boy.&nbsp;Despite&nbsp;appearances,&nbsp;he\'s&nbsp;the&nbsp;eldest&nbsp;of&nbsp;four&nbsp;siblings,&nbsp;responsible&nbsp;and&nbsp;polite.&nbsp;He\'s&nbsp;troubled&nbsp;by&nbsp;his&nbsp;two-faced&nbsp;nature.',
      sex: 1,
      breed: 'Rabbit',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ミンティ',
	  zh_name:'Minty',
      no: '21',
      description:
        'A&nbsp;pastry&nbsp;chef&nbsp;working&nbsp;at&nbsp;the&nbsp;Western&nbsp;confectionery&nbsp;shop&nbsp;"Chocolagne."&nbsp;Skilled&nbsp;at&nbsp;making&nbsp;sweets&nbsp;with&nbsp;mint.&nbsp;Her&nbsp;motto&nbsp;is&nbsp;"If&nbsp;they&nbsp;hit&nbsp;you,&nbsp;hit&nbsp;back."',
      sex: 2,
      breed: 'Rabbit',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ガク',
	  zh_name:'Gakuloid',
      no: '22',
      description:
        'A&nbsp;super&nbsp;robot&nbsp;powered&nbsp;by&nbsp;magical&nbsp;science&nbsp;that&nbsp;converts&nbsp;mana&nbsp;into&nbsp;electricity&nbsp;inside&nbsp;his&nbsp;body.&nbsp;He&nbsp;can&nbsp;also&nbsp;ingest&nbsp;food,&nbsp;but&nbsp;recharging&nbsp;via&nbsp;the&nbsp;cable&nbsp;in&nbsp;his&nbsp;tail&nbsp;is&nbsp;most&nbsp;efficient.',
      sex: 1,
      breed: 'Robot',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'パンプティ',
	  zh_name:'Pampty',
      no: '23',
      description:
        'A&nbsp;mysterious&nbsp;boy&nbsp;skilled&nbsp;in&nbsp;pantomime.&nbsp;Lately,&nbsp;he\'s&nbsp;been&nbsp;working&nbsp;hard&nbsp;to&nbsp;find&nbsp;new&nbsp;acts,&nbsp;and&nbsp;he\'s&nbsp;really&nbsp;into&nbsp;hypnotism.&nbsp;He&nbsp;sees&nbsp;Cheshika&nbsp;as&nbsp;a&nbsp;rival.&nbsp;He&nbsp;loves&nbsp;egg&nbsp;dishes.',
      sex: 1,
      breed: 'Lizard',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ルビー',
	  zh_name:'Ruby',
      no: '24',
      description:
        'A&nbsp;wicked&nbsp;and&nbsp;ruthless&nbsp;noble&nbsp;youth.&nbsp;Always&nbsp;walks&nbsp;with&nbsp;his&nbsp;servant&nbsp;bat.&nbsp;Once&nbsp;angered,&nbsp;he\'s&nbsp;a&nbsp;violent&nbsp;brute&nbsp;who&nbsp;won\'t&nbsp;stop.&nbsp;A&nbsp;mama\'s&nbsp;boy&nbsp;who&nbsp;swears&nbsp;loyalty&nbsp;to&nbsp;his&nbsp;mother.',
      sex: 1,
      breed: 'Tiger',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ジュエリーピンク',
	  zh_name:'Jewelry&nbsp;Pink',
      no: '25',
      description:
        'A&nbsp;maid&nbsp;serving&nbsp;Saphir.&nbsp;Skilled&nbsp;at&nbsp;his&nbsp;work,&nbsp;a&nbsp;formidable&nbsp;fighter,&nbsp;and&nbsp;a&nbsp;master&nbsp;of&nbsp;the&nbsp;Kamamaki&nbsp;Kick.&nbsp;Loves&nbsp;Saphir&nbsp;more&nbsp;than&nbsp;anything&nbsp;in&nbsp;this&nbsp;world.&nbsp;Smells&nbsp;of&nbsp;perfume.',
      sex: 1,
      breed: 'Horse',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ガウルォス',
	  zh_name:'Gawuros',
      no: '26',
      description:
        'A&nbsp;masked&nbsp;wolf&nbsp;who&nbsp;usually&nbsp;acts&nbsp;the&nbsp;fool.<br>Has&nbsp;the&nbsp;Evil&nbsp;Eye,&nbsp;granting&nbsp;the&nbsp;ability&nbsp;to&nbsp;peer&nbsp;into&nbsp;others\'&nbsp;memories.&nbsp;Fuuga\'s&nbsp;master,&nbsp;and&nbsp;together&nbsp;they&nbsp;wander&nbsp;the&nbsp;lands&nbsp;of&nbsp;Magirisia.',
      sex: 1,
      breed: 'Wolf',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ラミア',
	  zh_name:'Lamia',
      no: '27',
      description:
        'A&nbsp;girl&nbsp;from&nbsp;a&nbsp;family&nbsp;of&nbsp;sorcerers&nbsp;who&nbsp;sealed&nbsp;a&nbsp;Western&nbsp;dragon.&nbsp;She&nbsp;never&nbsp;stops&nbsp;smiling,&nbsp;but&nbsp;she\'s&nbsp;short-tempered&nbsp;and&nbsp;her&nbsp;attitude&nbsp;changes&nbsp;drastically&nbsp;when&nbsp;angry.&nbsp;She&nbsp;likes&nbsp;to&nbsp;burn&nbsp;monsters&nbsp;alive&nbsp;and&nbsp;eat&nbsp;them.',
      sex: 2,
      breed: 'Snake',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'ピーター',
	  zh_name:'Peter',
      no: '28',
      description:
        'Guardian&nbsp;of&nbsp;the&nbsp;Fountain&nbsp;of&nbsp;Souls,&nbsp;a&nbsp;sanctuary&nbsp;where&nbsp;Spirit&nbsp;Gods&nbsp;dwell.&nbsp;As&nbsp;a&nbsp;child,&nbsp;wandered&nbsp;into&nbsp;the&nbsp;fountain\'s&nbsp;forest&nbsp;and&nbsp;now&nbsp;lives&nbsp;surrounded&nbsp;by&nbsp;friend&nbsp;Belbel&nbsp;and&nbsp;the&nbsp;Spirit&nbsp;Gods.',
      sex: 1,
      breed: 'Cat',
      category: 'beast',
      alts: 3,
    },
    {
      name: 'クピャドエル',
	  zh_name:'Kupyadel',
      no: '01',
      description:
        'An&nbsp;angel&nbsp;who&nbsp;keeps&nbsp;their&nbsp;eyes&nbsp;closed&nbsp;at&nbsp;all&nbsp;times,&nbsp;as&nbsp;if&nbsp;hiding&nbsp;their&nbsp;true&nbsp;heart.&nbsp;The&nbsp;eye&nbsp;on&nbsp;their&nbsp;belly&nbsp;is&nbsp;unstable,&nbsp;but&nbsp;it&nbsp;has&nbsp;the&nbsp;power&nbsp;to&nbsp;see&nbsp;through&nbsp;to&nbsp;the&nbsp;truth.&nbsp;Their&nbsp;hobby&nbsp;is&nbsp;binding.&nbsp;They&nbsp;refer&nbsp;to&nbsp;themself&nbsp;as&nbsp;\'watakushi\'.',
      sex: 3,
      breed: 'Angel&nbsp;of&nbsp;Love',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'でかクピャ',
	  zh_name:'Big&nbsp;Cupya',
      no: '02',
      description:
        'A&nbsp;form&nbsp;grown&nbsp;by&nbsp;gaining&nbsp;mana.&nbsp;Prone&nbsp;to&nbsp;self-loathing&nbsp;over&nbsp;impulses&nbsp;unbefitting&nbsp;an&nbsp;angel,&nbsp;with&nbsp;a&nbsp;habit&nbsp;of&nbsp;hiding&nbsp;true&nbsp;feelings.&nbsp;Has&nbsp;a&nbsp;scar&nbsp;on&nbsp;the&nbsp;neck&nbsp;given&nbsp;by&nbsp;Devilun.&nbsp;First&nbsp;person:&nbsp;Boku.',
      sex: 3,
      breed: 'Angel&nbsp;of&nbsp;Love',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'シルフィ',
	  zh_name:'Sylphy',
      no: '03',
      description:
        'Fuuga\'s&nbsp;contracted&nbsp;fairy.&nbsp;The&nbsp;scarf&nbsp;he&nbsp;received&nbsp;at&nbsp;the&nbsp;time&nbsp;of&nbsp;the&nbsp;contract&nbsp;is&nbsp;his&nbsp;treasure.&nbsp;His&nbsp;dream&nbsp;is&nbsp;to&nbsp;one&nbsp;day&nbsp;gain&nbsp;power&nbsp;and&nbsp;grow&nbsp;big.&nbsp;He&nbsp;loves&nbsp;the&nbsp;handmade&nbsp;rice&nbsp;balls&nbsp;Fuuga&nbsp;makes.',
      sex: 1,
      breed: 'Wind&nbsp;Fairy',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'ベルベル',
	  zh_name:'Belbel',
      no: '04',
      description:
        'Peter\'s&nbsp;contracted&nbsp;fairy.&nbsp;She&nbsp;sheltered&nbsp;young&nbsp;Peter&nbsp;as&nbsp;he&nbsp;wandered&nbsp;the&nbsp;forest&nbsp;of&nbsp;trees,&nbsp;showing&nbsp;her&nbsp;caring&nbsp;nature.&nbsp;Her&nbsp;dream&nbsp;is&nbsp;to&nbsp;one&nbsp;day&nbsp;become&nbsp;a&nbsp;Great&nbsp;Fairy&nbsp;like&nbsp;Lady&nbsp;Fairydou.',
      sex: 2,
      breed: 'Bell&nbsp;Fairy',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'ムゥムゥ',
	  zh_name:'MuuMuu',
      no: '05',
      description:
        'A&nbsp;jeweler&nbsp;running&nbsp;a&nbsp;magic&nbsp;stone&nbsp;shop.&nbsp;Can&nbsp;assume&nbsp;true&nbsp;form&nbsp;using&nbsp;mana&nbsp;stored&nbsp;in&nbsp;a&nbsp;lamp.&nbsp;Can\'t&nbsp;resist&nbsp;expensive&nbsp;treasures.&nbsp;Catchphrase:&nbsp;Genius!',
      sex: 1,
      breed: 'Lamp&nbsp;Fairy',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'ミカエル',
	  zh_name:'Michael',
      no: '06',
      description:
        'The&nbsp;archangel&nbsp;who&nbsp;leads&nbsp;the&nbsp;Celestial&nbsp;Army.&nbsp;They&nbsp;can&nbsp;see&nbsp;through&nbsp;the&nbsp;eyes&nbsp;of&nbsp;all&nbsp;angels.&nbsp;They&nbsp;value&nbsp;justice,&nbsp;order,&nbsp;and&nbsp;fairness,&nbsp;and&nbsp;watch&nbsp;over&nbsp;Magirisia.',
      sex: 4,
      breed: 'Archangel',
      category: 'fairy',
      alts: 3,
    },
    {
      name: 'BBB',
	  zh_name:'BBB',
      no: '01',
      description:
        'A&nbsp;chimera&nbsp;of&nbsp;a&nbsp;fly&nbsp;and&nbsp;a&nbsp;termite.&nbsp;Since&nbsp;developing&nbsp;a&nbsp;taste&nbsp;for&nbsp;fine&nbsp;food,&nbsp;he\'s&nbsp;been&nbsp;gentle,&nbsp;but&nbsp;food-related&nbsp;stimulation&nbsp;brings&nbsp;out&nbsp;his&nbsp;gluttonous&nbsp;form,&nbsp;Gluttony,&nbsp;and&nbsp;sends&nbsp;him&nbsp;on&nbsp;a&nbsp;rampage.',
      sex: 1,
      breed: 'Demon&nbsp;of&nbsp;Gluttony',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'あもあも',
	  zh_name:'Amoamo',
      no: '02',
      description:
        'A&nbsp;chimera&nbsp;of&nbsp;a&nbsp;sea&nbsp;angel,&nbsp;sea&nbsp;hare,&nbsp;and&nbsp;scorpion.&nbsp;They&nbsp;can&nbsp;inject&nbsp;various&nbsp;toxins&nbsp;from&nbsp;their&nbsp;tail,&nbsp;are&nbsp;free-spirited,&nbsp;like&nbsp;to&nbsp;meddle&nbsp;and&nbsp;fuss&nbsp;over&nbsp;others,&nbsp;and&nbsp;hate&nbsp;ugly&nbsp;things.',
      sex: 3,
      breed: 'Demon&nbsp;of&nbsp;Lust',
      category: 'demon',
      alts: 9,
    },
    {
      name: 'ナザール',
	  zh_name:'Nazar',
      no: '03',
      description:
        'A&nbsp;chimera&nbsp;of&nbsp;sea&nbsp;snake,&nbsp;reindeer,&nbsp;crow,&nbsp;and&nbsp;dog.&nbsp;Self-conscious&nbsp;about&nbsp;his&nbsp;face,&nbsp;he&nbsp;hides&nbsp;it&nbsp;with&nbsp;bangs.&nbsp;Jealous&nbsp;and&nbsp;doesn\'t&nbsp;talk&nbsp;to&nbsp;anyone.&nbsp;Likes&nbsp;blueberries.',
      sex: 1,
      breed: 'Demon&nbsp;of&nbsp;Envy',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'マネコ',
	  zh_name:'Maneko',
      no: '04',
      description:
        'A&nbsp;former&nbsp;low-ranking&nbsp;cat&nbsp;demon.&nbsp;Having&nbsp;experienced&nbsp;extreme&nbsp;poverty,&nbsp;she&nbsp;still&nbsp;can\'t&nbsp;shake&nbsp;her&nbsp;penny-pinching&nbsp;habits.&nbsp;She&nbsp;oversees&nbsp;trade&nbsp;between&nbsp;the&nbsp;Human&nbsp;Realm&nbsp;and&nbsp;the&nbsp;Demon&nbsp;Realm.',
      sex: 2,
      breed: 'Demon&nbsp;of&nbsp;Greed',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'D・Red',
	  zh_name:'D&nbsp;Red',
      no: '05',
      description:
        'A&nbsp;chimera&nbsp;of&nbsp;a&nbsp;dragon&nbsp;and&nbsp;a&nbsp;pangolin.&nbsp;His&nbsp;body&nbsp;is&nbsp;ironclad,&nbsp;and&nbsp;he&nbsp;constantly&nbsp;uses&nbsp;Evil&nbsp;God&nbsp;abilities&nbsp;to&nbsp;turn&nbsp;his&nbsp;insides&nbsp;into&nbsp;an&nbsp;arsenal.&nbsp;An&nbsp;extreme&nbsp;military&nbsp;maniac,&nbsp;especially&nbsp;fond&nbsp;of&nbsp;tanks.',
      sex: 1,
      breed: 'Demon&nbsp;of&nbsp;Wrath',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'ハーデスター',
	  zh_name:'Hadester',
      no: '06',
      description:
        'The&nbsp;fallen&nbsp;form&nbsp;of&nbsp;Archangel&nbsp;Lucifer.&nbsp;They&nbsp;consider&nbsp;death&nbsp;a&nbsp;salvation&nbsp;and&nbsp;have&nbsp;become&nbsp;a&nbsp;reaper&nbsp;who&nbsp;harvests&nbsp;lives&nbsp;to&nbsp;create&nbsp;a&nbsp;cycle&nbsp;of&nbsp;happiness.&nbsp;They&nbsp;call&nbsp;the&nbsp;Summoner&nbsp;\'King\'&nbsp;and&nbsp;worship&nbsp;them.',
      sex: 4,
      breed: 'Fallen&nbsp;Angel&nbsp;of&nbsp;Pride',
      category: 'demon',
      alts: 6,
    },
    {
      name: 'クピデル',
	  zh_name:'Cupidel',
      no: '07',
      description:
        'Kupyadel\'s&nbsp;fallen&nbsp;form.&nbsp;Even&nbsp;if&nbsp;it\'s&nbsp;a&nbsp;false&nbsp;happiness,&nbsp;it\'s&nbsp;considered&nbsp;salvation,&nbsp;and&nbsp;if&nbsp;you\'re&nbsp;gazed&nbsp;upon&nbsp;by&nbsp;those&nbsp;eyes,&nbsp;your&nbsp;soul&nbsp;is&nbsp;trapped&nbsp;in&nbsp;a&nbsp;false&nbsp;paradise,&nbsp;and&nbsp;your&nbsp;body&nbsp;becomes&nbsp;a&nbsp;living&nbsp;corpse&nbsp;and&nbsp;rots&nbsp;away.',
      sex: 3,
      breed: 'Fallen&nbsp;Angel&nbsp;of&nbsp;Vanity',
      category: 'demon',
      alts: 1,
    },
    {
      name: 'ココヨ',
	  zh_name:'Kokoyo',
      no: '08',
      description:
        'A&nbsp;bat-type&nbsp;lower-class&nbsp;demon.&nbsp;Good&nbsp;at&nbsp;flattering,&nbsp;but&nbsp;tends&nbsp;to&nbsp;blurt&nbsp;out&nbsp;true&nbsp;feelings.&nbsp;At&nbsp;an&nbsp;age&nbsp;where&nbsp;she&nbsp;worries&nbsp;about&nbsp;being&nbsp;provincial.',
      sex: 2,
      breed: 'Weak&nbsp;Bat',
      category: 'demon',
      alts: 3,
    },
    {
      name: 'ザッス',
	  zh_name:'Zass',
      no: '09',
      description:
        'A&nbsp;bat-type&nbsp;lower-class&nbsp;demon.&nbsp;Bad&nbsp;at&nbsp;flattering&nbsp;and&nbsp;says&nbsp;everything&nbsp;honestly.&nbsp;Loves&nbsp;to&nbsp;eat.',
      sex: 1,
      breed: 'Weak&nbsp;Bat',
      category: 'demon',
      alts: 3,
    },
    {
      name: '  ',
	  zh_name:'&nbsp;&nbsp;',
      no: '00',
      description:
        'The&nbsp;form&nbsp;of&nbsp;a&nbsp;god&nbsp;encountered&nbsp;when&nbsp;failing&nbsp;to&nbsp;stop&nbsp;without&nbsp;calling&nbsp;the&nbsp;true&nbsp;name.&nbsp;They&nbsp;dislike&nbsp;having&nbsp;their&nbsp;name&nbsp;defined.&nbsp;They&nbsp;have&nbsp;a&nbsp;habit&nbsp;of&nbsp;counting&nbsp;from&nbsp;zero.',
      sex: 4,
      breed: '&nbsp;&nbsp;',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'ザコでび',
	  zh_name:'Zako&nbsp;Devi',
      no: '01',
      description:
        'The&nbsp;form&nbsp;he&nbsp;took&nbsp;back&nbsp;in&nbsp;his&nbsp;low-ranking&nbsp;bat-demon&nbsp;days.&nbsp;When&nbsp;mana&nbsp;is&nbsp;extremely&nbsp;depleted,&nbsp;he&nbsp;reverts&nbsp;to&nbsp;this&nbsp;form.&nbsp;It\'s&nbsp;the&nbsp;most&nbsp;common&nbsp;demon&nbsp;race&nbsp;and&nbsp;is&nbsp;weak&nbsp;in&nbsp;winter.',
      sex: 1,
      breed: 'Demon&nbsp;of&nbsp;Sloth',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'でびるん',
	  zh_name:'Devilun',
      no: '02',
      description:
        'A&nbsp;small&nbsp;form&nbsp;lacking&nbsp;mana.&nbsp;Lazy&nbsp;and&nbsp;prone&nbsp;to&nbsp;slacking&nbsp;off.&nbsp;Easily&nbsp;influenced&nbsp;and&nbsp;swept&nbsp;along&nbsp;by&nbsp;others.&nbsp;Catchphrase:&nbsp;dagya-.&nbsp;First&nbsp;person:&nbsp;Oresama.',
      sex: 1,
      breed: 'Demon&nbsp;of&nbsp;Sloth',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'デカでび',
	  zh_name:'Big&nbsp;Devi',
      no: '03',
      description:
        'The&nbsp;true&nbsp;form&nbsp;grown&nbsp;by&nbsp;gaining&nbsp;mana.&nbsp;Demon&nbsp;Realm&nbsp;dialect&nbsp;fades,&nbsp;first&nbsp;person&nbsp;becomes&nbsp;Oresama.&nbsp;Likes&nbsp;raspberry&nbsp;pie&nbsp;and&nbsp;Abracadabra-men.&nbsp;Nicknamed&nbsp;Bel&nbsp;by&nbsp;demons.',
      sex: 1,
      breed: 'Demon&nbsp;of&nbsp;Sloth',
      category: 'debirun',
      alts: 6,
    },
    {
      name: 'ネオでびるん',
	  zh_name:'NEO&nbsp;Devilun',
      no: '04',
      description:
        'The&nbsp;new&nbsp;form&nbsp;that&nbsp;gathered&nbsp;all&nbsp;the&nbsp;mana&nbsp;in&nbsp;Magirisia.&nbsp;Their&nbsp;will&nbsp;has&nbsp;been&nbsp;taken&nbsp;over&nbsp;by&nbsp;the&nbsp;Evil&nbsp;Eye,&nbsp;and&nbsp;they&nbsp;have&nbsp;almost&nbsp;no&nbsp;senses&nbsp;other&nbsp;than&nbsp;sight.&nbsp;The&nbsp;face&nbsp;on&nbsp;their&nbsp;head&nbsp;is&nbsp;now&nbsp;just&nbsp;a&nbsp;decoration.',
      sex: 4,
      breed: 'Sloth&nbsp;Demon&nbsp;King',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'べるるん',
	  zh_name:'Belrun',
      no: '05',
      description:
        'A&nbsp;form&nbsp;created&nbsp;by&nbsp;calling&nbsp;his&nbsp;true&nbsp;name&nbsp;and&nbsp;forcibly&nbsp;making&nbsp;him&nbsp;fall&nbsp;into&nbsp;the&nbsp;light.&nbsp;Wrapped&nbsp;in&nbsp;a&nbsp;white&nbsp;wedding&nbsp;dress,&nbsp;his&nbsp;horns&nbsp;are&nbsp;bleached&nbsp;pure&nbsp;white.&nbsp;He\'d&nbsp;probably&nbsp;look&nbsp;good&nbsp;in&nbsp;a&nbsp;cow-print&nbsp;bikini&nbsp;too.',
      sex: 1,
      breed: 'Demon&nbsp;of&nbsp;Sloth',
      category: 'debirun',
      alts: 3,
    },
    {
      name: 'めだま',
	  zh_name:'Eyeball',
      no: '06',
      description:
        'The&nbsp;form&nbsp;of&nbsp;the&nbsp;core&nbsp;that&nbsp;succeeded&nbsp;in&nbsp;stopping&nbsp;without&nbsp;calling&nbsp;the&nbsp;true&nbsp;name.&nbsp;With&nbsp;tears&nbsp;of&nbsp;regret&nbsp;in&nbsp;their&nbsp;eyes,&nbsp;they&nbsp;wither&nbsp;away&nbsp;in&nbsp;the&nbsp;warm&nbsp;hands&nbsp;of&nbsp;the&nbsp;Summoner&nbsp;at&nbsp;the&nbsp;end.&nbsp;Even&nbsp;if&nbsp;you&nbsp;realize&nbsp;it&nbsp;now,&nbsp;it\'s&nbsp;too&nbsp;late.',
      sex: 4,
      breed: 'Devilun',
      category: 'debirun',
      alts: 3,
    },
  ],
  collectionCharaNames: function (category) {
    return this.collectionCharaData()
      .filter(c => c.category == category && c.no != '00') // 00だけ除外する（特殊表示）
      .map(c => c.name)
  },
  collectionChara: function (name) {
    return this.collectionCharaData().find(c => c.name === name)
  },
  collectionCharaCategoryData: function () {
    return ['beast']
      .concat(
        this.allCharasOpenInCollection() ? ['fairy', 'demon', 'debirun'] : []
      )
      .map(name => ({
        name,
        text: $.lang('collection')['chara'][name],
      }))
  },
  collectionCharaCategoryNames: function () {
    return this.collectionCharaCategoryData().map(c => c.name)
  },
  collectionCharaCategory: function (name) {
    return this.collectionCharaCategoryData().find(c => c.name === name)
  },
  allCharasOpenInCollection: function () {
    const { collectedCharacters } = TYRANO.kag.variable.sf
    return collectedCharacters.includes('ムゥムゥ')
  },
  characterCount: function () {
    const { allCharactersOpen, characters } = TYRANO.kag.variable.sf
    if (allCharactersOpen) return characters.filter(c => c != '  ').length

    const allNames = this.collectionCharaNames('beast')
    return characters.filter(c => allNames.includes(c)).length
  },
  collectedCharacterCount: function () {
    const { collectedCharacters } = TYRANO.kag.variable.sf
    if (this.allCharasOpenInCollection())
      return collectedCharacters.filter(c => c != '  ').length

    const beasts = this.collectionCharaNames('beast')
    return collectedCharacters.filter(c => beasts.includes(c)).length
  },
  totalCharacters: function () {
    const charas = TYRANO.kag.dc.collectionCharaData()
    const available = TYRANO.kag.variable.sf.allCharactersOpen
      ? charas.filter(c => c.name != '  ')
      : charas.filter(c => c.category == 'beast')
    return available.length
  },
  collectedTotalCharacters: function () {
    const charas = TYRANO.kag.dc.collectionCharaData()
    if (this.allCharasOpenInCollection())
      return charas.filter(c => c.name != '  ').length

    return charas.filter(c => c.category == 'beast').length
  },
}
;(function () {
  TYRANO.kag.variable.sf.characters = Array.from(
    new Set(
      TYRANO.kag.variable.sf.characters.map(c =>
        c == 'D・RED' ? 'D・Red' : c,
      ),
    ),
  )
  TYRANO.kag.variable.sf.collectedCharacters = Array.from(
    new Set(
      TYRANO.kag.variable.sf.collectedCharacters.map(c =>
        c == 'D・RED' ? 'D・Red' : c,
      ),
    ),
  )
})()
