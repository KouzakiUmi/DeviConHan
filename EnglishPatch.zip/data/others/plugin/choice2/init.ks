﻿[loadjs storage="plugin/choice2/waku_width.js"]
[loadjs storage="plugin/choice2/after_choice2.js"]
;マクロ定義（選択肢）
[macro name=choice2]
  [skipstop]
  [iscript]
  // 後ろの無効画像も含めて隠す
  $('.skip_button').addClass('in_choice2')
  mp.storage = TYRANO.kag.stat.stack.macro.slice(-1)[0].storage
  mp.color_hover1 || (mp.color_hover1 = '')
  mp.color_hover2 || (mp.color_hover2 = '')
  tf.cm1 = mp.cm1 || 'true'
  tf.cm2 = mp.cm2 || 'true'
  tf.choiceSize = 22
  tf.face = mp.face || 'craftmincho'

  // Choice images are not all the same width: waku.png/waku_mp.png are
  // 534px wide, while waku_black.png/waku_kinki.png are 352px wide.
  // Measure the actual active font and promote a short frame when needed.
  const choiceCanvas = document.createElement('canvas')
  const choiceContext = choiceCanvas.getContext('2d')
  const choiceWidth = (text) => {
    choiceContext.font = `${tf.choiceSize}px "${tf.face}"`
    return choiceContext.measureText(String(text).replace(/&nbsp;/gi, ' ').replace(/<br\s*\/?\s*>/gi, ' ')).width
  }
  const wrapChoiceText = (raw, maxWidth) => {
    const source = String(raw || '')
      .replace(/&nbsp;/gi, ' ')
      .replace(/<br\s*\/?\s*>/gi, '\n')
      .trim()
    if (!source) return ''
    return source.split(/\n/).map((paragraph) => {
      const words = paragraph.trim().split(/\s+/).filter(Boolean)
      if (!words.length) return ''
      if (choiceWidth(paragraph) <= maxWidth) return words.join(' ')
      if (words.length > 1) {
        let best = null
        for (let cut = 1; cut < words.length; cut += 1) {
          const first = words.slice(0, cut).join(' ')
          const second = words.slice(cut).join(' ')
          const firstWidth = choiceWidth(first)
          const secondWidth = choiceWidth(second)
          if (firstWidth > maxWidth || secondWidth > maxWidth) continue
          const orphanPenalty = words.length - cut <= 2 && cut >= 4 ? 180 : 0
          const balancePenalty = Math.abs(firstWidth - secondWidth) / 5
          const score = orphanPenalty + balancePenalty
          if (!best || score < best.score) best = { first, second, score }
        }
        if (best) return `${best.first}<br>${best.second}`
      }
      const lines = []
      let line = ''
      for (const word of words) {
        const candidate = line ? `${line} ${word}` : word
        if (line && choiceWidth(candidate) > maxWidth) {
          lines.push(line)
          line = word
        } else line = candidate
      }
      if (line) lines.push(line)
      return lines.join('<br>')
    }).join('<br>')
  }
  const prepareChoice = (raw, requestedKey) => {
    let key = requestedKey || 'default'
    const availableWidth = dc.wakuWidths[key] || dc.wakuWidths.default
    const innerWidth = availableWidth - 48
    // A short frame should not force a tiny or crowded label.  Keep the
    // special frame when it fits; otherwise use the long default frame.
    if (key !== 'default' && key !== 'mp' && choiceWidth(raw) > innerWidth) key = 'default'
    const width = (dc.wakuWidths[key] || dc.wakuWidths.default) - 48
    return { key, text: wrapChoiceText(raw, width) }
  }
  const choice1 = prepareChoice(mp.text1, mp.graphic1 || 'default')
  const choice2 = prepareChoice(mp.text2, mp.graphic2 || 'default')
  f.graphic1 = choice1.key === 'default' ? 'waku.png' : `waku_${choice1.key}.png`
  f.graphic2 = choice2.key === 'default' ? 'waku.png' : `waku_${choice2.key}.png`
  tf.enterimg1 = choice1.key === 'default' ? 'waku2.png' : `waku_${choice1.key}2.png`
  tf.enterimg2 = choice2.key === 'default' ? 'waku2.png' : `waku_${choice2.key}2.png`
  tf.width1 = dc.wakuWidths[choice1.key] || dc.wakuWidths.default
  tf.width2 = dc.wakuWidths[choice2.key] || dc.wakuWidths.default
  tf.x1 = (1280 - tf.width1) / 2
  tf.x2 = (1280 - tf.width2) / 2
  tf.xOffset1 = (dc.wakuWidths.default - tf.width1) / 2
  tf.xOffset2 = (dc.wakuWidths.default - tf.width2) / 2
  tf.y1 = mp.y ? Number(mp.y) : 700
  tf.y2 = tf.y1 + 90
  tf.choiceText1 = choice1.text
  tf.choiceText2 = choice2.text
  [endscript]
  [layopt layer="fix" visible="true" cond="$('.fixlayer').css('display')=='none'&&$('.message0_fore').attr('l_visible')=='false'"]
  [preload  storage="./data/sound/tap.ogg"  ]
  [preload  storage="./data/sound/OK.ogg"  ]

  ;1個目
  [if exp="mp.disabled1=='true'"]
  [image name="waku,waku1,disabled" layer="fix" folder="image" storage="&f.graphic1" x="&1280+tf.xOffset1" y="&tf.y1" width="&tf.width1" height="80" zindex="100"]
  [ptext name="waku,waku1,disabled" layer="fix" text="&tf.choiceText1" face="&tf.face" color="%color1|white" size="&tf.choiceSize" x="&1280+tf.xOffset1" y="&tf.y1" width="&tf.width1" align="center" ]
  [else]
  [glink name="waku,waku1" font_color="%color1|white" font_color_hover="%color_hover1" face="&tf.face" storage="%storage" target="%target1" text="&tf.choiceText1" x="&1280+tf.xOffset1" y="&tf.y1" width="&tf.width1" height="80" size="&tf.choiceSize" graphic="&f.graphic1" enterimg="&tf.enterimg1" enterse="tap.ogg" clickse="OK.ogg" cm="&tf.cm1" exp="dc.afterChoice2(f.graphic1=='waku_mp.png')"]
  [endif]

  ;2個目
  [if exp="mp.disabled2=='true'"]
  [image name="waku,waku2,disabled" layer="fix" folder="image" storage="&f.graphic2" x="&1280+tf.xOffset2" y="&tf.y2" width="&tf.width2" height="80" zindex="100"]
  [ptext name="waku,waku2,disabled" layer="fix" text="&tf.choiceText2" face="&tf.face" color="%color2|white" size="&tf.choiceSize" x="&1280+tf.xOffset2" y="&tf.y2" width="&tf.width2" align="center" ]
  [else]
  [glink name="waku,waku2" font_color="%color2|white" font_color_hover="%color_hover2" face="&tf.face" storage="%storage" target="%target2" text="&tf.choiceText2" x="&1280+tf.xOffset2" y="&tf.y2" width="&tf.width2" height="80" size="&tf.choiceSize" graphic="&f.graphic2" enterimg="&tf.enterimg2" enterse="tap.ogg" clickse="OK.ogg" cm="&tf.cm2" exp="dc.afterChoice2(f.graphic2=='waku_mp.png')"]
  [endif]

  [iscript]
  $('.waku1, .waku2').css({
    'box-sizing': 'border-box',
    'display': 'flex',
    'align-items': 'center',
    'justify-content': 'center',
    'line-height': '1.05',
    'padding-top': '0',
    'padding-bottom': '0',
    'white-space': 'normal',
  })
  [endscript]

  [wait time=10]
  [guard_click]
  [playse  volume="100"  time="0"  buf="1"  storage="select.ogg"  ]
  [anim name="waku1" left="&tf.x1" time="300" effect="easeOutCubic"]
  [wait time=200]
  [anim name="waku2" left="&tf.x2" time="300" effect="easeOutCubic"]
  [wait time=300]
  [free_guard_click]
  [tb_autosave  title=""  cond="f.autoSave==1"]
[endmacro]
