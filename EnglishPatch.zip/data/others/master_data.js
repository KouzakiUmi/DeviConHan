﻿TYRANO.kag.dc = {
  ...TYRANO.kag.dc,
  characters: function () {
    const notKilled = [
      {
        name: 'リリカ',
        folder: '55',
        scenario: 'Ririka',
        difficulty: 'easy',
        phrase:
          'Looks&nbsp;like&nbsp;a&nbsp;good&nbsp;start!<br>Is&nbsp;that&nbsp;what&nbsp;you\'ve&nbsp;got&nbsp;in&nbsp;your&nbsp;hand?<br>That&nbsp;trendy&nbsp;magic&nbsp;phone&nbsp;thing&nbsp;or&nbsp;whatever?',
        day: 0,
        cond: f => f.currentLoop >= 2,
        tutorial: true,
      },
      {
        name: 'ペイン',
        folder: '8',
        scenario: 'pain',
        difficulty: 'easy',
        phrase: 'Oh,&nbsp;this&nbsp;one&nbsp;looks<br>like&nbsp;a&nbsp;good&nbsp;start!',
        day: 0,
        cond: f => f.currentLoop >= 1,
        tutorial: true,
      },
      {
        name: 'ティング',
        folder: '9',
        scenario: 'ting',
        difficulty: 'normal',
        phrase:
          'Looks&nbsp;like&nbsp;the&nbsp;one&nbsp;next&nbsp;to&nbsp;them!<br>They&nbsp;seem&nbsp;to&nbsp;want&nbsp;to&nbsp;get&nbsp;out,<br>but&nbsp;are&nbsp;they&nbsp;trapped&nbsp;in&nbsp;there?',
        day: 0,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'ジェクト',
        folder: '27',
        scenario: 'ject',
        difficulty: 'normal',
        phrase:
          'Is&nbsp;this&nbsp;cyberspace?<br>Feels&nbsp;pretty&nbsp;futuristic!<br>Those&nbsp;clothes&nbsp;look&nbsp;like&nbsp;they&nbsp;store&nbsp;mana&nbsp;too!',
        day: 0,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'アリス',
        folder: '22',
        scenario: 'Alice',
        difficulty: 'hard',
        phrase: 'Experimenting?<br>What&nbsp;in&nbsp;the&nbsp;world&nbsp;are&nbsp;you&nbsp;making<br>in&nbsp;such&nbsp;a&nbsp;huge&nbsp;pot?',
        day: 0,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'コハク',
        folder: '25',
        scenario: 'kohaku',
        difficulty: 'easy',
        phrase:
          'Is&nbsp;that&nbsp;the&nbsp;famous&nbsp;nine-tailed&nbsp;fox?<br>Now&nbsp;that\'s&nbsp;a&nbsp;beauty&nbsp;glancing&nbsp;back!<br>Not&nbsp;my&nbsp;type,&nbsp;though.<br>',
        day: 0,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'アルマース',
        folder: '43',
        scenario: 'Almaz',
        difficulty: 'hard',
        phrase:
          'He\'s&nbsp;playing&nbsp;the&nbsp;piano!<br>But&nbsp;from&nbsp;inside&nbsp;the&nbsp;crystal,<br>you&nbsp;can\'t&nbsp;hear&nbsp;a&nbsp;thing.',
        day: 0,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'ライ',
        folder: '58',
        scenario: 'Lai',
        difficulty: 'hard',
        phrase:
          'Just&nbsp;lounging&nbsp;in&nbsp;the&nbsp;sun,&nbsp;huh.<br>Looks&nbsp;like&nbsp;a&nbsp;tough&nbsp;fight,&nbsp;but<br>is&nbsp;this&nbsp;dumb&nbsp;face&nbsp;really&nbsp;that&nbsp;strong?',
        day: 0,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'ラピス',
        folder: '47',
        scenario: 'lapis',
        difficulty: 'hard',
        phrase: 'Our&nbsp;eyes&nbsp;keep&nbsp;meeting,&nbsp;huh.<br>It\'s&nbsp;like&nbsp;he\'s&nbsp;looking&nbsp;at&nbsp;me&nbsp;or&nbsp;something...',
        day: 0,
        cond: f => f.currentLoop >= 3 && f.end_complete == 0,
      },
      {
        name: 'サフィール',
        folder: '38',
        scenario: 'saphir',
        difficulty: 'easy',
        phrase: 'He\'s&nbsp;in&nbsp;the&nbsp;bath!<br>But&nbsp;let\'s&nbsp;summon&nbsp;him<br>without&nbsp;a&nbsp;care&nbsp;anyway!',
        day: 1,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'マルス',
        folder: '20',
        scenario: 'marusu',
        difficulty: 'easy',
        phrase:
          'You&nbsp;okay?&nbsp;This&nbsp;guy\'s&nbsp;drinking<br>a&nbsp;huge&nbsp;amount&nbsp;of&nbsp;booze.<br>Looks&nbsp;like&nbsp;I&nbsp;can&nbsp;exploit&nbsp;the&nbsp;gaps&nbsp;in&nbsp;his&nbsp;heart.',
        day: 1,
        cond: f => f.currentLoop >= 1 && f.end_complete == 0,
      },
      {
        name: 'ネゼル',
        folder: '37',
        scenario: 'nezeru',
        difficulty: 'normal',
        phrase:
          'You\'re&nbsp;using&nbsp;matching&nbsp;mugs,<br>all&nbsp;lovey-dovey...<br>So&nbsp;this&nbsp;is&nbsp;what&nbsp;it&nbsp;means&nbsp;to&nbsp;be&nbsp;a&nbsp;normie.',
        prejump: 'syoukan_nezeru.ks',
        day: 1,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'ルナ',
        folder: '42',
        scenario: 'runa',
        difficulty: 'easy',
        phrase: 'A&nbsp;race&nbsp;that&nbsp;lives&nbsp;in&nbsp;the&nbsp;sea?<br>Grilled,&nbsp;they\'d&nbsp;be&nbsp;purr-fectly&nbsp;tasty!<br>Let\'s&nbsp;fish&nbsp;one&nbsp;up.',
        day: 1,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'フウガ',
        folder: '23',
        scenario: 'fuga',
        difficulty: 'hard',
        phrase:
          'Dual&nbsp;swords,&nbsp;huh?&nbsp;That\'s&nbsp;a&nbsp;rare&nbsp;sight.<br>Two&nbsp;swords&nbsp;must&nbsp;be&nbsp;hard&nbsp;to&nbsp;handle.<br>Show-off...',
        day: 1,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'チェシカ',
        folder: '40',
        scenario: 'chieshika',
        difficulty: 'hard',
        phrase:
          'What&nbsp;the&nbsp;heck&nbsp;is&nbsp;this&nbsp;guy...?<br>Is&nbsp;he&nbsp;trying&nbsp;to&nbsp;get&nbsp;himself&nbsp;summoned<br>from&nbsp;over&nbsp;there?',
        day: 1,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'マキ',
        folder: '61',
        scenario: 'Maki',
        difficulty: 'easy',
        phrase:
          'She\'s&nbsp;writing&nbsp;something&nbsp;down?<br>This&nbsp;magic&nbsp;circle...&nbsp;it&nbsp;looks&nbsp;like<br>the&nbsp;one&nbsp;on&nbsp;this&nbsp;house\'s&nbsp;floor...',
        day: 1,
        cond: f => f.currentLoop >= 3,
      },
      {
        name: 'ミーティア',
        folder: '39',
        scenario: 'meteor',
        difficulty: 'easy',
        phrase: 'Studying,&nbsp;huh?<br>Let\'s&nbsp;go&nbsp;mess&nbsp;with&nbsp;you!<br>Keh&nbsp;keh!',
        day: 2,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'コニー',
        folder: '29',
        scenario: 'cony',
        difficulty: 'hard',
        phrase:
          'That&nbsp;getup&nbsp;means&nbsp;cops!<br>They\'re&nbsp;going&nbsp;around&nbsp;asking<br>the&nbsp;townsfolk&nbsp;questions.',
        day: 2,
        cond: f => f.currentLoop >= 1 && f.end_complete == 0,
      },
      {
        name: 'エメロード',
        folder: '33',
        scenario: 'emeroad',
        difficulty: 'easy',
        phrase:
          'Are&nbsp;you&nbsp;a&nbsp;stalker?!<br>You\'re&nbsp;the&nbsp;worst&nbsp;scum!<br>Alright,&nbsp;I\'ll&nbsp;punish&nbsp;you!',
        day: 2,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'アレン',
        folder: '17',
        scenario: 'aren',
        difficulty: 'hard',
        phrase:
          'This&nbsp;one...&nbsp;is&nbsp;adorable!<br>But&nbsp;something&nbsp;in&nbsp;my&nbsp;gut<br>says&nbsp;he\'s&nbsp;dangerous.',
        day: 2,
        cond: f => f.currentLoop >= 2 && f.end_complete == 0,
      },
      {
        name: 'ミンティ',
        folder: '57',
        scenario: 'minty',
        difficulty: 'hard',
        phrase:
          'I&nbsp;remember&nbsp;this&nbsp;shop!<br>They&nbsp;sell&nbsp;those&nbsp;meow&nbsp;pies...<br>Brings&nbsp;back&nbsp;memories.',
        day: 2,
        cond: f =>
          f.currentLoop >= 2 && f.blueberry == 1 && f.end_complete == 0,
      },
      {
        name: 'ガク',
        folder: '32',
        scenario: 'Gaku',
        difficulty: 'hard',
        phrase:
          'Whoa,&nbsp;he\'s&nbsp;firing&nbsp;cannon&nbsp;blasts<br>from&nbsp;his&nbsp;mouth!<br>Are&nbsp;we&nbsp;really&nbsp;summoning&nbsp;this&nbsp;guy?<br>He&nbsp;seems&nbsp;super&nbsp;dangerous!',
        day: 2,
        cond: f => f.currentLoop >= 2 && f.end_complete == 0,
      },
      {
        name: 'パンプティ',
        folder: '34',
        scenario: 'panpu',
        difficulty: 'normal',
        phrase: 'What&nbsp;the&nbsp;heck&nbsp;is&nbsp;this&nbsp;guy?<br>His&nbsp;face&nbsp;is&nbsp;way<br>too&nbsp;close,&nbsp;man...',
        day: 2,
        cond: f => f.currentLoop >= 3,
      },
      {
        name: 'ムゥムゥ',
        folder: '31',
        scenario: 'muumuu',
        difficulty: 'hard',
        phrase:
          'Isn\'t&nbsp;that&nbsp;a&nbsp;magic&nbsp;stone<br>packed&nbsp;with&nbsp;mana?!&nbsp;But&nbsp;hey...<br>I\'ve&nbsp;seen&nbsp;this&nbsp;guy&nbsp;somewhere&nbsp;before.',
        day: 3,
        cond: f =>
          // 1周目以降、トゥルーエンドは2キャラ目かつサフィールを通っていない（通ってたらジュエリーピンク）
          (f.end_complete != 1 && f.currentLoop >= 1) ||
          (f.end_complete == 1 &&
            f.finished.length % 3 == 1 &&
            !f.finished.includes('サフィール')),
      },
      {
        name: 'ルビー',
        folder: '44',
        scenario: 'Ruby',
        difficulty: 'hard',
        phrase: 'It\'s&nbsp;a&nbsp;wine&nbsp;cellar!<br>Let\'s&nbsp;snatch&nbsp;some&nbsp;aged&nbsp;wine!',
        day: 3,
        cond: f =>
          // 1周目以降、トゥルーエンドは3キャラ目
          (f.end_complete != 1 && f.currentLoop >= 1) ||
          (f.end_complete == 1 && f.finished.length % 3 == 2),
      },
      {
        name: 'ジュエリーピンク',
        folder: '54',
        scenario: 'jewelrypink',
        difficulty: 'easy',
        phrase: 'Judging&nbsp;by&nbsp;that&nbsp;outfit,&nbsp;are&nbsp;you&nbsp;a&nbsp;maid?<br>I\'ll&nbsp;make&nbsp;you&nbsp;my&nbsp;servant!',
        day: 3,
        cond: f =>
          // 1周目以降、トゥルーエンドは2キャラ目、サフィールを通っているのは絶対条件
          f.finished.includes('サフィール') &&
          ((f.end_complete != 1 && f.currentLoop >= 1) ||
            (f.end_complete == 1 && f.finished.length % 3 == 1)),
      },
      {
        name: 'あもあも',
        folder: '48',
        scenario: 'amoamo',
        difficulty: 'hard',
        phrase:
          'It\'s&nbsp;blurry&nbsp;and&nbsp;hard&nbsp;to&nbsp;see,<br>but&nbsp;it&nbsp;looks&nbsp;like&nbsp;a&nbsp;pool.<br>Is&nbsp;going&nbsp;in&nbsp;at&nbsp;night&nbsp;the&nbsp;trend&nbsp;now?',
        day: 3,
        cond: f =>
          // 2周目以降、トゥルーエンドは1キャラ目
          (f.end_complete != 1 && f.currentLoop >= 2) ||
          (f.end_complete == 1 && f.finished.length % 3 == 0),
      },
      {
        name: 'ガウルォス',
        folder: '53',
        scenario: 'gauru',
        difficulty: 'hard',
        phrase:
          'What&nbsp;the&nbsp;heck&nbsp;is&nbsp;this&nbsp;creepy&nbsp;masked&nbsp;wolf...<br>I\'ll&nbsp;wring&nbsp;every&nbsp;last&nbsp;drop&nbsp;of&nbsp;MP&nbsp;out&nbsp;of&nbsp;him!',
        day: 3,
        cond: f =>
          f.currentLoop >= 2 &&
          f.finished.includes('フウガ') &&
          f.end_complete == 0,
      },
      {
        name: 'ラミア',
        folder: '52',
        scenario: 'Lamia',
        difficulty: 'hard',
        phrase:
          'W-What&nbsp;a&nbsp;creepy&nbsp;one...<br>but&nbsp;we\'re&nbsp;ready&nbsp;for&nbsp;anything&nbsp;now!',
        day: 3,
        cond: f =>
          f.currentLoop >= 2 &&
          f.finished.includes('ガウルォス') &&
          f.end_complete == 0,
      },
      {
        name: 'ピーター',
        folder: '59',
        scenario: 'Peter',
        difficulty: 'hard',
        phrase:
          '...This&nbsp;scenery,&nbsp;is&nbsp;it&nbsp;the&nbsp;Fountain&nbsp;of&nbsp;Souls?<br>But&nbsp;that\'s&nbsp;strange.&nbsp;Why&nbsp;would<br>a&nbsp;lowly&nbsp;creature&nbsp;be&nbsp;here...',
        day: 3,
        cond: f =>
          f.currentLoop >= 3 &&
          f.finished.length % 3 == 2 &&
          f.end_complete == 0,
        prejump: 'syoukan_Peter.ks',
      },
    ]
    const killed = [
      {
        name: 'ティング',
        folder: '9',
        scenario: 'ting',
        difficulty: 'normal',
        phrase:
          'What\'s&nbsp;this&nbsp;white&nbsp;furball...?<br>They&nbsp;seem&nbsp;to&nbsp;want&nbsp;to&nbsp;get&nbsp;out,<br>but&nbsp;are&nbsp;they&nbsp;trapped&nbsp;in&nbsp;there?',
        day: 0,
        cond: _ => 1,
      },
      {
        name: 'アリス',
        folder: '22',
        scenario: 'Alice',
        difficulty: 'hard',
        phrase: 'Experimenting?<br>What&nbsp;in&nbsp;the&nbsp;world&nbsp;are&nbsp;you&nbsp;making<br>in&nbsp;such&nbsp;a&nbsp;huge&nbsp;pot?',
        day: 0,
        cond: _ => 1,
      },
      {
        name: 'コハク',
        folder: '25',
        scenario: 'kohaku',
        difficulty: 'easy',
        phrase:
          'Is&nbsp;that&nbsp;the&nbsp;famous&nbsp;nine-tailed&nbsp;fox?<br>Now&nbsp;that\'s&nbsp;a&nbsp;beauty&nbsp;glancing&nbsp;back!<br>Not&nbsp;my&nbsp;type,&nbsp;though.<br>',
        day: 0,
        cond: _ => 1,
      },
      {
        name: 'サフィール',
        folder: '38',
        scenario: 'saphir',
        difficulty: 'easy',
        phrase: 'He\'s&nbsp;in&nbsp;the&nbsp;bath!<br>But&nbsp;let\'s&nbsp;summon&nbsp;him<br>without&nbsp;a&nbsp;care&nbsp;anyway!',
        day: 1,
        cond: _ => 1,
      },
      {
        name: 'マルス',
        folder: '20',
        scenario: 'marusu',
        difficulty: 'easy',
        phrase:
          'You&nbsp;okay?&nbsp;This&nbsp;guy\'s&nbsp;drinking<br>a&nbsp;huge&nbsp;amount&nbsp;of&nbsp;booze.<br>Looks&nbsp;like&nbsp;I&nbsp;can&nbsp;exploit<br>the&nbsp;gaps&nbsp;in&nbsp;his&nbsp;heart.',
        day: 1,
        cond: _ => 1,
      },
      {
        name: 'ネゼル',
        folder: '37',
        scenario: 'nezeru',
        difficulty: 'normal',
        phrase:
          'You\'re&nbsp;using&nbsp;matching&nbsp;mugs,<br>all&nbsp;lovey-dovey...<br>So&nbsp;this&nbsp;is&nbsp;what&nbsp;it&nbsp;means&nbsp;to&nbsp;be&nbsp;a&nbsp;normie.',
        prejump: 'syoukan_nezeru.ks',
        day: 1,
        cond: _ => 1,
      },
      {
        name: 'ミーティア',
        folder: '39',
        scenario: 'meteor',
        difficulty: 'easy',
        phrase: 'Studying,&nbsp;huh?<br>Let\'s&nbsp;go&nbsp;mess&nbsp;with&nbsp;you!<br>Keh&nbsp;keh!',
        day: 2,
        cond: _ => 1,
      },
      {
        name: 'エメロード',
        folder: '33',
        scenario: 'emeroad',
        difficulty: 'easy',
        phrase:
          'Are&nbsp;you&nbsp;a&nbsp;stalker?!<br>You\'re&nbsp;the&nbsp;worst&nbsp;scum!<br>Alright,&nbsp;I\'ll&nbsp;punish&nbsp;you!',
        day: 2,
        cond: _ => 1,
      },
      {
        name: 'パンプティ',
        folder: '34',
        scenario: 'panpu',
        difficulty: 'normal',
        phrase: 'What&nbsp;the&nbsp;heck&nbsp;is&nbsp;this&nbsp;guy?<br>His&nbsp;face&nbsp;is&nbsp;way<br>too&nbsp;close,&nbsp;man...',
        day: 2,
        cond: _ => 1,
      },
      {
        name: 'ムゥムゥ',
        folder: '31',
        scenario: 'muumuu',
        difficulty: 'hard',
        phrase:
          'Isn\'t&nbsp;that&nbsp;a&nbsp;magic&nbsp;stone<br>packed&nbsp;with&nbsp;mana?!&nbsp;But&nbsp;hey...<br>I\'ve&nbsp;seen&nbsp;this&nbsp;guy&nbsp;somewhere&nbsp;before.',
        day: 3,
        cond: _ => 1,
      },
      {
        name: 'あもあも',
        folder: '48',
        scenario: 'amoamo',
        difficulty: 'hard',
        phrase:
          'It\'s&nbsp;blurry&nbsp;and&nbsp;hard&nbsp;to&nbsp;see,<br>but&nbsp;it&nbsp;looks&nbsp;like&nbsp;a&nbsp;pool.<br>Is&nbsp;going&nbsp;in&nbsp;at&nbsp;night&nbsp;the&nbsp;trend&nbsp;now?',
        day: 3,
        cond: f => f.finished.length % 3 >= 1,
      },
      {
        name: 'ラミア',
        folder: '52',
        scenario: 'Lamia',
        difficulty: 'hard',
        phrase:
          'W-What&nbsp;a&nbsp;creepy&nbsp;one...<br>but&nbsp;we\'re&nbsp;ready&nbsp;for&nbsp;anything&nbsp;now!',
        day: 3,
        cond: f => f.finished.length % 3 >= 2,
      },
      {
        name: 'ピーター',
        folder: '59',
        scenario: 'Peter',
        difficulty: 'hard',
        phrase:
          '...This&nbsp;scenery,&nbsp;is&nbsp;it&nbsp;the&nbsp;Fountain&nbsp;of&nbsp;Souls?<br>But&nbsp;that\'s&nbsp;strange.&nbsp;Why&nbsp;would<br>a&nbsp;lowly&nbsp;creature&nbsp;be&nbsp;here...',
        day: 3,
        cond: f => f.finished.length % 3 >= 2,
      },
    ]
    const { kill } = TYRANO.kag.variable.sf
    return kill > 0 ? killed : notKilled
  },
  devilCharacters: function () {
    return [
      {
        name: 'BBB',
        folder: '64',
        scenario: 'BBB',
        phrase:
          'And&nbsp;this&nbsp;is&nbsp;Bub!<br>He&nbsp;has&nbsp;a&nbsp;bit&nbsp;of&nbsp;an<br>intimidating&nbsp;aura,&nbsp;doesn\'t&nbsp;he?',
        cond: _ => 1,
      },
      {
        name: 'あもあも',
        folder: '48',
        scenario: 'amoamo',
        phrase:
          'What&nbsp;cute&nbsp;pajamas!<br>So&nbsp;even&nbsp;Great&nbsp;Demons<br>have&nbsp;little&nbsp;kids,&nbsp;huh.',
        cond: f => f.finished.length >= 1,
      },
      {
        name: 'ナザール',
        folder: '73',
        scenario: 'nazar',
        phrase:
          'I&nbsp;don\'t&nbsp;know&nbsp;what&nbsp;happened,<br>but&nbsp;I&nbsp;hope&nbsp;you&nbsp;two<br>can&nbsp;make&nbsp;up.',
        cond: f => f.finished.length >= 2,
      },
      {
        name: 'マネコ',
        folder: '76',
        scenario: 'maneko',
        phrase:
          'She\'s&nbsp;checking&nbsp;some&nbsp;documents.<br>Perhaps&nbsp;she\'s&nbsp;in&nbsp;a&nbsp;role<br>that&nbsp;compiles&nbsp;reports.',
        cond: f => f.finished.length >= 3,
      },
      {
        name: 'D・Red',
        folder: '77',
        scenario: 'DRED',
        phrase:
          'This&nbsp;is&nbsp;D&nbsp;Red...&nbsp;Let\'s&nbsp;stay&nbsp;on&nbsp;our&nbsp;guard<br>and&nbsp;keep&nbsp;our&nbsp;wits&nbsp;about&nbsp;us.',
        cond: f => f.finished.length >= 4,
      },
      {
        name: 'ハーデスター',
        folder: '78',
        scenario: 'Hardester',
        phrase:
          'Lord&nbsp;Lucifer...!&nbsp;I&nbsp;mustn\'t&nbsp;treat&nbsp;them<br>as&nbsp;though&nbsp;they&nbsp;were&nbsp;Lucifer.',
        cond: f => f.finished.length >= 5,
      },
    ]
  },
}
