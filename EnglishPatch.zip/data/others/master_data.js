﻿TYRANO.kag.dc = {
  ...TYRANO.kag.dc,
  characters: function () {
    const notKilled = [
      {
        name: 'リリカ',
        folder: '55',
        scenario: 'Ririka',
        difficulty: 'easy',
        phrase:
          'Looks like a good start!<br>Is that what you\'ve got in your hand?<br>That trendy magic phone thing or whatever?',
        day: 0,
        cond: f => f.currentLoop >= 2,
        tutorial: true,
      },
      {
        name: 'ペイン',
        folder: '8',
        scenario: 'pain',
        difficulty: 'easy',
        phrase: 'Oh, this one looks<br>like a good start!',
        day: 0,
        cond: f => f.currentLoop >= 1,
        tutorial: true,
      },
      {
        name: 'ティング',
        folder: '9',
        scenario: 'ting',
        difficulty: 'normal',
        phrase:
          'Looks like the one next to them!<br>They seem to want to get out,<br>but are they trapped in there?',
        day: 0,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'ジェクト',
        folder: '27',
        scenario: 'ject',
        difficulty: 'normal',
        phrase:
          'Is this cyberspace?<br>Feels pretty futuristic!<br>Those clothes look like they store mana too!',
        day: 0,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'アリス',
        folder: '22',
        scenario: 'Alice',
        difficulty: 'hard',
        phrase: 'Experimenting?<br>What in the world are you making<br>in such a huge pot?',
        day: 0,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'コハク',
        folder: '25',
        scenario: 'kohaku',
        difficulty: 'easy',
        phrase:
          'Is that the famous nine-tailed fox?<br>Now that\'s a beauty glancing back!<br>Not my type, though.<br>',
        day: 0,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'アルマース',
        folder: '43',
        scenario: 'Almaz',
        difficulty: 'hard',
        phrase:
          'He\'s playing the piano!<br>But from inside the crystal,<br>you can\'t hear a thing.',
        day: 0,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'ライ',
        folder: '58',
        scenario: 'Lai',
        difficulty: 'hard',
        phrase:
          'Just lounging in the sun, huh.<br>Looks like a tough fight, but<br>is this dumb face really that strong?',
        day: 0,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'ラピス',
        folder: '47',
        scenario: 'lapis',
        difficulty: 'hard',
        phrase: 'Our eyes keep meeting, huh.<br>It\'s like he\'s looking at me or something...',
        day: 0,
        cond: f => f.currentLoop >= 3 && f.end_complete == 0,
      },
      {
        name: 'サフィール',
        folder: '38',
        scenario: 'saphir',
        difficulty: 'easy',
        phrase: 'He\'s in the bath!<br>But let\'s summon him<br>without a care anyway!',
        day: 1,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'マルス',
        folder: '20',
        scenario: 'marusu',
        difficulty: 'easy',
        phrase:
          'You okay? This guy\'s drinking<br>a huge amount of booze.<br>Looks like I can exploit the gaps in his heart.',
        day: 1,
        cond: f => f.currentLoop >= 1 && f.end_complete == 0,
      },
      {
        name: 'ネゼル',
        folder: '37',
        scenario: 'nezeru',
        difficulty: 'normal',
        phrase:
          'You\'re using matching mugs,<br>all lovey-dovey...<br>So this is what it means to be a normie.',
        prejump: 'syoukan_nezeru.ks',
        day: 1,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'ルナ',
        folder: '42',
        scenario: 'runa',
        difficulty: 'easy',
        phrase: 'A race that lives in the sea?<br>Grilled, they\'d be purr-fectly tasty!<br>Let\'s fish one up.',
        day: 1,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'フウガ',
        folder: '23',
        scenario: 'fuga',
        difficulty: 'hard',
        phrase:
          'Dual swords, huh? That\'s a rare sight.<br>Two swords must be hard to handle.<br>Show-off...',
        day: 1,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'チェシカ',
        folder: '40',
        scenario: 'chieshika',
        difficulty: 'hard',
        phrase:
          'What the heck is this guy...?<br>Is he trying to get himself summoned<br>from over there?',
        day: 1,
        cond: f => f.currentLoop >= 2,
      },
      {
        name: 'マキ',
        folder: '61',
        scenario: 'Maki',
        difficulty: 'easy',
        phrase:
          'She\'s writing something down?<br>This magic circle... it looks like<br>the one on this house\'s floor...',
        day: 1,
        cond: f => f.currentLoop >= 3,
      },
      {
        name: 'ミーティア',
        folder: '39',
        scenario: 'meteor',
        difficulty: 'easy',
        phrase: 'Studying, huh?<br>Let\'s go mess with you!<br>Keh keh!',
        day: 2,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'コニー',
        folder: '29',
        scenario: 'cony',
        difficulty: 'hard',
        phrase:
          'That getup means cops!<br>They\'re going around asking<br>the townsfolk questions.',
        day: 2,
        cond: f => f.currentLoop >= 1 && f.end_complete == 0,
      },
      {
        name: 'エメロード',
        folder: '33',
        scenario: 'emeroad',
        difficulty: 'easy',
        phrase:
          'Are you a stalker?!<br>You\'re the worst scum!<br>Alright, I\'ll punish you!',
        day: 2,
        cond: f => f.currentLoop >= 1,
      },
      {
        name: 'アレン',
        folder: '17',
        scenario: 'aren',
        difficulty: 'hard',
        phrase:
          'This one... is adorable!<br>But something in my gut<br>says he\'s dangerous.',
        day: 2,
        cond: f => f.currentLoop >= 2 && f.end_complete == 0,
      },
      {
        name: 'ミンティ',
        folder: '57',
        scenario: 'minty',
        difficulty: 'hard',
        phrase:
          'I remember this shop!<br>They sell those meow pies...<br>Brings back memories.',
        day: 2,
        cond: f =>
          f.currentLoop >= 2 && f.blueberry == 1 && f.end_complete == 0,
      },
      {
        name: 'ガク',
        folder: '32',
        scenario: 'Gaku',
        difficulty: 'hard',
        phrase:
          'Whoa, he\'s firing cannon blasts<br>from his mouth!<br>Are we really summoning this guy?<br>He seems super dangerous!',
        day: 2,
        cond: f => f.currentLoop >= 2 && f.end_complete == 0,
      },
      {
        name: 'パンプティ',
        folder: '34',
        scenario: 'panpu',
        difficulty: 'normal',
        phrase: 'What the heck is this guy?<br>His face is way<br>too close, man...',
        day: 2,
        cond: f => f.currentLoop >= 3,
      },
      {
        name: 'ムゥムゥ',
        folder: '31',
        scenario: 'muumuu',
        difficulty: 'hard',
        phrase:
          'Isn\'t that a magic stone<br>packed with mana?! But hey...<br>I\'ve seen this guy somewhere before.',
        day: 3,
        cond: f =>
          // 1周目以降、トゥルーエンドは2キャラ目かつサフィールを通っていない（通ってたらジュエリーピンク）
          (f.end_complete != 1 && f.currentLoop >= 1) ||
          (f.end_complete == 1 &&
            f.finished.length % 3 == 1 &&
            !f.finished.includes('サフィール')),
      },
      {
        name: 'ルビー',
        folder: '44',
        scenario: 'Ruby',
        difficulty: 'hard',
        phrase: 'It\'s a wine cellar!<br>Let\'s snatch some aged wine!',
        day: 3,
        cond: f =>
          // 1周目以降、トゥルーエンドは3キャラ目
          (f.end_complete != 1 && f.currentLoop >= 1) ||
          (f.end_complete == 1 && f.finished.length % 3 == 2),
      },
      {
        name: 'ジュエリーピンク',
        folder: '54',
        scenario: 'jewelrypink',
        difficulty: 'easy',
        phrase: 'Judging by that outfit, are you a maid?<br>I\'ll make you my servant!',
        day: 3,
        cond: f =>
          // 1周目以降、トゥルーエンドは2キャラ目、サフィールを通っているのは絶対条件
          f.finished.includes('サフィール') &&
          ((f.end_complete != 1 && f.currentLoop >= 1) ||
            (f.end_complete == 1 && f.finished.length % 3 == 1)),
      },
      {
        name: 'あもあも',
        folder: '48',
        scenario: 'amoamo',
        difficulty: 'hard',
        phrase:
          'It\'s blurry and hard to see,<br>but it looks like a pool.<br>Is going in at night the trend now?',
        day: 3,
        cond: f =>
          // 2周目以降、トゥルーエンドは1キャラ目
          (f.end_complete != 1 && f.currentLoop >= 2) ||
          (f.end_complete == 1 && f.finished.length % 3 == 0),
      },
      {
        name: 'ガウルォス',
        folder: '53',
        scenario: 'gauru',
        difficulty: 'hard',
        phrase:
          'What the heck is this creepy masked wolf...<br>I\'ll wring every last drop of MP out of him!',
        day: 3,
        cond: f =>
          f.currentLoop >= 2 &&
          f.finished.includes('フウガ') &&
          f.end_complete == 0,
      },
      {
        name: 'ラミア',
        folder: '52',
        scenario: 'Lamia',
        difficulty: 'hard',
        phrase:
          'W-What a creepy one...<br>but we\'re ready for anything now!',
        day: 3,
        cond: f =>
          f.currentLoop >= 2 &&
          f.finished.includes('ガウルォス') &&
          f.end_complete == 0,
      },
      {
        name: 'ピーター',
        folder: '59',
        scenario: 'Peter',
        difficulty: 'hard',
        phrase:
          '...This scenery, is it the Fountain of Souls?<br>But that\'s strange. Why would<br>a lowly creature be here...',
        day: 3,
        cond: f =>
          f.currentLoop >= 3 &&
          f.finished.length % 3 == 2 &&
          f.end_complete == 0,
        prejump: 'syoukan_Peter.ks',
      },
    ]
    const killed = [
      {
        name: 'ティング',
        folder: '9',
        scenario: 'ting',
        difficulty: 'normal',
        phrase:
          'What\'s this white furball...?<br>They seem to want to get out,<br>but are they trapped in there?',
        day: 0,
        cond: _ => 1,
      },
      {
        name: 'アリス',
        folder: '22',
        scenario: 'Alice',
        difficulty: 'hard',
        phrase: 'Experimenting?<br>What in the world are you making<br>in such a huge pot?',
        day: 0,
        cond: _ => 1,
      },
      {
        name: 'コハク',
        folder: '25',
        scenario: 'kohaku',
        difficulty: 'easy',
        phrase:
          'Is that the famous nine-tailed fox?<br>Now that\'s a beauty glancing back!<br>Not my type, though.<br>',
        day: 0,
        cond: _ => 1,
      },
      {
        name: 'サフィール',
        folder: '38',
        scenario: 'saphir',
        difficulty: 'easy',
        phrase: 'He\'s in the bath!<br>But let\'s summon him<br>without a care anyway!',
        day: 1,
        cond: _ => 1,
      },
      {
        name: 'マルス',
        folder: '20',
        scenario: 'marusu',
        difficulty: 'easy',
        phrase:
          'You okay? This guy\'s drinking<br>a huge amount of booze.<br>Looks like I can exploit<br>the gaps in his heart.',
        day: 1,
        cond: _ => 1,
      },
      {
        name: 'ネゼル',
        folder: '37',
        scenario: 'nezeru',
        difficulty: 'normal',
        phrase:
          'You\'re using matching mugs,<br>all lovey-dovey...<br>So this is what it means to be a normie.',
        prejump: 'syoukan_nezeru.ks',
        day: 1,
        cond: _ => 1,
      },
      {
        name: 'ミーティア',
        folder: '39',
        scenario: 'meteor',
        difficulty: 'easy',
        phrase: 'Studying, huh?<br>Let\'s go mess with you!<br>Keh keh!',
        day: 2,
        cond: _ => 1,
      },
      {
        name: 'エメロード',
        folder: '33',
        scenario: 'emeroad',
        difficulty: 'easy',
        phrase:
          'Are you a stalker?!<br>You\'re the worst scum!<br>Alright, I\'ll punish you!',
        day: 2,
        cond: _ => 1,
      },
      {
        name: 'パンプティ',
        folder: '34',
        scenario: 'panpu',
        difficulty: 'normal',
        phrase: 'What the heck is this guy?<br>His face is way<br>too close, man...',
        day: 2,
        cond: _ => 1,
      },
      {
        name: 'ムゥムゥ',
        folder: '31',
        scenario: 'muumuu',
        difficulty: 'hard',
        phrase:
          'Isn\'t that a magic stone<br>packed with mana?! But hey...<br>I\'ve seen this guy somewhere before.',
        day: 3,
        cond: _ => 1,
      },
      {
        name: 'あもあも',
        folder: '48',
        scenario: 'amoamo',
        difficulty: 'hard',
        phrase:
          'It\'s blurry and hard to see,<br>but it looks like a pool.<br>Is going in at night the trend now?',
        day: 3,
        cond: f => f.finished.length % 3 >= 1,
      },
      {
        name: 'ラミア',
        folder: '52',
        scenario: 'Lamia',
        difficulty: 'hard',
        phrase:
          'W-What a creepy one...<br>but we\'re ready for anything now!',
        day: 3,
        cond: f => f.finished.length % 3 >= 2,
      },
      {
        name: 'ピーター',
        folder: '59',
        scenario: 'Peter',
        difficulty: 'hard',
        phrase:
          '...This scenery, is it the Fountain of Souls?<br>But that\'s strange. Why would<br>a lowly creature be here...',
        day: 3,
        cond: f => f.finished.length % 3 >= 2,
      },
    ]
    const { kill } = TYRANO.kag.variable.sf
    return kill > 0 ? killed : notKilled
  },
  devilCharacters: function () {
    return [
      {
        name: 'BBB',
        folder: '64',
        scenario: 'BBB',
        phrase:
          'And this is Bub!<br>He has a bit of an<br>intimidating aura, doesn\'t he?',
        cond: _ => 1,
      },
      {
        name: 'あもあも',
        folder: '48',
        scenario: 'amoamo',
        phrase:
          'What cute pajamas!<br>So even Great Demons<br>have little kids, huh.',
        cond: f => f.finished.length >= 1,
      },
      {
        name: 'ナザール',
        folder: '73',
        scenario: 'nazar',
        phrase:
          'I don\'t know what happened,<br>but I hope you two<br>can make up.',
        cond: f => f.finished.length >= 2,
      },
      {
        name: 'マネコ',
        folder: '76',
        scenario: 'maneko',
        phrase:
          'She\'s checking some documents.<br>Perhaps she\'s in a role<br>that compiles reports.',
        cond: f => f.finished.length >= 3,
      },
      {
        name: 'D・Red',
        folder: '77',
        scenario: 'DRED',
        phrase:
          'This is D Red... Let\'s stay on our guard<br>and keep our wits about us.',
        cond: f => f.finished.length >= 4,
      },
      {
        name: 'ハーデスター',
        folder: '78',
        scenario: 'Hardester',
        phrase:
          'Lord Lucifer...! I mustn\'t treat them<br>as though they were Lucifer.',
        cond: f => f.finished.length >= 5,
      },
    ]
  },
}
