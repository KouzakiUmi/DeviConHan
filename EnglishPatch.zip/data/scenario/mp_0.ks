﻿[_tb_system_call storage=system/_mp_0.ks]

[eval exp="f.zeroPoint++"]
[comment  c="セリフを飛ばす...アルマース、あもあも、ガウルォス、ジュエピ、コハク、ラミア、パンプ、ルビー"  ]
[return cond="['アルマース','あもあも','ガウルォス','ジュエリーピンク','コハク','ラミア','パンプ','ルビー'].includes(f.chara.name)"]

[if exp="f.day==0"]

[comment  c="0日目"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
[if exp="sf.kill == 0][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/84.png"  ][else][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/151.png"  ][endif]
[_tb_end_text]

[if exp="f.zeroPoint==1"]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0]...Still, all three emotional auras[r]are sewer-sludge colored.[p]We just started, and you're already tired? Jeez.[p][else]...Still, all three emotional auras[r]are sewer-sludge colored.[p]And you call yourself a demon fanatic? Sheesh.[p][endif]
[_tb_end_text]

[elsif exp="f.zeroPoint==2"]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0]...What, again?[r]All three emotional auras are sewer-sludge colored.[p]You really are hopeless at this, huh?[p][else]...What, again? All three emotional auras are[r]sewer-sludge colored.[p]What, are you short on faith in yours truly?[p][endif]
[_tb_end_text]

[elsif exp="f.zeroPoint==3"]

[tb_start_text mode=1 ]
#Devilun
...Haaah.[r]Now that I look closer,[r]your emotional aura's sewer-sludge colored again.[p]There's an MP check coming up, you know. Got that?[p]
[_tb_end_text]

[endif]

[elsif exp="f.day==1"]

[comment  c="1日目"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
[if exp="sf.kill == 0][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/84.png"  ][else][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/151.png"  ][endif]
[_tb_end_text]

[if exp="f.zeroPoint==1"]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0]...Still, all three emotional auras[r]are sewer-sludge colored.[p]We're barely getting started...Are you off today?[p][else]...Still, all three emotional auras[r]are sewer-sludge colored.[p]We're barely getting started, so get to work.[p][endif]
[_tb_end_text]

[elsif exp="f.zeroPoint==2"]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0]...What, all three emotional auras are[r]sewer-sludge colored again.[p]Guess you just don't have the talent for this.[p][else]...What, all three emotional auras are[r]sewer-sludge colored again, aren't they?[p]And you call yourself a demon fanatic?[p][endif]
[_tb_end_text]

[elsif exp="f.zeroPoint==3"]

[tb_start_text mode=1 ]
#Devilun
...What, now that I look closer,[r]your emotional aura's sewer-sludge colored again.[p]You're really going into an MP check like that?[p]
[_tb_end_text]

[endif]

[elsif exp="f.day==2"]

[comment  c="2日目"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
[if exp="sf.kill == 0][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/84.png"  ][else][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/151.png"  ][endif]
[_tb_end_text]

[if exp="f.zeroPoint==1"]

[tb_start_text mode=1 ]
#Devilun
...Still, all three emotional[r]auras are sewer-sludge colored.[p]Don't get cocky just because you're improving.[p]
[_tb_end_text]

[elsif exp="f.zeroPoint==2"]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0]...What, all three emotional auras are[r]sewer-sludge colored again.[p]Taking it easy on purpose, huh?[p][else]...What, all three emotional auras are[r]sewer-sludge colored again.[p]Your faith isn't strong enough.[p][endif]
[_tb_end_text]

[elsif exp="f.zeroPoint==3"]

[tb_start_text mode=1 ]
#Devilun
...What, now that I look closer,[r]your emotional aura's sewer-sludge colored again.[p]You'll be learning the hard way soon enough.[p]
[_tb_end_text]

[endif]

[elsif exp="f.day==3"]

[comment  c="3日目"  ]
[tb_start_tyrano_code]
[keyframe name="fuwakoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマでび" keyframe="fuwakoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=4 ]
[if exp="sf.kill == 0][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/151.png"  ][else][chara_mod  name="コマでび"  time="0"  cross="false"  storage="chara/10/145.png"  ][endif]
[_tb_end_text]

[if exp="f.zeroPoint==1"]

[tb_start_text mode=1 ]
#Devilun
[if exp="sf.kill == 0]...Wait.[r]Now that I look closer,[r]all three emotional auras are sewer-sludge colored...[p]After all this, will you betray yours truly?[p][else]...Wait.[r]Now that I look closer,[r]your emotional aura's sewer-sludge colored...[p]After all this, will you betray yours truly?[p][endif]
[_tb_end_text]

[elsif exp="f.zeroPoint==2"]

[tb_start_text mode=1 ]
#Devilun
...What, your emotional aura's sewer-sludge colored again.[p]I knew it.[r]You're planning to betray me after all.[p]
[_tb_end_text]

[elsif exp="f.zeroPoint==3"]

[tb_start_text mode=1 ]
#Devilun
...Well, just as expected,[r]your emotional aura's sewer-sludge colored.[p]The MP check is next. Just sit there and tremble.[p]
[_tb_end_text]

[endif]

[endif]

[return  ]
