﻿[_tb_system_call storage=system/_gekizyou_END43.ks]

[cm  ]
[bg_loop name="gekizyo2"]

[chara_show  name="劇場でび"  time="0"  wait="false"  storage="chara/15/dagya5.png"  width="523"  height="551"  left="598"  top="164"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_show  name="ちび悪魔"  time="0"  wait="false"  storage="chara/72/23.png"  width="539"  height="526"  left="151"  top="192"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-10"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[stopse  time="300"  buf="1"  fadeout="true"  ]
[wait  time="500"  ]
[call  storage="maku.ks"  target="*open_gekizyou"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="5_theater.ogg"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Hadester
[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="true"  storage="chara/72/24.png"  ]
[tb_start_text mode=1 ]
#Hadester
At long last, the Rushadagya Theater is here.[r]And today, for the poor little lambs...[p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="700" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="劇場でび"  time="0"  cross="true"  storage="chara/15/dagya36.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=50]Hold up, hold up, hold up--![resetfont][p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="劇場でび"  time="0"  cross="true"  storage="chara/15/dagya3.png"  ]
[tb_start_text mode=1 ]
#Devilun
W-what was that chant just now?[r]What brought that on?[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="true"  storage="chara/72/25.png"  ]
[tb_start_text mode=1 ]
#Hadester
This segment has been a long-held dream of mine.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[font size=50]A long-held dream!?[resetfont][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Hadester
Heh... I've waited so long for this moment.[r]I got a little carried away.[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="true"  storage="chara/15/dagya55.png"  ]
[tb_start_text mode=1 ]
#Devilun
You...Just who are you?[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="true"  storage="chara/72/24.png"  ]
[tb_start_text mode=1 ]
#Hadester
If you wish to know, you must receive a boon[r]through our master's Load spell.[p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="700" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="劇場でび"  time="0"  cross="true"  storage="chara/15/dagya7.png"  ]
[tb_start_text mode=1 ]
#Devilun
[emb exp="f.name"]~! Do something about this![p]
[_tb_end_text]

[tb_eval  exp="sf.END43=1"  name="END43"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[jump  storage="gekizyou_END_menu.ks"  target=""  ]
