﻿[_tb_system_call storage=system/_gekizyou_END40.ks]

[cm  ]
[bg_loop name="gekizyo2"]

[chara_show  name="劇場でび"  time="0"  wait="false"  storage="chara/15/dagya53.png"  width="523"  height="551"  left="598"  top="164"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_show  name="ちび悪魔"  time="0"  wait="false"  storage="chara/72/8.png"  width="504"  height="491"  left="193"  top="207"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="3000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[stopse  time="300"  buf="1"  fadeout="true"  ]
[wait  time="500"  ]
[call  storage="maku.ks"  target="*open_gekizyou"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="5_theater.ogg"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Nazar
Nnnngh...[r]I feel absolutely miserable.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Hey, hey. Seriously, though--[r]what happened back then?[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/9.png"  ]
[tb_start_text mode=1 ]
#Nazar
You mean the mirror...? Like I'd tell you.[r]Hold on, what is this segment?![r]What happened to our fight?[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya38.png"  ]
[tb_start_text mode=1 ]
#Devilun
C'mon, don't sweat the small stuff.[r]Anything goes in this segment![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Come on, Levi♥ Please, tell meee![p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/10.png"  ]
[tb_start_text mode=1 ]
#Nazar
Sheesh... all right.[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya9.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=25]Yep, he's still a pushover when I lay it on thick.[resetfont][p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/8.png"  ]
[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya1.png"  ]
[tb_start_text mode=1 ]
#Nazar
...Long ago, in a certain[r]country in the Human Realm, I used the Evil[r]Eye of Envy to bewitch people's hearts.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nazar
Then... a mirror was suddenly held up to me,[r]and I ended up looking like I was rejecting it.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nazar
They must've thought a mirror[r]could reflect my Evil Eye back at me.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/9.png"  ]
[tb_start_text mode=1 ]
#Nazar
The rumor spread;[r]soon they made charms against the Evil Eye[r]modeled almost exactly on my own...[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya5.png"  ]
[tb_start_text mode=1 ]
#Devilun
I think I saw one in Magirisia, too.[r]...A charm that looks just like your Evil Eye? Creepy.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/8.png"  ]
[tb_start_text mode=1 ]
#Nazar
Yeah... Every time I see one,[r]I smash the glass charm. Infuriating...[r]Being afraid of mirrors is just superstition.[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya54.png"  ]
[tb_start_text mode=1 ]
#Devilun
So... maybe you rejected the mirror because[r]you hated the face staring back at you?[p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" x="0"]
[frame p="50%" x="-3"]
[frame p="100%" x="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="100" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/11.png"  ]
[tb_start_text mode=1 ]
#Nazar
Guh!?[p]

[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya41.png"  ]
[tb_start_text mode=1 ]
#Devilun
...Hit a nerve, huh? Asmodeus once told me[r]you didn't use to hide your face behind your hair.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/12.png"  ]
[tb_start_text mode=1 ]
#Nazar
Tch, Asmodeus is always butting in![r]I-I'm not lifting my bangs! Like I'd let you see![p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya20.png"  ]
[tb_start_text mode=1 ]
#Devilun
Well, it's not like I was gonna[r]force you to show me.[p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="3000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/10.png"  ]
[tb_start_text mode=1 ]
#Nazar
...Knowing you, you probably think you've[r]got leverage on me.[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya24.png"  ]
[tb_start_text mode=1 ]
#Devilun
...Whatever your mug looks like,[r]I couldn't care less.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/10.png"  ]
[tb_start_text mode=1 ]
#Nazar
...[p]
[_tb_end_text]

[jump  storage="gekizyou_END_menu.ks"  target=""  ]
