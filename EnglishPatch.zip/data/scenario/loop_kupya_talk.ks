﻿[_tb_system_call storage=system/_loop_kupya_talk.ks]

[chara_show  name="クピャドエル"  time="0"  wait="false"  storage="chara/14/1.png"  width="1280"  height="960"  ]
[comment  c="お話する"  ]
[comment  c="名前を前の周回から変更する"  ]
*name

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
By the way, [emb exp="f.name"]--you changed your name, didn't you!?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But even using an alias,[r]it seems you can't escape your contract with a demon.[p]
[_tb_end_text]

[return  ]
[comment  c="性別を前の周回から変更する"  ]
*gender

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[emb exp="f.name"]...[r]You even changed your gender with magic, didn't you!?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.hutanari == 1"]And this time, you've got both, too! What a bargain~♪[else]I can become either one as well, so I'm happy♪[r]Let's have a sword fight sometime, shall we?♪[endif][p]

[_tb_end_text]

[return  ]
[comment  c="でびるんという名前を褒める"  ]
*name_suteki

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
The name Devilun is lovely![r]I'm honored to call him Devi-kun, too![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I didn't know what to call you before[delay speed=100]...[resetdelay][r]I was so troubled.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Having been given a name,[r]Devi-kun must be very happy too.[p]
[_tb_end_text]

[return  ]
[comment  c="悪魔を召喚するなんて悪い"  ]
*yokumosyoukan

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Honestly, summoning a demon...[r][emb exp="f.name"], you're a bad child.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/28.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...When you've given up on everything, I understand[r]the urge to do something you shouldn't.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But if you stop[r]helping Devi-kun by gathering mana and the like[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
This time, [emb exp="f.name"] is in danger,[r]with their soul in his grasp.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
It is our duty as angels to correct[r]the mistakes of troubled,[r]unstable lambs like you, and protect them.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
So please don't worry! I won't let the demon[r]do whatever he pleases with [emb exp="f.name"]![p]
[_tb_end_text]

[return  ]
[comment  c="読書のすすめ"  ]
*hon

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Did you read the book last night?[r]I hope you'll find a clue to Devi-kun's true name...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
It would be nice if we could borrow books from[r]someone knowledgeable about demons, too.[p]
[_tb_end_text]

[return  ]
[comment  c="ニセドエル"  ]
*nise

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I was caught up with something urgent and couldn't[r]answer the door just now, so I'm sorry.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
It seems Nisedoeru[r]answered it for me instead![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Nisedoeru is a fellow[r]angel from my cohort, you know.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/5.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
By the way, I'm the one who[r]gave her that name♪[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
When the Archangel gave her a name,[r]I was the one who suggested it.[p]

[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
The second generation carrying on spirited[r]Isedoel's will[delay speed=100]...[resetdelay] That's right--Nisedoeru![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah[delay speed=100]...[resetdelay] The Archangel approved it, too,[r]and that was a fond memory.[p]
[_tb_end_text]

[eval exp="f.nise=3"]

[return  ]
[comment  c="真の名の公言はお気を付けを"  ]
*hokanokata

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I hope everyone you summon will[r]give you hints to Devi-kun's true name, too.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But if anyone other than the contractor casually[r]speaks a demon's true name...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
If it's the name of a high-ranking[r]demon, they won't get off lightly. That's[r]simply demonic nature... It's their instinct.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/17.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I won't say what would happen, since[r]even speaking of it is taboo, so I'll keep quiet![r]Please be careful about that, all right?[p]
[_tb_end_text]

[return  ]
[comment  c="ヒントに関して"  ]
*hint

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
The hints I give you are simply what I see[r]through the True Eye.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
What I can see changes from day to day,[r]and things I just saw may suddenly[r]vanish from sight, so it is rather unstable...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'd be glad if I could help [emb exp="f.name"], as I believe[r]we can find an ending where everyone is happy...[p]
[_tb_end_text]

[return  ]
[comment  c="お手伝い"  ]
*otetudai

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Somehow, I feel like [emb exp="f.name"] will guide this world[r]in a better direction.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
So I want to give you my full cooperation![r]That's why I'm happy you came to rely on me.[p]




[_tb_end_text]

[return  ]
[comment  c="正直甘く見てました"  ]
*syo

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay] To be honest, I underestimated it.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.bel_name_first == 1]If you call Devi-kun by name, you can safely[r]reach a happy ending[delay speed=100]...[resetdelay] ...that's what I thought.[else]If you call Devi-kun by name, you can stop him safely and[r]reach a happy ending[delay speed=100]...[resetdelay] ...that's what I thought.[endif][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But that doesn't mean the possibility of happiness[r]has been cut off.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah, I won't give up![p]
[_tb_end_text]

[return  ]
[comment  c="可能性"  ]
*kanousei

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
There must be possibilities for happiness[r]scattered here and there.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Let's look for them![r]Using what the True Eye reveals as our guide,[r]we'll find all sorts of endings![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I'm sure [emb exp="f.name"]'s recorded[r][font color=0xEC6FC5 bold=true]ending list[resetfont] will be a clue too.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
There are [font color=0xEC6FC5 bold=true]30[resetfont] possible endings at the moment, and[r][font color=0xEC6FC5 bold=true]the number you've found so far is [emb exp="dc.endCount()"][resetfont]...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Somewhere, a happy ending... yes,[r][font color=0xEC6FC5 bold=true]a True Ending[resetfont] must be waiting for us![p]
[_tb_end_text]

[return  ]
[comment  c="おわり"  ]
*owari

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_tyrano_code]
[if exp="f.kupya_owari == 0"]
#Kupyadel
I'm afraid there's nothing left for us to talk about,[r]so I hope you'll understand
[elsif exp="f.kupya_owari == 1"]
#Kupyadel
My talk deck is completely empty now.
[elsif exp="f.kupya_owari == 2"]
#Kupyadel
Shall we talk about the weather?
[elsif exp="f.kupya_owari == 3"]
#Kupyadel
You could start a topic every now and then, too, [emb exp="f.name"]!
[elsif exp="f.kupya_owari == 4"]
#Kupyadel
You're surprisingly an attention seeker, aren't you, [emb exp="f.name"]?
[elsif exp="f.kupya_owari == 5"]
#Kupyadel
You should pay Devi-kun some attention too, you know?
[elsif exp="f.kupya_owari == 6"]
#Kupyadel
I feel like poking Devi-kun's horns--poke poke!
[elsif exp="f.kupya_owari == 7"]
#Kupyadel
[if exp="f.currentLoop == 1]Fuwa-kupyaa~[else]If you want some advice,[r]just say the word.[endif]
[elsif exp="f.kupya_owari == 8"]
#Kupyadel
[if exp="f.currentLoop == 1][else]Kupyaa~[endif] I'm starting to feel sleepy.
[elsif exp="f.kupya_owari == 9"]
#Kupyadel
Actually... with this appearance, my eyes are closed, so[r]no one will notice if I sneak off to sleep in the church.
[elsif exp="f.kupya_owari == 10"]
#Kupyadel
I'll leave it to you to decide whether I'm really asleep or just pretending.
[elsif exp="f.kupya_owari == 11"]
#Kupyadel
Snooo~[delay speed=100]...[resetdelay]
[else]
#Kupyadel
Snooo~[delay speed=100]......[resetdelay]
[endif]
[p]
[_tb_end_tyrano_code]

[tb_eval  exp="f.kupya_owari+=1"  name="kupya_owari"  cmd="+="  op="t"  val="1"  val_2="undefined"  ]
[return  ]
[comment  c="神眼について"  ]
*eye_true

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
My belly eye isn't an Evil Eye! An angel's[r]belly eye is called the Divine Eye, you know![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Of them all, the True Eye, which lets me[r]see the truth, is especially difficult to handle.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
If I steady my mind and focus on the heart of a matter,[r]it sometimes hazily comes into view...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Sometimes information just slips[r]into my thoughts out of nowhere... Cupyah,[r]I wish I could learn to use it better.[p]

[_tb_end_text]

[return  ]
[comment  c="邪眼閉じてる？"  ]
*zyagan2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/28.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
In this form, I keep the eyes on my face closed[r]so I can focus on my True Eye and avoid visual noise.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
That's how important the belly eye is to a Spirit[r]God, so it is generally kept open at all times...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.koukai_kidoku"]I understand now, through the flashback,[r]why he always keeps it closed.[r]To think Devi-kun had a past like that... it pains me[else]Why does Devi-kun always keep his closed?[r]I imagine it's just too much trouble, though...[endif][p]
[_tb_end_text]

[return  ]
[comment  c="オッドアイ"  ]
*eye

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Did you think that I had odd[r]eyes too when I opened them...?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Only high-ranking angels and demons have odd eyes...[p]

[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Hence, a lowly middle-class angel like me has[r]the same color in both eyes on my face.[p]
[_tb_end_text]

[return  ]
[comment  c="でかくぴゃ"  ]
*dekakupya

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
My large form...[if exp="f.currentLoop == 1][r]I startled you, didn't I[else]I keep[r]startling you every time; I'm sorry[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
As for why I use "boku" as my first-person pronoun...[r]it's just an old habit.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I used to imitate the Archangel I admired,[r]but the other angels made snide remarks about it...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
At least in my small form,[r]I make a point of speaking more formally.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
To fake who I am over something like this...[r]it's rather silly, isn't it?[p]
[_tb_end_text]

[return  ]
[comment  c="ダギャマキコ"  ]
*makiko

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I tried guessing Devi-kun's true name![r]It's only a guess, so feel free to ignore it...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Since he has a verbal tic like mine,[r]I think it must be related to his name![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I think it's probably Dagya-something or other...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
How about "Dagyamakiko"?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=300]...[resetdelay] Makiko was just something I made up.[p]
[_tb_end_text]

[return  ]
[comment  c="ダギャマキコ"  ]
*makiko2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
What could Devi-kun's true name possibly be...?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If only we knew that, we could stop Devi-kun's rampage.[r]Let's search hard! Heave-ho, heave-ho![p]
[_tb_end_text]

[return  ]
[comment  c="真の名探そう"  ]
*name_sagashi

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
For now, let's focus on finding[r]Devi-kun's true name[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
If we force Devi-kun to stop now,[r][emb exp="f.name"]'s life will be in danger[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But even under an unfair contract,[r]once we know his name, we've got the upper hand![p]
[_tb_end_text]

[return  ]
[comment  c="神のロード魔法リスポーン"  ]
*re

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I saw Devi-kun's sad ending and thought...[r]If only we could start over one more time...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/15.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Then, the instant [emb exp="f.name"] opened the book,[r]I was teleported back to the Fountain of Souls--[r]and it startled me.[p]
[_tb_end_text]

[mind_voice  color="0xfffb7a"  name="Kupyadel"  text="Maybe this is thanks to our provisional contract..."  face="KaiseiDecol-Bold"  ]
[tb_start_text mode=1 ]
#Kupyadel
It made me happy,[r]as though our feelings had reached each other.[r]The Load spell is practically divine, isn't it![p]
[_tb_end_text]

[reset_mind_voice  ]
[return  ]
[comment  c="支えになれて嬉しい"  ]
*hitori

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Each time we repeat it[if exp="f.currentLoop == 2][else]--over and over[endif],[r]I try to think, "I'm glad it worked out."[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Though it's not perfect,[r]being able to carry memories over[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[mind_voice  color="0x2ea6b6"  name="？？？"  text="You're not alone."  face="Yawamin"  ]
[tb_start_text mode=1 ]
#Kupyadel
Otherwise, [emb exp="f.name"] would have been[r]all alone in this loop this whole time.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
When I think of it that way, I'm glad that I can be[r]a source of support for [emb exp="f.name"].[p]
[_tb_end_text]

[reset_mind_voice  ]
[return  ]
[comment  c="目玉でび、本質"  ]
*medama

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/12.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
S-sorry, thinking about Devi-kun made me flash back...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
...We succeeded in stopping him, but Devi-kun[r]ended up as nothing but eyes.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
It was so painful to look at that I[r]covered my eyes and panicked.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
...No matter what form Devi-kun takes,[r][emb exp="f.name"] never changes their attitude even a little.[r]That's amazing.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/23.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
That's your way of showing that[r]you'll accept Devi-kun in any form, isn't it, [emb exp="f.name"]?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[emb exp="f.name"] truly sees the essence of Devi-kun.[r]That's an amazing thing, something not easily done.[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
[delay speed=100]・・・[resetdelay]
[_tb_end_text]

[return  ]
[comment  c="結婚"  ]
*wedding

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Marriage should be something happy, yet Devi-kun[r]looked utterly miserable in his wedding clothes.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Um... but I don't think he hated being married to [emb exp="f.name"]![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Because he feared being looked[r]down on by the people of the Demon Realm.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If only he could break free from[r]the shackles of the Demon Realm[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But I suppose the same can be said of me,[p]since I suppress my own[r]feelings and follow the rules of the Heavenly Realm.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...It's so difficult to be yourself[r]without worrying about how others see you...[p]
[_tb_end_text]

[return  ]
[comment  c="食べられる"  ]
*BBB

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Forget everything and start over from scratch[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Was that really[r]the best possible answer for Devi-kun?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
They say ignorance can sometimes be bliss,[r]but somehow I still can't accept it[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[return  ]
[comment  c="記憶がない"  ]
*lord

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...I'm sorry to ask this, but you've[r]failed to stop NEO Devilun, haven't you?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I saw this through the eye of truth.[r]Was it a supernova?[r]Everything went white before me, and then...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
That's why I thought it was amazing that [emb exp="f.name"][r]you managed to start over safely...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If you managed to cast the Load[r]spell in the middle of that, nice work![p]
[_tb_end_text]

[return  ]
[comment  c="lordはじめから"  ]
*lord2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
You failed to stop NEO Devilun, didn't you?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
It was only for an instant, but my body grew hot[r]and I felt as if I were melting...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
So that's what it feels like to disappear...[r]Somehow, I don't think it was all that painful[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But you managed to load[r]safely to the checkpoint without being swallowed[r]by that supernova--nice work![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
As expected of you, [emb exp="f.name"]!
[_tb_end_text]

[return  ]
[comment  c="天界おしゃれ"  ]
*tenkai

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Angels rise early![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
In the morning, we wash our faces[r]at the fountain, fix our bangs, pat on some[r]Angel Powder... then put on our earmuffs![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/5.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
All angels are fashionistas♪
[_tb_end_text]

[return  ]
[comment  c="ループ多い5"  ]
*loop5

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
By my count, you've looped[r]already [emb exp="f.currentLoop-1"] times[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
No matter how much stamina you have, your heart[r]will wear down. Please don't push yourself too hard[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]Even when I say that,[r]I don't sound very convincing, do I?[p]
[_tb_end_text]

[comment  c="ループ多い10"  ]
*loop10

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
By my count, you've started over[r]already [emb exp="f.currentLoop-1"] times[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[emb exp="f.name"][delay speed=100]...[resetdelay][r]A-are you all right?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]......[resetdelay]I'm worried.[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
[delay speed=100]・・・[resetdelay]
[_tb_end_text]

[return  ]
[comment  c="胸ぐら"  ]
*munagura

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
P-please don't worry![r]Look, I'm full of energy now![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If even an angel like me wasn't smiling,[r]you'd be worried too, [emb exp="f.name"]![p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
I'm sorry for worrying you! Um...[wait time=300]
[_tb_end_text]

[return  ]
[comment  c="胸ぐらloop2"  ]
*munagura2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]I'm sorry for worrying you yesterday[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Being touched by Devi-kun...[r]made me happy...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/25.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah!? What I just said is a secret[r]from everyone in the Heavenly Realm![p]
[_tb_end_text]

[return  ]
[comment  c="胸ぐらloop3"  ]
*munagura3

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/12.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]Y-yesterday, I'm sorry[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Being touched by Devi-kun is the only[r]happiness I have in these repeating days...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
To think I can only enjoy[r]happiness through something like this...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/25.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
I mustn't get negative like this!
[_tb_end_text]

[return  ]
[comment  c="胸ぐらloop4_これから"  ]
*munagura4

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]I'll get to be touched by Devi-kun again tonight[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/23.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=300]...[resetdelay]Devi-kun[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
Hah-s...sorry[r][wait time=300]
[_tb_end_text]

[return  ]
[comment  c="ラズベリーパイ"  ]
*raspberry

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devi-kun was all sticky with yesterday's jam...[r]The way he ate it was so clumsy and adorable♥[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/9.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Speaking of raspberry pie[delay speed=300]...[resetdelay][r]it's giving me such nostalgia.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/6.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
Ah, no[delay speed=100]...[resetdelay] Never mind, it's nothing.
[_tb_end_text]

[return  ]
[comment  c="ブルーベリーパイ"  ]
*blueberry

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
So you ate blueberry pie last night instead[r]of raspberry pie![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I think it was Devi-kun's mistake,[r]but it's fascinating that even though the same[r]time repeats, things can change like this.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Maybe our actions are causing a shift[r]in time and changing events...[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
It might be what they call the butterfly effect![p]
[_tb_end_text]

[return  ]
[comment  c="パイ"  ]
*pie

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I caught a glimpse through the window! The[r][if exp="f.blueberry == 1"]blueberry[else]raspberry[endif] pie you ate yesterday... It looked delicious![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'm not very good with sour flavors, so[r]I want a sweet custard pie with lots of cream.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Someday, let's all have some custard pie too...[p]
[_tb_end_text]

[return  ]
[comment  c="吐き気"  ]
*haku

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.currentLoop == 1]Devi-kun looks kind of sick...[else]Devi-kun still looks sick as ever...[r]watching him just makes my heart ache.[endif][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.currentLoop == 1]That's nausea from having too much mana;[r]it must be too much for such a small body.[else]It's too much for such a small body, so why...[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.currentLoop == 1]...I just can't understand why he would go so far[r]to gather mana.[else]...I feel like I'm gradually starting to understand[r]what drives Devi-kun to go so far.[endif][p]
[_tb_end_text]

[return  ]
[comment  c="分かった"  ]
*haku2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devi-kun could just stay Devi-kun even[r]without becoming something like that...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
How can I make Devi-kun realize that?[p]
[_tb_end_text]

[return  ]
[comment  c="獰猛"  ]
*zyagan

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.currentLoop == 1]I feel like the Evil Eye is starting to take over his[r]personality and make him violent.[else]Devi-kun... it feels like the Evil Eye is[r]starting to take over his personality, making him violent...[endif][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.currentLoop == 1]That's not Devi-kun![r]I'm so worried...[else]He's even starting to lose his five senses...[r]What could he possibly want so badly that he'd go that far?[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=300]・・・[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
[delay speed=100]...[resetdelay]Let me collect myself. Um,
[_tb_end_text]

[return  ]
[comment  c="気付き"  ]
*ki

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devi-kun just hasn't realized[r]what he truly wants yet.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/8.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
There are things you only[r]realize after losing them... We have to help him[r]realize them before he loses them.[p]
[_tb_end_text]

[return  ]
[comment  c="明日が憂鬱"  ]
*utu

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/13.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]Ghh-[if exp="f.kupya_syouziki == 1]after all[else]honestly[endif]![p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/13.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.kupya_syouziki == 1]After all[delay speed=100]...[resetdelay] this is the day I start dreading tomorrow[else][delay speed=100]...[resetdelay] Honestly, I'm dreading tomorrow[endif][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
With Devi-kun suffering right before me,[r]I can't do a thing.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/14.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]If only I had more power,[r]I could lead everyone to happiness.[p]
[_tb_end_text]

[tb_eval  exp="f.kupya_syouziki=1"  name="kupya_syouziki"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[memory name="kupya_syouziki" val="1"]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/12.png"  ]
[tb_start_text mode=4 ]
#Kupyadel
[delay speed=200]...[resetdelay]Excuse me, um...[wait time=300]
[_tb_end_text]

[return  ]
[comment  c="天使について"  ]
*tenshi

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/28.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Everyone in the Human Realm[r]often misunderstands us, but...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Angels originally exist in the[r]Human Realm to preserve the balance of good and[r]evil and confront demons that amplify evil.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
So angels are discouraged from[r]interfering with people in the Human Realm.[p]Even if that person has already been led[r]astray by a demon...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
That's the exorcist's job. We angels must[r]take action before someone is led astray by a demon...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
So although we pray for the happiness of everyone[r]in the Human Realm,[p]we are hardly grand beings capable of leading[r]every single person to happiness.[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...But I still want to live up to everyone's[r]expectations as much as I can.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
For [emb exp="f.name"], who made a contract with Devi-kun...![p]

[_tb_end_text]

[return  ]
[comment  c="エンドコンプ_未使用"  ]
*complete

[tb_start_text mode=1 ]
#Kupyadel
All the endings I can see with the True[r]Eye have been collected, haven't they?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]But judging by your expression,[r]you haven't found the ideal ending, have you?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/19.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]・・・[resetdelay][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But![delay speed=100]...[resetdelay] We mustn't give up yet![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Because the law of causality has changed,[r]I believe we can still save Devi-kun somewhere.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[font size=32]Let's move forward without giving up hope[r]until the very end![resetfont][p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]I feel I can still see[r]a faint glimmer of hope through the True Eye.[p]
[_tb_end_text]

[return  ]
[comment  c="エンドコンプ2_未使用"  ]
*complete2

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Where in the world can we save Devi-kun?[r]When he is NEO Devilun?[r]Or when we start over once more?[p]
[_tb_end_text]

[chara_mod  name="クピャドエル"  time="0"  cross="false"  storage="chara/14/2.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Honestly...[r]Devi-kun really is a troublesome child, isn't he?[p]
[_tb_end_text]

[return  ]
