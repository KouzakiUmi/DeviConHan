﻿[_tb_system_call storage=system/_omake_DRED.ks]

[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[tb_start_text mode=1 ]
#D Red
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="DR1.webp"  wait="false"  ]
[wait  time="2000"  ]
[playbgm  volume="50"  time="0"  loop="true"  storage="21_makai.ogg"  fadein="false"  ]
[flash_off  time="2000"  effect="fadeOut"  ]

[l  ]
[playse  volume="100"  time="0"  buf="3"  loop="false"  storage="makai1.ogg"  ]
[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#D Red
[font size=50]Hmm-hmm-hmm-hmm-hmm♪[resetfont][p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="DR2.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
[font size=50]I'm home![resetfont][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Demon King
You seem to be in a remarkably good mood, D Red.[p]
[_tb_end_text]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  loop="false"  storage="gauru1.ogg"  ]
[playse  volume="100"  time="0"  buf="4"  loop="false"  storage="aseru.ogg"  ]
[bg  time="300"  method="crossfade"  storage="DR3.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
Oh, you're awake, Dad! Did you see that little pup...[r]He's quite something, just as Beelzebub said.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Demon King
See it? I was woken up by the noise![r]Even if Bub says so, I can't believe an angel's[r]errand boy like that is any good.[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="DR4.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
I rather like him, myself.[r]He doesn't seem like a bad sort, either.[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="DR5.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Demon King
Don't tell me[delay speed=300]...[resetdelay]after all that military[r]buildup, you're going to let that little runt[r]sway you into calling off the invasion of Magirisia?[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="DR6.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
Guh[delay speed=100]...[resetdelay]Well, that's[delay speed=100]...[resetdelay]I mean[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Demon King
[font size=50]You big softie-[wait time=300]-[wait time=300]-[resetfont][wait time=300][er]

[_tb_end_text]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="4"  loop="false"  storage="aseru.ogg"  ]
[playse  volume="100"  time="0"  buf="1"  loop="false"  storage="gauru3.ogg"  ]
[bg  time="50"  method="crossfade"  storage="DR7.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
[font size=50]![delay speed=300]...[resetdelay]Mamon![r]Why, if it isn't Mamon![resetfont][p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="DR8.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
Mew, my lord... You're safe...[r]No, that's not the point! What happened?[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="DR9.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
Ma-Mamon, I, er... I may have been asking[r]too much of you... or something like that...[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="DR10.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
[delay speed=300]...[resetdelay]Ahem.[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="DR11.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
You have my thanks for all your hard work.[p]
[_tb_end_text]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="4"  loop="false"  storage="gimon.ogg"  ]
[bg  time="100"  method="crossfade"  storage="DR12.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
Mew! Why all of a sudden!?[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="DR13.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#D Red
A token of my appreciation.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
I-I know that![p]
[_tb_end_text]

[stopbgm  time="2000"  fadeout="true"  ]
[tb_start_text mode=1 ]
#Demon King
[delay speed=300]......[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[open_omake  category="gallery"  name="DR"  ]
[jump  storage="collection_omake.ks"  target="*resume_to_ng"  ]
