﻿[_tb_system_call storage=system/_omake_debi.ks]

[flash  time="0"  effect="fadeIn"  color="0xFFFFFF"  ]

[tb_start_text mode=1 ]
#Belphegor
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="B1.webp"  wait="false"  ]
[playbgm  volume="50"  time="0"  loop="true"  storage="5_theater.ogg"  fadein="false"  ]
[flash_off  time="2000"  effect="fadeOut"  ]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Belphegor
Bub! Long time no see-[r]gimme some mana![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
...Belphegor, you're big enough now.[r]Isn't it about time you gathered your own mana?[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="B2.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Belphegor
Aw, man.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
Siiigh[delay speed=100]...[resetdelay]I wish I could replenish my mana[r]just by eating, like you, Bub.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="B3.webp"  wait="false"  ]
[stopbgm  time="3000"  fadeout="true"  ]
[tb_start_text mode=1 ]
#Beelzebub
Oh, right. There's someone I'd like to introduce[r]you to, Belphegor.[wait time=400][p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="3"  loop="false"  storage="makai1.ogg"  ]
[bg  time="300"  method="crossfade"  storage="shiro.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Beelzebub
Come with me.[wait time=400][p]
[_tb_end_text]

[tb_hide_message_window  ]
[tb_start_text mode=1 ]
#Belphegor
[_tb_end_text]

[wait  time="2000"  ]
[playse  volume="100"  time="1000"  buf="5"  storage="mori.ogg"  loop="true"  fadein="true"  ]
[bg  time="3000"  method="crossfade"  storage="B4.webp"  wait="false"  ]
[l  ]
[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Belphegor
Whoa, what is this orchard!?[r]It's so bright--it's just like the Human Realm![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
Here in Fallen Paradise,[r]we grow all sorts of fruit in an environment[r]just like the Human Realm.[p]

[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="B5.webp"  wait="false"  ]
[playse  volume="100"  time="0"  buf="4"  loop="false"  storage="nisu.ogg"  ]
[tb_start_text mode=1 ]
#???
Lord Bub.[p]

[_tb_end_text]

[bg  time="1000"  method="crossfade"  storage="shiro.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Beelzebub
Oh, there you are.[wait time=400][p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="B6.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Beelzebub
Allow me to introduce him.[r]This is Nisrok, my personal[r]chef and the manager of Fallen Paradise.[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="B7.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Nisrok
Greetings, Lord Belphegor.[r]It's a pleasure to meet you.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nisrok
I serve as Lord Bub's retainer,[r]and I am Nisrok, the Demon Realm's head chef.[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="B8.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Beelzebub
Nisrok serves dishes made with the fruit grown here.[r]That way, even in the Demon Realm, we can enjoy[r]cuisine as fine as anything in the Human Realm.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
Huh--Bub has a fallen angel as his aide?[r]That's... kinda unexpected.[p]

[_tb_end_text]

[tb_hide_message_window  ]
[playse  volume="100"  time="0"  buf="4"  storage="NISU4.ogg"  ]
[bg  time="300"  method="crossfade"  storage="B9.webp"  wait="false"  ]
[wait  time="1000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Lesser Fallen Angel
Sorry to keep you waiting.[r]Here's Lord Nisrok's special lunch plate.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
Whoa! That looks delicious![p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="4"  storage="paku.ogg"  ]
[bg  time="100"  method="crossfade"  storage="B10.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Belphegor
Nom![p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="4"  storage="kawaii.ogg"  ]
[bg  time="300"  method="crossfade"  storage="B11.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Belphegor
Mmm, yummy! I can get this much[r]mana just by eating--this is amazing![p]
[_tb_end_text]

[stopse  time="1000"  buf="5"  fadeout="true"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="tukamu.ogg"  ]
[bg  time="300"  method="crossfade"  storage="B12.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Belphegor
...[wait time=100]...[wait time=100]...[wait time=100]?[p]
[_tb_end_text]

[tb_hide_message_window  ]
[flash  time="300"  effect="fadeIn"  color="0x000000"  ]

[tb_start_tyrano_code]
[position layer="message0" frame="Message3.png"  height="258"  ]
[_tb_end_tyrano_code]

[bg  time="0"  method="crossfade"  storage="B13.webp"  wait="false"  ]
[camera  time="10"  zoom="1.05"  wait="false"  ]
[wait  time="500"  ]
[playse  volume="100"  time="0"  buf="4"  storage="kowai.ogg"  ]
[flash_off  time="0"  effect="fadeOut"  ]

[reset_camera  time="2000"  wait="false"  ]
[wait  time="2000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Nisrok
[font size=50]How is it?[wait time=200][r]How do you like the kids' meal?[wait time=300][resetfont][p]
[_tb_end_text]

[playbgm  volume="50"  time="0"  loop="true"  storage="16_the_devil_s_power.ogg"  ]
[tb_start_text mode=1 ]
#Belphegor
(Wha-[wait time=100]-[wait time=100]-[wait time=100]what's with this guy!?[r]He suddenly started treating me like a kid!?)[p]
[_tb_end_text]

[reset_camera  time="1"  wait="false"  ]
[bg  time="100"  method="crossfade"  storage="B14.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Belphegor
(I can see[delay speed=100]...[resetdelay]what's in that dark[r]heart of yours[delay speed=100]...[resetdelay] Don't get any funny[r]ideas just because I don't have my Evil Eye!)[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
([delay speed=100]...[resetdelay]!? Are you badmouthing Bub in your head, too?)[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
(How can someone like this be Bub's aide?![r]Unforgivable[delay speed=100]...[resetdelay])[p]
[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="500"  wait="false"  ]

[tb_start_text mode=1 ]
#Belphegor
Y-you[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="B15.webp"  wait="false"  ]
[tb_hide_message_window  ]
[tb_start_tyrano_code]
[position layer="message0" frame="Message.png"  height="258"  ]
[_tb_end_tyrano_code]

[stopbgm  time="0"  ]
[playse  volume="100"  time="0"  buf="5"  storage="mori.ogg"  loop="true"  fadein="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="hirameki.ogg"  ]
[free layer=4 name="kuro" time="0"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[wait  time="1000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Nisrok
This is for you, Lord Bub.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Beelzebub
Mmm[delay speed=100]...[resetdelay]your cooking is delicious, as always.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
[delay speed=100]...[resetdelay]![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
(So this is the face Bub makes around him.)[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
(If I put a damper on things now,[r]it'd only make Bub sad.)[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Belphegor
[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="kuro.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Belphegor
([delay speed=100]...[resetdelay]Maybe I'm just dragging down Bub's reputation[r]by being such a hopeless mess.)[p]
[_tb_end_text]

[tb_hide_message_window  ]
[stopbgm  time="1000"  fadeout="true"  ]
[stopse  time="1000"  buf="5"  fadeout="true"  ]
[open_omake  category="gallery"  name="BBB"  ]
[jump  storage="collection_omake.ks"  target="*resume_to_ng"  ]
