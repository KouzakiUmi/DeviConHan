﻿[_tb_system_call storage=system/_gekizyou_END32.ks]

[cm  ]
[bg_loop name="gekizyo2"]

[chara_show  name="劇場でび"  time="0"  wait="false"  storage="chara/15/dagya20.png"  width="564"  height="595"  left="355"  top="143"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[stopse  time="300"  buf="1"  fadeout="true"  ]
[call  storage="maku.ks"  target="*open_gekizyou"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="5_theater.ogg"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Devilun
What was that "twang" sound effect...A stringed instrument?[p]

[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya28.png"  ]
[tb_start_text mode=1 ]
#Devilun
Still, that womanizing white cat...[r]Even after I went out of my way to stop him,[r]he went and got [font face="KaiseiDecol-Bold"]played[resetfont] like a sucker...[p]

[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya9.png"  ]
[tb_start_text mode=1 ]
#Devilun
Well, thinking someone's a woman and finding out[r]they're a man... or that their gender's unknown...[r]in this world, that's just an everyday thing, huh...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Still, threatening someone with crunchy kelp...[r][font face="KaiseiDecol-Bold"]Sure[resetfont], it [font face="KaiseiDecol-Bold"]reeks[resetfont] up close...[p]
[_tb_end_text]

[jump  storage="gekizyou_END_menu.ks"  target=""  ]
