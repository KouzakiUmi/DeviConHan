﻿[clearfix]
[tb_show_message_window]
[tb_start_text mode=1 ]
#
This path is blocked.[wait time=60000]
[_tb_end_text]
[s]
