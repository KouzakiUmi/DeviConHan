﻿[_tb_system_call storage=system/_loop_Chapter3.ks]

*loop1

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/3.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]Tsk[r]You've been darting around with such underhanded tricks...[p]
[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[playse  volume="100"  time="1000"  buf="4"  storage="wind.ogg"  ]
[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/4.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_filter_blur  layer="all"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
#Devilun I'm talking about you Kupyadel[p]
You've been clinging to me and needling me[r]What exactly are you after? [wait time=300]What can you do?[p]




[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
N-[wait time=300]No, eek![wait time=300]I'm against violence![p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
It's obvious you've been found out, so quit[r]pretending to be that tiny little thing already.[p]

[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/5.png"  ]
[playse  volume="100"  time="0"  buf="2"  storage="marusu.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
Or maybe you want me to do that again.[wait time=300][r]Do you want it?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Ngh![wait time=300][r]Anything but that, please![p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="kupya_modoru.ogg"  ]
[tb_hide_message_window  ]
[flash  time="800"  effect="fadeIn"  color="0xFFFFFF"  ]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/7.png"  ]
[wait  time="600"  ]
[flash_off  time="1500"  effect="fadeOut"  ]

[wait  time="1000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
That's it, that face.[wait time=300]Much better.[r][wait time=300]Just my type.[p]

[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
As I thought, this form fits me like a glove...![wait time=300][r]But I'm almost there at last...[wait time=300]Heh heh heh.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
We're just one step from the finish line![wait time=300][r]I'm counting on you, [emb exp="f.name"].[p]



[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/7.png"  ]
[tb_start_text mode=1 ]
#Devilun
What?[wait time=300]You think this isn't my true form?[r]Heh.[wait time=300]That's what I thought at first...[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
But thanks to you, I've realized[r]there's another possibility, [emb exp="f.name"].[p]

[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="500"  wait="false"  ]

[tb_start_text mode=4 ]
#Devilun
I'm heading to the bedroom first.





[_tb_end_text]

[wait  time="200"  ]
[playse  volume="100"  time="1000"  buf="2"  storage="doa4.ogg"  ]
[tb_start_text mode=4 ]
[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
[_tb_end_text]

[chara_hide  name="成体でびるん"  time="0"  wait="false"  pos_mode="false"  ]
[tb_hide_message_window  ]
[stopse  time="0"  buf="5"  ]
[playse  volume="100"  time="1000"  buf="2"  storage="doa3.ogg"  ]
[chara_show  name="成体クピャドエル"  time="0"  wait="false"  storage="chara/36/1.png"  width="1239"  height="929"  left="19"  top="19"  reflect="false"  ]
[bg  time="0"  method="crossfade"  storage="haikei_Small.webp"  ]
[wait  time="3000"  ]
[free layer=4 name="kuro" time="1000"]

[wait  time="1000"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Kupyadel
......[p]

[_tb_end_text]

[tb_hide_message_window  ]
[choice2 text1="Lend&nbsp;a&nbsp;hand" target1="*oko" text2="Wake&nbsp;them&nbsp;up" target2="*oko" ]

[s  ]
*oko

[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/wedding.png"  ]
[playse  volume="100"  time="0"  buf="2"  storage="ashi.ogg"  ]
[camera  time="2000"  zoom="1.699"  wait="false"  layer="base"  ease_type="ease"  y="155"  ]
[camera  time="2000"  zoom="1.7"  wait="false"  layer="0"  ease_type="ease"  y="200"  ]
[camera  time="2000"  zoom="1.7"  wait="true"  layer="1"  ease_type="ease"  y="200"  ]
[wait  time="1000"  ]
[playse  volume="100"  time="0"  buf="1"  storage="gimon.ogg"  ]
[flash  time="20"  effect="fadeIn"  color="0xFFFFFF"  ]

[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/0.png"  ]
[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/2.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
...![p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="80"  cross="false"  storage="chara/36/3.png"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/te.png"  ]
[tb_hide_message_window  ]
[reset_camera  time="5000"  wait="false"  layer="base"  ease_type="ease"  ]
[reset_camera  time="5000"  wait="false"  layer="0"  ease_type="ease"  ]
[reset_camera  time="5000"  wait="false"  layer="1"  ease_type="ease"  ]
[wait  time="3000"  ]
[fadein_window  time="1000"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="9_cupyadoel_ai.ogg"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah...[wait time=300]Thank you very much.[wait time=300][r]You're so kind, [emb exp="f.name"].[p]


[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/4.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'm sorry you had to see me in such an unsightly state...[p]

[_tb_end_text]

[tb_start_text mode=1 ]
Just like him, [wait time=300]as long as I have mana,[r]this is what I really look like too.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
That must have... startled you.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Devilun had only been in that small body because[r]he was short on mana, so he could just barely manage...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
As a mere mid-ranking angel, [wait time=300][r]I can't stop Devilun as he is now.[p]


[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/5.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
But I...[wait time=300]I'm not chasing Devilun[r]without a plan, you know.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Devilun has a gentle side, even among the great demons.[wait time=300][r]He also has the potential to save others...[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Even just now, [wait time=300]though [c]killing[_c] me would have been easy...[wait time=300][r]unlike other demons, he chose not to.[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/4.png"  ]
[reset_camera  time="0"  wait="false"  layer="layer_camera"  ease_type="ease"  ]
[tb_start_text mode=1 ]
#Kupyadel
...I first met Devilun[r]when I was still a fledgling angel.[p]

[_tb_end_text]

[tb_hide_message_window  ]
[hide_photo_button]

[call  storage="me.ks"  target="*meclose_kioku"  ]
[tb_start_text mode=1 ]
#②
[_tb_end_text]

[chara_hide  name="成体クピャドエル"  time="0"  wait="false"  pos_mode="false"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/0.png"  ]
[tb_start_tyrano_code]
[position layer="message0" frame="Message2_.png" height="265"]
[_tb_end_tyrano_code]

[bg  time="0"  method="crossfade"  storage="kupya_kaisou1.webp"  ]
[call  storage="phase.ks"  target="*hide"  ]
[call  storage="me.ks"  target="*meopen_kioku"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#②
As an angel, [wait time=300]I must see the mission[r]I've been given through.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#②
To help this world move even a little toward a better[r]future, and help everyone find happiness.[wait time=300]That is my role...[p]

[_tb_end_text]

[bg  time="200"  method="crossfade"  storage="kupya_kaisou2.webp"  ]
[tb_start_text mode=1 ]
#②
But crushed beneath the weight of[r]that sense of duty, I pushed myself too[r]far.[wait time=300] I ended up in danger and collapsed.[p]

[_tb_end_text]

[bg  time="200"  method="crossfade"  storage="kupya_kaisou3.webp"  ]
[tb_start_text mode=1 ]
#②
And then, [wait time=300]Devilun suddenly appeared before me.[p]
[_tb_end_text]

[bg  time="200"  method="crossfade"  storage="shiro.webp"  ]
[tb_start_text mode=1 ]
#②
Well[delay speed=100]...[resetdelay]this is embarrassing to admit[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[bg  time="200"  method="crossfade"  storage="kupya_kaisou4.webp"  ]
[tb_start_text mode=1 ]
#②
He shared some of his mana with me.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#②
N-[wait time=100]Not his mouth![wait time=300][r]It was around the neck...[wait time=300]just a little.[p]


[_tb_end_text]

[bg  time="200"  method="crossfade"  storage="kupya_kaisou5.webp"  ]
[tb_start_text mode=1 ]
#②
After that, [wait time=300]he gave me a sweet-and-tart[r]raspberry pie to eat, you see.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#②
I never knew something could be this delicious,[r][wait time=300]or that happiness could feel like this...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#②
For an angel like me, who had never even had the[r]chance to taste food, [wait time=300]this pleasure was a revelation![p]
[_tb_end_text]

[tb_hide_message_window  ]
[call  storage="me.ks"  target="*meclose_kioku2"  ]
[bg  time="0"  method="crossfade"  storage="haikei_Small.webp"  ]
[chara_show  name="成体クピャドエル"  time="0"  wait="false"  storage="chara/36/6.png"  width="1280"  height="960"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/te.png"  ]
[call  storage="phase.ks"  target="*show_top"  ]
[call  storage="me.ks"  target="*meopen_kioku2"  ]
[show_photo_button]

[tb_start_text mode=1 ]
#Kupyadel
[_tb_end_text]

[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Kupyadel
That was what made me realize[wait time=300]I didn't have to lie[r]to my own feelings.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
So, if I'm being honest, raspberry flavor is[r]a little too tart for me. I'll have custard, please.[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/3.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Huh?[wait time=300]Then why do I tie Devilun up[r]and torment him, you ask...?[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/7.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Oh my, how rude of you[r]It's all part of the game, you know.[p]

[_tb_end_text]

[reset_camera  time="0"  wait="false"  layer="layer_camera"  ease_type="ease"  ]
[tb_start_text mode=1 ]
#Kupyadel
That too is the result of refusing to lie to my[r]feelings, you see. ❤ [wait time=300]Love takes many forms in this world.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
My love means[r][wait time=300]tormenting Devilun![p]


[_tb_end_text]

[tb_hide_message_window  ]
[call  storage="me.ks"  target="*me_close_player"  ]
[tb_start_text mode=1 ]
#Kupyadel
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/8.png"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/te_zyagan.png"  ]
[bg  time="0"  method="crossfade"  storage="player_zyagan_Small.webp"  ]
[call  storage="me.ks"  target="*meopen_player"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Kupyadel
That may be what I said, but[wait time=300]it isn't what I truly feel.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Perhaps what I really want is a love with Devilun[r]as sweet--no, sweeter than custard pie.[p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But he is a demon.[wait time=300]If I gave in to that,[r]this angel would truly break this time.[p]
...just like that person long ago,[r]I would fall from grace.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
It's a defense mechanism: I pour this[r]twisted affection onto Devilun.[wait time=300] ...I know. I know.[p]
This is the only way I can express[r]my love for the demon Devilun.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But if these feelings of mine[r]were caused by Devilun's kiss...[p]
Then, at the very least, he ought to[r]take responsibility for them. Honestly.[p]


[_tb_end_text]

[call  storage="me.ks"  target="*me_ENDtozi_player"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/te.png"  ]
[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/6.png"  ]
[bg  time="0"  method="crossfade"  storage="haikei_Small.webp"  ]
[call  storage="me.ks"  target="*me_ENDake_nobgm"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Hehe.[wait time=300]I might be on the verge[r]of falling from grace too, you know.[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/9.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...But I'm sure [emb exp="f.name"] has also been saved in some way[r]by a free-spirited Devilun.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
That's why I don't try to stop him.[wait time=300][r]No matter what path Devilun chooses,[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[emb exp="f.name"] is here[r]I have a feeling everything will be all right...[p]

[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0xFFFFFF"  ]

[playse  volume="100"  time="0"  buf="1"  storage="gimon.ogg"  ]
[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/3.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=1 ]
#Kupyadel
Wait,[wait time=300]did you just read my thoughts?[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/10.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
...The power of the Evil Eye is beginning to consume you.[wait time=300][r]It's only a matter of time before it takes your soul.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Please uncover his name and stop him![wait time=300][r]It's the only way left![p]


[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/6.png"  ]
[reset_camera  time="0"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
If you ever need anything, call for[r]Kupyadel, angel of love.[p]

[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/11.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupyah~[delay speed=100]...[resetdelay][r]May eternal happiness be yours[delay speed=100]...[resetdelay][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]......[resetdelay][p]
[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="0"  wait="false"  ]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...Nothing at all.[resetdelay][p]
[_tb_end_text]

[open_omake  category="gallery"  name="kupya_kaisou"  ]
[memory name="kupya_inori" val="1"]

[collect_character name="でかクピャ"]

[jump  storage="Chapter3.ks"  target="*loop_back"  ]
*loop2

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/3.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]Tsk[r]You've been darting around with such underhanded tricks...[p]
[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[playse  volume="100"  time="1000"  buf="4"  storage="wind.ogg"  ]
[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/4.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_filter_blur  layer="all"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=50]What's with you since last night? Kupyadel[resetfont][wait time=300][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
You've been clinging to me and needling me[r]Trying to stop me is pointless.[p]




[_tb_end_text]

[memory name="ne" val="0"]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Oh my![wait time=300]I'm against violence![p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
It's obvious you've been found out, so quit[r]pretending to be that tiny little thing already.[p]

[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/5.png"  ]
[playse  volume="100"  time="0"  buf="2"  storage="marusu.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
Or maybe you want me to do that again.[wait time=300][r]Do you want it?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
...[p]
[_tb_end_text]

[playse  volume="100"  time="1000"  buf="0"  storage="kupya_modoru.ogg"  ]
[tb_hide_message_window  ]
[flash  time="800"  effect="fadeIn"  color="0xFFFFFF"  ]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/7.png"  ]
[wait  time="600"  ]
[flash_off  time="1500"  effect="fadeOut"  ]

[wait  time="1000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
That's it, that face.[wait time=300]Much better.[r][wait time=300]Just my type.[p]

[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
As I thought, this form fits me like a glove...![wait time=300][r]But I'm almost there at last...[wait time=300]Heh heh heh.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
We're just one step from the finish line![wait time=300][r]I'm counting on you, [emb exp="f.name"].[p]



[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/14.png"  ]
[tb_start_text mode=1 ]
#Devilun
...Still, now that the great me is right in front of you,[r]your reaction is awfully muted. Oh well.[p]
[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
It's thanks to you that I realized[r]there was another possibility.[p]

[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="500"  wait="false"  ]

[tb_start_text mode=4 ]
#Devilun
I'm heading to the bedroom first.





[_tb_end_text]

[wait  time="200"  ]
[playse  volume="100"  time="1000"  buf="2"  storage="doa4.ogg"  ]
[tb_start_text mode=4 ]
[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
[_tb_end_text]

[chara_hide  name="成体でびるん"  time="0"  wait="false"  pos_mode="false"  ]
[tb_hide_message_window  ]
[stopse  time="0"  buf="5"  ]
[playse  volume="100"  time="1000"  buf="2"  storage="doa3.ogg"  ]
[chara_show  name="成体クピャドエル"  time="0"  wait="false"  storage="chara/36/1.png"  width="1280"  height="960"  ]
[bg  time="0"  method="crossfade"  storage="haikei_Small.webp"  ]
[wait  time="3000"  ]
[free layer=4 name="kuro" time="1000"]

[wait  time="1000"  ]
[fadein_window  time="1000"  ]
[jump  storage="loop_Chapter3.ks"  target="*loop3"  cond="f.currentLoop>2"  ]
[tb_start_text mode=1 ]
#Kupyadel
......[p]

[_tb_end_text]

[tb_hide_message_window  ]
[choice2 text1="Lend&nbsp;a&nbsp;hand" target1="*oko2" text2="Wake&nbsp;them&nbsp;up" target2="*oko2" ]

[s  ]
*oko2

[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/wedding.png"  ]
[playse  volume="100"  time="0"  buf="2"  storage="ashi.ogg"  ]
[camera  time="2000"  zoom="1.69"  wait="false"  layer="base"  ease_type="ease"  y="150"  ]
[camera  time="2000"  zoom="1.7"  wait="false"  layer="0"  ease_type="ease"  y="200"  ]
[camera  time="2000"  zoom="1.7"  wait="true"  layer="1"  ease_type="ease"  y="200"  ]
[wait  time="1000"  ]
[playse  volume="100"  time="0"  buf="1"  storage="gimon.ogg"  ]
[flash  time="20"  effect="fadeIn"  color="0xFFFFFF"  ]

[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/0.png"  ]
[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/13.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
...[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="80"  cross="false"  storage="chara/36/4.png"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/te.png"  ]
[chara_mod  name="プレイヤー"  time="0"  cross="false"  storage="chara/2/0.png"  ]
[tb_hide_message_window  ]
[reset_camera  time="5000"  wait="false"  layer="base"  ease_type="ease"  ]
[reset_camera  time="5000"  wait="false"  layer="0"  ease_type="ease"  ]
[reset_camera  time="5000"  wait="false"  layer="1"  ease_type="ease"  ]
[wait  time="3000"  ]
[fadein_window  time="1000"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="9_cupyadoel_ai.ogg"  ]
[tb_start_text mode=1 ]
#Kupyadel
I'm sorry to have worried you.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=300]...[resetdelay]I did it on purpose.[p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I wanted to check properly from up close.[r]Devilun's heartbeat, his warmth[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/12.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
It was really Devilun.[r]I was so, so happy just to know that[delay speed=100]...[resetdelay][p]



[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Good. As I thought, [emb exp="f.name"]'s[r]ability to start over is the real thing.[p]



[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I resent that this is the only way I can feel[r]Devilun's body heat, but[p]



[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/9.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I[delay speed=100]...[resetdelay]No, I am satisfied.[p]


[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0xFFFFFF"  ]

[playse  volume="100"  time="0"  buf="1"  storage="gimon.ogg"  ]
[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/3.png"  ]
[memory name="MAGAN" val="1"]

[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=1 ]
#Kupyadel
![delay speed=100]...[resetdelay]Is it about time for [emb exp="f.name"]'s[r]Magic Eye to awaken?[p]

[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/5.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
You once read my mind without warning with the[r]Magic Eye on your forehead, and it gave me quite a shock.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.bel_name_first == 1"]It must hurt terribly while it awakens[r][delay speed=100]...[resetdelay]but[else]But when you became NEO Devilun[r]you handled the Magic Eye so skillfully[endif][p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/6.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
If you put that power Devilun gave you to good use,[r]we may be able to find a new ending[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/9.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
Let's work together to find the best solution[r]--one that will make Devilun[delay speed=100]...[resetdelay] and everyone happy.[p]


[_tb_end_text]

[stopbgm  time="2000"  fadeout="true"  ]
[jump  storage="Chapter3.ks"  target="*loop_back"  ]
*loop3

[tb_start_tyrano_code]
[delay speed=100]......[resetdelay]
[if exp="f.currentLoop == 3"]
#Kupyadel
Devilun... you were warm.
[elsif exp="f.currentLoop == 4"]
#Kupyadel
This is the only way I can feel[r]Devilun.
[elsif exp="f.currentLoop == 5"]
#Kupyadel
Forgive me this folly.
[elsif exp="f.currentLoop == 6"]
#Kupyadel
I wish I could hold you.
[elsif exp="f.currentLoop == 7"]
#Kupyadel
Devilun... ahh.
[elsif exp="f.currentLoop == 8"]
#Kupyadel
This is so unbecoming, isn't it?
[else]
Forgive me this folly.
[endif]
[p]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=200]......[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Don't worry about me. Go to Devilun, who[r]is going to have a hard time, and be there for him.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
He[wait time=100]needs love.[p]
[_tb_end_text]

[jump  storage="Chapter3.ks"  target="*loop_back"  ]
*end_complete

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/3.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]Tsk[r]You've been darting around[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[chara_show  name="成体クピャドエル"  time="0"  wait="false"  storage="chara/36/deka1.png"  width="1280"  height="960"  ]
[playse  volume="100"  time="1000"  buf="4"  storage="idou.ogg"  ]
[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/9.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
Doel,[wait time=100]you[delay speed=100]...[resetdelay]that form[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[flash  time="80"  effect="fadeIn"  color="0xFFFFFF"  ]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/deka2.png"  ]
[stopse  time="0"  buf="5"  ]
[playse  volume="100"  time="1000"  buf="4"  storage="gimon.ogg"  ]
[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/10.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[l  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]W-what[wait time=100]happened to you?[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="1"  storage="sasu2.ogg"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/11.png"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=50]Get away from me![resetfont][r]You're not the you I know.[p]
[_tb_end_text]

[playbgm  volume="50"  time="1000"  loop="true"  storage="9_cupyadoel_ai.ogg"  ]
[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/12.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]What would you do if I said this was the real me?[p]
[_tb_end_text]

[chara_mod  name="成体でびるん"  time="0"  cross="false"  storage="chara/35/13.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]No.[r]You're not like that.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
If you're trying to stop me[r]by taking this form, too bad for you.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
I've finally seized this chance[delay speed=100]...[resetdelay][r]I'm not going to let it end here.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="500"  wait="false"  ]

[tb_start_text mode=4 ]
#Devilun
I'm going to the bedroom first.




[_tb_end_text]

[wait  time="200"  ]
[playse  volume="100"  time="1000"  buf="2"  storage="doa4.ogg"  ]
[tb_start_text mode=4 ]
[p]
[_tb_end_text]

[tb_start_text mode=4 ]
#Kupyadel
[_tb_end_text]

[chara_hide  name="成体でびるん"  time="0"  wait="false"  pos_mode="false"  ]
[chara_hide  name="成体クピャドエル"  time="0"  wait="false"  pos_mode="false"  ]
[tb_hide_message_window  ]
[stopse  time="0"  buf="5"  ]
[playse  volume="100"  time="1000"  buf="2"  storage="doa3.ogg"  ]
[chara_show  name="成体クピャドエル"  time="0"  wait="false"  storage="chara/36/1.png"  width="1098"  height="823"  left="73"  top="82"  reflect="false"  ]
[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[bg  time="0"  method="crossfade"  storage="haikei_Small.webp"  ]
[wait  time="800"  ]
[free layer=4 name="kuro"]

[flash_off  time="1000"  effect="fadeOut"  ]

[wait  time="800"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Kupyadel
Devilun, you always...[wait time=100][r]it's not fair how you get to stay in the dark.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
An angel who falls in love[r]with a demon will fall from grace.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
That's why I've always tried[wait time=100][r]to keep a reasonable distance from Devilun.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I've spent all this time feeling only the faint[r]warmth of Devilun's hand on my collar, [wait time=100]over and over.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I've kept crushing down the urge [wait time=100]to hold[r]that love-starved man tight in my arms,[wait time=100]over and over[delay speed=100]...[resetdelay][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
But[wait time=300]it doesn't matter anymore.[p]

[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/1__.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
I[delay speed=100]...[resetdelay]I don't mind falling from grace anymore.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Because no matter how many times[r]I start over, I could never find an ending[r]where Devilun and everyone could be happy.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
So[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Once I have fallen[delay speed=100]...[resetdelay]no matter what it takes,[r]I will make everyone happy.[p]
[_tb_end_text]

[jump  storage="loop_Chapter3.ks"  target="*100_mp"  cond="f.mp_100==0"  ]
[tb_start_text mode=1 ]
#Kupyadel
Even you, [emb exp="f.name"], made it this far by pretending[r]to gather MP and bluffing your way through...[delay speed=100]...[resetdelay]I know.[p]
[_tb_end_text]

*100_mp

[tb_start_text mode=1 ]
#Kupyadel
[if exp="f.mp_100== 0"]Maybe that choice earns a passing mark[else]Maybe a choice like that earns a passing mark[endif][p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/1.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=300]...[resetdelay]Oh, right... when you become a fallen[r]angel, your darker personality takes over and you[r]lose your memories of the happy times, don't you?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I wish I could have remembered [emb exp="f.name"],[wait time=100]and Devilun...[r]I really wanted to remember it all.[p]
[_tb_end_text]

[chara_mod  name="成体クピャドエル"  time="0"  cross="false"  storage="chara/36/1__.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
No...[wait time=100]it would probably be easier[r]if I forgot memories like these now.[p]
[_tb_end_text]

[stopbgm  time="4000"  fadeout="true"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Even though I was an angel, [wait time=100]I[r]ended up being no help at all [delay speed=100]...[resetdelay]I'm sorry.[p]
[_tb_end_text]

[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="0"  wait="false"  ]

[tb_start_text mode=1 ]
#Kupyadel
Well then.[p]
[_tb_end_text]

[tb_hide_message_window  ]
[tb_filter_blur  layer="all"  ]
[flash  time="1000"  effect="fadeIn"  color="0x000000"  ]

[tb_start_text mode=1 ]
#Devilun
[_tb_end_text]

[wait  time="2000"  ]
[tb_eval  exp="f.photoNonFixedPose=0"  name="photoNonFixedPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[bg  time="0"  method="crossfade"  storage="haikei_bed2.webp"  ]
[playbgm  volume="50"  time="0"  loop="true"  storage="7_before_sleep.ogg"  ]
[free layer=4 name="kuro" time="0"  ]

[chara_hide_all  time="0"  wait="false"  ]
[chara_show  name="ベッド"  time="0"  wait="false"  storage="chara/19/6.png"  width="1140"  height="855"  left="62"  top="58"  reflect="false"  ]
[chara_show  name="プレイヤー"  zindex="2"  layer="1"  time="0"  wait="false"  storage="chara/2/0.png"  width="1280"  height="960"  ]
[flash_off  time="1000"  effect="fadeOut"  ]

[wait  time="1500"  ]
[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Devilun
So you finally dragged yourself back.[wait time=300] You're late.[p]

[_tb_end_text]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/51.png"  ]
[tb_start_text mode=1 ]
#Devilun
D[delay speed=300]...[resetdelay]-Doel... where are they?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
B-[wait time=100]but I'm not worried or anything.[wait time=100][r]I just thought it was the first time[r]I'd ever seen them look like that[wait time=100]...[delay speed=300][resetdelay][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/52.png"  ]
[playse  volume="100"  time="0"  buf="1"  storage="hazikeru.ogg"  ]
[tb_start_tyrano_code]
[play_apng name="kemuri" layer="1" x="-420" y="190" width="1280" height="960" mode="screen" free="true"]
[_tb_end_tyrano_code]

[wait  time="200"  ]
[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/pie.png"  ]
[wait  time="1000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
Here you go.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
They probably like this[r]sort of sugary-sweet thing right?[p]
[_tb_end_text]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/51.png"  ]
[tb_start_text mode=1 ]
#Devilun
When I fed Doel raspberry pie before,[r]they thought it was sour... I just remembered.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
They'll probably like that cream pie.[r]Next time you see them, give it to them to try.[p]

[_tb_end_text]

[playse  volume="100"  time="0"  buf="1"  storage="aseru.ogg"  ]
[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/4.png"  ]
[tb_start_text mode=1 ]
#Devilun
S-stole it-keep that between us, okay?[r]And you don't have to tell them it was from me, either.[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
If they get upset and do something weird to me,[r]it'll be a real pain![p]

[_tb_end_text]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/10.png"  ]
[image name="ゴール" layer=0  time="500"  wait="false"  folder="image"  storage="goal/fuki.png"  width="294"  height="258"  left="132"  top="194"  reflect="false"  ]

[chara_mod  name="プレイヤー"  time="80"  cross="false"  storage="chara/2/te.png"  ]
[tb_start_text mode=1 ]
#Devilun
I'll give you that [font color=0xEC6FC5 bold=true]GOAL[resetfont] flag.[wait time=300] Like the[r]Magic Flute, I just found it lying around somewhere.[p]
[_tb_end_text]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/53.png"  ]
[camera  time="8000"  zoom="1.15"  wait="false"  layer="base"  y="50"  ]
[camera  time="8000"  zoom="1.3"  wait="false"  layer="0"  y="50"  ]
[camera  time="8000"  zoom="1.3"  wait="false"  layer="1"  y="50"  ]
[stopbgm  time="2000"  fadeout="true"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=100]...[resetdelay]Still, you...[p]
[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[stopbgm  time="0"  fadeout="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="gimon.ogg"  ]
[reset_camera  time="0"  wait="false"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_start_text mode=1 ]
#Devilun
How do you know what the Goal charm does?[r]I want to know.[p]
[_tb_end_text]

[free name="ゴール" layer=0  time="500"  wait="false"]

[tb_start_text mode=1 ]
#Devilun
You can see right through me.[r]You even know the story I was about to tell you[r]--how I was cast out of the Demon Realm.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
I've felt something was off ever since I was[r]summoned. I can feel a powerful Connection directed at me.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
And it's one-sided--from you,[r]someone I've never even met.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]I don't know what you're hiding, but[r]there is no lie in this bond between our minds.[p]
[_tb_end_text]

[playbgm  volume="50"  time=""  loop="true"  storage="7_before_sleep.ogg"  fadein="false"  ]
[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/6.png"  ]
[tb_start_text mode=4 ]
#Devilun
I'll ask you straight:[r]what are you planning to do with me?[wait time=500]


[_tb_end_text]

[choice2 text1="Make&nbsp;him&nbsp;my&nbsp;partner" target1="*to" text2="Make&nbsp;him&nbsp;my&nbsp;friend" target2="*to" y="500"]

[s  ]
*to

[flash  time="80"  effect="fadeIn"  color="0xFFFFFF"  ]

[tb_hide_message_window  ]
[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/12.png"  ]
[playse  volume="100"  time="0"  buf="1"  storage="hirameki.ogg"  ]
[wait  time="100"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[wait  time="500"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
S-so[wait time=300]that's it?[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="ベッド"  time="80"  cross="false"  storage="chara/19/2.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]Well,[wait time=300]if you think you can, give it a try.[p]
[_tb_end_text]

[chara_mod  name="ベッド"  time="300"  cross="false"  storage="chara/19/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=100]...[resetdelay]Zzz...[p]

[_tb_end_text]

[tb_hide_message_window  ]
[chara_show  name="TAP"  time="500"  wait="false"  storage="chara/18/TAP.png"  width="400"  height="200"  left="445"  top="9"  reflect="false"  ]
[clickable  storage="loop_Chapter3.ks"  x="469"  y="148"  width="339"  height="566"  target="*tap1"  _clickable_img=""  ]
[s  ]
*tap1

[flash  time="50"  effect="fadeIn"  color="0x000000"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="mp.ogg"  ]
[tb_start_tyrano_code]
[keyframe name="kupya"]
[frame p="0%" y="0"]
[frame p="50%" y="-30"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="クピャドエル" keyframe="kupya" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/5.png"  ]
[chara_hide  name="TAP"  time="500"  wait="false"  pos_mode="false"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
Good grief, every single night you never let up.[r]Do you really want to sleep together that badly?[p]

[_tb_end_text]

[tb_hide_message_window  ]
[chara_mod  name="ベッド"  time="300"  cross="false"  storage="chara/19/8.png"  ]
[chara_show  name="TAP"  time="500"  wait="false"  storage="chara/18/TAP.png"  width="400"  height="200"  left="445"  top="9"  reflect="false"  ]
[clickable  storage="loop_Chapter3.ks"  x="469"  y="148"  width="339"  height="566"  target="*tap2"  _clickable_img=""  ]
[s  ]
*tap2

[flash  time="50"  effect="fadeIn"  color="0x000000"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="mp.ogg"  ]
[tb_start_tyrano_code]
[keyframe name="kupya"]
[frame p="0%" y="0"]
[frame p="50%" y="-30"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="クピャドエル" keyframe="kupya" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/29.png"  ]
[chara_hide  name="TAP"  time="500"  wait="false"  pos_mode="false"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=100]...[resetdelay][p]


[_tb_end_text]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/33.png"  ]
[tb_start_text mode=1 ]
#Devilun
Can't be helped[delay speed=100]...[resetdelay][r]Just for tonight.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Doel, for one--why do you all[r]have such enormous feelings for me?[r]I can't for the life of me figure out why.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
You're a really strange one.[font size=25][r]You weren't even surprised by my true form...[resetfont][p]

[_tb_end_text]

[chara_mod  name="ベッド"  time="0"  cross="false"  storage="chara/19/34.png"  ]
[tb_start_text mode=1 ]
#Devilun
Ugh, if you're going to sleep,[r]hurry up and turn off the light.[p]


[_tb_end_text]

[tb_hide_message_window  ]
[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="20"  wait="false"  ]

[playse  volume="100"  time="0"  buf="1"  storage="off.ogg"  ]
[wait  time="3000"  ]
[tb_show_message_window  ]
[playse  volume="60"  time="0"  buf="1"  storage="fuku2.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
Ngh[delay speed=100]...[resetdelay][r]You sure are clinging to me.[p]
[_tb_end_text]

[playse  volume="60"  time="0"  buf="1"  storage="fuku2.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
W-where are you touching me?![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...![resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[delay speed=300]......[resetdelay]hey.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Does your forehead hurt?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
The Magic Eye! I mean, your Ma-gic Eye! It hurts[r]so badly when it awakens that I writhe around in agony.[p]
[_tb_end_text]

[playse  volume="60"  time="0"  buf="1"  storage="fuku2.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=100]...[resetdelay]Like this?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Being petted by you[delay speed=100]...[resetdelay][r]isn't half bad, so I'll return the favor.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Heh heh[delay speed=300]...[resetdelay]that's a nice face[delay speed=300]...[resetdelay][r]Knew you had it in you[delay speed=300]...[resetdelay][p]

[_tb_end_text]

[tb_hide_message_window  ]
[stopbgm  time="3000"  fadeout="true"  ]
[wait  time="3000"  ]
[flash  time="1000"  effect="fadeIn"  color="0x000000"  ]

[eval exp="f.day=3"]

[call  storage="phase.ks"  target="*hide"  ]
[free layer=4 name="kuro"]

[tb_eval  exp="f.photoNonFixedPose=1"  name="photoNonFixedPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[chara_hide  name="ベッド"  time="0"  wait="false"  pos_mode="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[bg  time="0"  method="crossfade"  storage="haikei2.webp"  ]
[free_layermode  time="0"  wait="false"  ]
[wait  time="800"  ]
[playbgm  volume="50"  time="0"  loop="true"  storage="1_debirun_no_theme.ogg"  ]
[chara_show  name="でびるん"  time="0"  wait="false"  storage="chara/1/15.png"  width="1280"  height="960"  ]
[chara_show  name="プレイヤー"  zindex="2"  layer="1"  time="0"  wait="false"  storage="chara/2/te.png"  width="1280"  height="960"  ]
[reset_camera  time="0"  wait="false"  ]
[tb_start_tyrano_code]
[keyframe name="fuwa"]
[frame p="0%" y="0"]
[frame p="50%" y="-50"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="でびるん" keyframe="fuwa" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[call  storage="phase.ks"  target="*show_top"  ]
[flash_off  time="1000"  effect="fadeOut"  ]

[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Devilun
Yaaawn[delay speed=300]...[resetdelay][r]I slept well.[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/54.png"  ]
[tb_start_text mode=1 ]
#Devilun
[delay speed=300]...[resetdelay]That thing from yesterday.[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/53.png"  ]
[tb_start_text mode=1 ]
#Devilun
You know, the head-patting[delay speed=300]...[resetdelay][p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/54.png"  ]
[tb_start_text mode=4 ]
#Devilun
You can do it again before bed[delay speed=300]...[resetdelay][wait time=800][er]
[_tb_end_text]

[flash  time="80"  effect="fadeIn"  color="0x000000"  ]

[stopbgm  time="0"  ]
[camera  time="0"  zoom="1.3"  wait="false"  y="30"  ]
[playse  volume="100"  time="0"  buf="5"  storage="k3.ogg"  loop="true"  ]
[playse  volume="100"  time="1000"  buf="4"  storage="k1.ogg"  ]
[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/27.png"  ]
[layermode  mode="overlay"  color="0xffffff"  time="0"  wait="false"  graphic="k.png"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[quake  time="300"  count="7"  hmax="5"  wait="false"  ]
[reset_camera  time="300"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=50]Gah![resetfont][wait time=600][p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
[delay speed=300]......[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
Holding that massive amount of mana in this tiny body[r]is pretty damn tough...[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/28.png"  ]
[tb_start_text mode=1 ]
#Devilun
That's right--we've come this far[r]I'm not about to stop here.[p]
[_tb_end_text]

[jump  storage="Chapter3.ks"  target="*end_complete_jump"  ]
