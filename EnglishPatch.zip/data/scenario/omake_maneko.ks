﻿[_tb_system_call storage=system/_omake_maneko.ks]

[flash  time="800"  effect="fadeIn"  color="0xFFFFFF"  ]

[playbgm  volume="50"  time="3000"  loop="true"  storage="natu.ogg"  fadein="true"  ]
[call  storage="me.ks"  target="*meopen_nobgm"  ]
[tb_start_text mode=1 ]
#Maneko
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="mane1.webp"  wait="false"  ]
[camera  time="10"  zoom="1.1"  wait="false"  layer="layer_camera"  ]
[wait  time="2000"  ]
[reset_camera  time="10000"  wait="false"  layer="layer_camera"  ease_type="ease"  ]
[flash_off  time="2000"  effect="fadeOut"  ]

[l  ]
[call  storage="me.ks"  target="*meclose_kioku2"  ]
[reset_camera  time="10"  wait="false"  ]
[bg  time="0"  method="crossfade"  storage="mane2.webp"  wait="false"  ]
[wait  time="500"  ]
[call  storage="me.ks"  target="*meopen_kioku2"  ]
[disable_menu_button]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Maneko
With my powers, blending into the Human Realm is a cinch.[p]

[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="mane3.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
Mew[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
This stubborn old man--just because I used to eat[r]tangerines in winter, he even buys them in summer.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
He took me in, saying my mere presence[r]would make his business boom...[r]But he's been just as broke ever since.[p]

[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="mane4.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
And yet[delay speed=100]...[resetdelay]why does he go out of his way[r]to buy something that looks this expensive?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
Maybe I eat it every time he serves it,[r]so he mistakes it for my favorite[delay speed=100]...[resetdelay][p]


[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="mane6.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
Well, it'd be a waste, so I might as well eat it.[p]


[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="mane5.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
Tangerines are so cheap and common, ugh.[r]What was that canned thing I used to eat[delay speed=100]...[resetdelay][r]what was it again?[p]

[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="mane6.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
That's it! Pineapple! I want pineapple, pineapple![r]Summer means pineapple, right?![p]

[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="mane7.webp"  wait="false"  ]
[playse  volume="100"  time="0"  buf="4"  storage="paku.ogg"  ]
[tb_start_text mode=1 ]
#Maneko
Chomp[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
[delay speed=500]...[resetdelay]Summer orange... yummy.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
[delay speed=100]...[resetdelay]Anyway...[p]
[_tb_end_text]

[bg  time="3000"  method="crossfade"  storage="shiro.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Maneko
Unlike the Demon Realm,[wait time=300]it's peaceful, huh?[wait time=2000][p]
[_tb_end_text]

[stopbgm  time="1000"  fadeout="true"  ]
[tb_hide_message_window  ]
[open_omake  category="gallery"  name="mane"  ]
[jump  storage="collection_omake.ks"  target="*resume_to_ng"  ]
