﻿;=========キャラクター事前定義情報 
;でびるん
[chara_new  name="でびるん"  jname="Devilun"  storage="chara/1/1.png"  ]
[fuki_chara  left="200"  top="270"  sippo="top"  sippo_left="30"  sippo_top="40"  sippo_width="12"  sippo_height="20"  select_fix_width="false"  max_width="300"  color="0xFFFFFF"  opacity="255"  border_size="3"  border_color="0x000000"  radius="15"  font_color="0x000000"  font_size="36"  name="でびるん"  ]
;プレイヤー
[chara_new  name="プレイヤー"  jname="プレイヤー"  storage="chara/2/0.png"  ]
;ペイン
[chara_new  name="ペイン"  jname="Payne"  storage="chara/8/0.png"  ]
;ティング
[chara_new  name="ティング"  jname="Ting"  storage="chara/9/0.png"  ]
;コマでび
[chara_new  name="コマでび"  jname="コマでび"  storage="chara/10/00.png"  ]
;感情オーラ1
[chara_new  name="感情オーラ1"  jname="感情オーラ1"  storage="chara/11/moya1-1.png"  ]
;感情オーラ2
[chara_new  name="感情オーラ2"  jname="感情オーラ2"  storage="chara/12/moya2-2.png"  ]
;感情オーラ3
[chara_new  name="感情オーラ3"  jname="感情オーラ3"  storage="chara/13/moya3-3.png"  ]
;クピャドエル
[chara_new  name="クピャドエル"  jname="Kupyadel"  storage="chara/14/1.png"  ]
;劇場でび
[chara_new  name="劇場でび"  jname="劇場でび"  storage="chara/15/dagya1.png"  ]
;劇場える
[chara_new  name="劇場える"  jname="劇場える"  storage="chara/16/hure1.png"  ]
;アレン
[chara_new  name="アレン"  jname="Allen"  storage="chara/17/0.png"  ]
;TAP
[chara_new  name="TAP"  jname="TAP"  storage="chara/18/17.png"  ]
;ベッド
[chara_new  name="ベッド"  jname="ベッド"  storage="chara/19/1.png"  ]
;マルス
[chara_new  name="マルス"  jname="Mars"  storage="chara/20/0.png"  ]
;コマえる
[chara_new  name="コマえる"  jname="コマえる"  storage="chara/21/10.png"  ]
;アリス
[chara_new  name="アリス"  jname="Alice"  storage="chara/22/0.png"  ]
;フウガ
[chara_new  name="フウガ"  jname="Fuuga"  storage="chara/23/0.png"  ]
;シルフィ
[chara_new  name="シルフィ"  jname="Sylphy"  storage="chara/24/1.png"  ]
;コハク
[chara_new  name="コハク"  jname="Kohaku"  storage="chara/25/0.png"  ]
;本
[chara_new  name="本"  jname="本"  storage="chara/26/1.png"  ]
;ジェクト
[chara_new  name="ジェクト"  jname="Ject"  storage="chara/27/0.png"  ]
;ポリゴン
[chara_new  name="ポリゴン"  jname="ポリゴン"  storage="chara/28/1.png"  ]
;コニー
[chara_new  name="コニー"  jname="Connie"  storage="chara/29/0.png"  ]
;サブでび
[chara_new  name="サブでび"  jname="サブでび"  storage="chara/30/1_sub.png"  ]
;ムゥムゥ
[chara_new  name="ムゥムゥ"  jname="MuuMuu"  storage="chara/31/0.png"  ]
;ガク
[chara_new  name="ガク"  jname="Gakuloid"  storage="chara/32/0.png"  ]
;エメロード
[chara_new  name="エメロード"  jname="Emeraude"  storage="chara/33/0.png"  ]
;パンプティ
[chara_new  name="パンプティ"  jname="Pampty"  storage="chara/34/0.png"  ]
;成体でびるん
[chara_new  name="成体でびるん"  jname="成体でびるん"  storage="chara/35/1.png"  ]
;成体クピャドエル
[chara_new  name="成体クピャドエル"  jname="成体クピャドエル"  storage="chara/36/1.png"  ]
;ネゼル
[chara_new  name="ネゼル"  jname="Nesseru"  storage="chara/37/0.png"  ]
;サフィール
[chara_new  name="サフィール"  jname="Saphir"  storage="chara/38/0.png"  ]
;ミーティア
[chara_new  name="ミーティア"  jname="Meteor"  storage="chara/39/0.png"  ]
;チェシカ
[chara_new  name="チェシカ"  jname="Cheshika"  storage="chara/40/0.png"  ]
;ルナ
[chara_new  name="ルナ"  jname="Luna"  storage="chara/42/0.png"  ]
;アルマース
[chara_new  name="アルマース"  jname="Almaz"  storage="chara/43/0.png"  ]
;ルビー
[chara_new  name="ルビー"  jname="Ruby"  storage="chara/44/0.png"  ]
;ザコウモリA
[chara_new  name="ザコウモリA"  jname="Lousy Bat A"  storage="chara/45/1.png"  ]
;ザコウモリB
[chara_new  name="ザコウモリB"  jname="Lousy Bat B"  storage="chara/46/1.png"  ]
;ラピス
[chara_new  name="ラピス"  jname="Lapis"  storage="chara/47/0.png"  ]
;あもあも
[chara_new  name="あもあも"  jname="Amoamo"  storage="chara/48/0.png"  ]
;サブくぴゃ
[chara_new  name="サブくぴゃ"  jname="サブくぴゃ"  storage="chara/49/A1.png"  ]
;ネオでび
[chara_new  name="ネオでび"  jname="ネオでび"  storage="chara/50/1.png"  ]
;ネオでび邪眼
[chara_new  name="ネオでび邪眼"  jname="ネオでび邪眼"  storage="chara/51/1.png"  ]
;ラミア
[chara_new  name="ラミア"  jname="Lamia"  storage="chara/52/0.png"  ]
;ガウルォス
[chara_new  name="ガウルォス"  jname="Gawuros"  storage="chara/53/0.png"  ]
;ジュエリーピンク
[chara_new  name="ジュエリーピンク"  jname="Jewelry Pink"  storage="chara/54/0.png"  ]
;リリカ
[chara_new  name="リリカ"  jname="Ririka"  storage="chara/55/0.png"  ]
;ウエディングでびるん
[chara_new  name="ウエディングでびるん"  jname="ウエディングでびるん"  storage="chara/56/1.png"  ]
;ミンティ
[chara_new  name="ミンティ"  jname="Minty"  storage="chara/57/0.png"  ]
;ライ
[chara_new  name="ライ"  jname="Rai"  storage="chara/58/0.png"  ]
;ピーター
[chara_new  name="ピーター"  jname="Peter"  storage="chara/59/0.png"  ]
;ベルベル
[chara_new  name="ベルベル"  jname="Belbel"  storage="chara/60/1.png"  ]
;マキ
[chara_new  name="マキ"  jname="Maki"  storage="chara/61/0.png"  ]
;邪眼
[chara_new  name="邪眼"  jname="邪眼"  storage="chara/62/1.png"  ]
;ネオ
[chara_new  name="ネオ"  jname="Neo"  storage="chara/63/1.png"  ]
;BBB
[chara_new  name="BBB"  jname="BBB"  storage="chara/64/00_Devil.png"  ]
;寝る
[chara_new  name="寝る"  jname="寝る"  storage="chara/65/1.png"  ]
;ネゼル手
[chara_new  name="ネゼル手"  jname="ネゼル手"  storage="chara/66/hon1.png"  ]
;ミカエル
[chara_new  name="ミカエル"  jname="Michael"  storage="chara/67/1.png"  ]
;ミーティア星
[chara_new  name="ミーティア星"  jname="ミーティア星"  storage="chara/68/hoshi.png"  ]
;ニセドエル
[chara_new  name="ニセドエル"  jname="Nisedoeru"  storage="chara/69/1.png"  ]
;透過チェシカ
[chara_new  name="透過チェシカ"  jname="透過チェシカ"  storage="chara/70/c1.png"  ]
;でび縛り
[chara_new  name="でび縛り"  jname="でび縛り"  storage="chara/71/1.png"  ]
;ちび悪魔
[chara_new  name="ちび悪魔"  jname="ちび悪魔"  storage="chara/72/1.png"  ]
;ナザール
[chara_new  name="ナザール"  jname="Nazar"  storage="chara/73/00_Devil.png"  ]
;ベルレヴィ
[chara_new  name="ベルレヴィ"  jname="ベルレヴィ"  storage="chara/74/1.png"  ]
;召喚士
[chara_new  name="召喚士"  jname="召喚士"  storage="chara/75/1.png"  ]
;マネコ
[chara_new  name="マネコ"  jname="Maneko"  storage="chara/76/00_Devil.png"  ]
;D・Red
[chara_new  name="D・Red"  jname="D Red"  storage="chara/77/00_Devil.png"  ]
;ハーデスター
[chara_new  name="ハーデスター"  jname="Hadester"  storage="chara/78/00_Devil.png"  ]
;開発陣
[chara_new  name="開発陣"  jname="開発陣"  storage="chara/79/1.png"  ]

[chara_new  name="Devilun"  jname="Devilun"  storage="chara/1/1.png"  ]
[chara_new  name="Neo"  jname="Neo"  storage="chara/63/1.png"  ]
[chara_new  name="Gawuros"  jname="Gawuros"  storage="chara/53/0.png"  ]
[chara_new  name="Kupyadel"  jname="Kupyadel"  storage="chara/14/1.png"  ]
[chara_new  name="①Mars①"  jname="①Mars①"  storage="chara/20/0.png"  ]
[chara_new  name="Meteor"  jname="Meteor"  storage="chara/39/0.png"  ]
[chara_new  name="①Devilun①"  jname="①Devilun①"  storage="chara/1/1.png"  ]
[chara_new  name="D Red"  jname="D Red"  storage="chara/77/00_Devil.png"  ]
[chara_new  name="Amoamo"  jname="Amoamo"  storage="chara/48/0.png"  ]
[chara_new  name="Ririka"  jname="Ririka"  storage="chara/55/0.png"  ]
[chara_new  name="Nazar"  jname="Nazar"  storage="chara/73/00_Devil.png"  ]
[chara_new  name="Hadester"  jname="Hadester"  storage="chara/78/00_Devil.png"  ]
[chara_new  name="Maneko"  jname="Maneko"  storage="chara/76/00_Devil.png"  ]
[chara_new  name="Alice"  jname="Alice"  storage="chara/22/0.png"  ]
[chara_new  name="Emeraude"  jname="Emeraude"  storage="chara/33/0.png"  ]
[chara_new  name="Kohaku"  jname="Kohaku"  storage="chara/25/0.png"  ]
[chara_new  name="Lamia"  jname="Lamia"  storage="chara/52/0.png"  ]
[chara_new  name="②Devilun②"  jname="②Devilun②"  storage="chara/1/1.png"  ]
[chara_new  name="①Lamia①"  jname="①Lamia①"  storage="chara/52/0.png"  ]
[chara_new  name="Mars"  jname="Mars"  storage="chara/20/0.png"  ]
[chara_new  name="MuuMuu"  jname="MuuMuu"  storage="chara/31/0.png"  ]
[chara_new  name="Nesseru"  jname="Nesseru"  storage="chara/37/0.png"  ]
[chara_new  name="Pampty"  jname="Pampty"  storage="chara/34/0.png"  ]
[chara_new  name="Belbel"  jname="Belbel"  storage="chara/60/1.png"  ]
[chara_new  name="Peter"  jname="Peter"  storage="chara/59/0.png"  ]
[chara_new  name="Saphir"  jname="Saphir"  storage="chara/38/0.png"  ]
[chara_new  name="Ting"  jname="Ting"  storage="chara/9/0.png"  ]
[chara_new  name="Nisedoeru"  jname="Nisedoeru"  storage="chara/69/1.png"  ]
[chara_new  name="Lousy Bat A"  jname="Lousy Bat A"  storage="chara/45/1.png"  ]
[chara_new  name="Lousy Bat B"  jname="Lousy Bat B"  storage="chara/46/1.png"  ]
[chara_new  name="Payne"  jname="Payne"  storage="chara/8/0.png"  ]
[chara_new  name="Almaz"  jname="Almaz"  storage="chara/43/0.png"  ]
[chara_new  name="Allen"  jname="Allen"  storage="chara/17/0.png"  ]
[chara_new  name="Allen①"  jname="Allen①"  storage="chara/17/0.png"  ]
[chara_new  name="Cheshika"  jname="Cheshika"  storage="chara/40/0.png"  ]
[chara_new  name="Connie"  jname="Connie"  storage="chara/29/0.png"  ]
[chara_new  name="Fuuga"  jname="Fuuga"  storage="chara/23/0.png"  ]
[chara_new  name="Sylphy"  jname="Sylphy"  storage="chara/24/1.png"  ]
[chara_new  name="Gakuloid"  jname="Gakuloid"  storage="chara/32/0.png"  ]
[chara_new  name="Ject"  jname="Ject"  storage="chara/27/0.png"  ]
[chara_new  name="Jewelry Pink"  jname="Jewelry Pink"  storage="chara/54/0.png"  ]
[chara_new  name="Rai"  jname="Rai"  storage="chara/58/0.png"  ]
[chara_new  name="Rai②"  jname="Rai②"  storage="chara/58/0.png"  ]
[chara_new  name="Lapis"  jname="Lapis"  storage="chara/47/0.png"  ]
[chara_new  name="Maki"  jname="Maki"  storage="chara/61/0.png"  ]
[chara_new  name="Minty"  jname="Minty"  storage="chara/57/0.png"  ]
[chara_new  name="MuuMuu③"  jname="MuuMuu③"  storage="chara/31/0.png"  ]
[chara_new  name="Peter②"  jname="Peter②"  storage="chara/59/0.png"  ]
[chara_new  name="Ruby"  jname="Ruby"  storage="chara/44/0.png"  ]
[chara_new  name="Luna"  jname="Luna"  storage="chara/42/0.png"  ]
[chara_new  name="Michael"  jname="Michael"  storage="chara/67/1.png"  ]
[chara_new  name="Hide Non-Fixed Pose (Hide Summoner in Back)"  jname="Hide Non-Fixed Pose (Hide Summoner in Back)"  storage="chara/75/1.png"  ]
[chara_new  name="NEO Devilun"  jname="NEO Devilun"  storage="chara/1/1.png"  ]
[chara_new  name="Beelzebub"  jname="Beelzebub"  storage="chara/64/00_Devil.png"  ]
[chara_new  name="Time Stopper"  jname="Time Stopper"  storage="chara/74/1.png"  ]
[chara_new  name="Tamamo"  jname="Tamamo"  storage="chara/25/0.png"  ]
[chara_new  name="Lousy Bats"  jname="Lousy Bats"  storage="chara/45/1.png"  ]
;=========変数宣言部分 
[iscript] 
f['mp']=10; 
f['mp_max']=110; 
f['name']='Summoner'; 
f['point']=0; 
f['tips']=0; 
f['seibetu']=0; 
f['omake']=0; 
f['kansou1']=0; 
f['kansou2']=''; 
f['kansou3']=''; 
f['zyagan1_search']=0; 
f['zyagan2_search']=0; 
f['zyagan3_search']=0; 
f['shibou']=0; 
f['HANYOU']=0; 
f['tuno']=0; 
f['nemumi']=0; 
f['nemumiInterval']=180000; 
f['RANSUU']=0; 
f['zyagan_count']=0; 
f['day']=0; 
f['tutorial_finished']=0; 
f['ting']=0; 
f['Alice_nabe']=0; 
f['marusu_m']=0; 
f['ject_tasuke']=''; 
f['che_mata']=''; 
f['bel_name']=0; 
f['lapis']=0; 
f['lapis_clear']=0; 
f['lapis_END']=0; 
f['ruby']=0; 
f['cony']=0; 
f['kupya_1']=0; 
f['kupya_2']=0; 
f['kupya_3']=0; 
f['meteor']=0; 
f['marusu']=0; 
f['hue']=1; 
f['goal']=0; 
f['fue']=0; 
f['Lamia']=0; 
f['MAGAN']=0; 
f['player_me']=0; 
f['gauru']=0; 
f['fuga_sukumizu']=0; 
f['show_menu_ng']=0; 
f['script']=0; 
f['nezeru_clear']=0; 
f['sign']=0; 
f['jewelry']=0; 
f['currentLoop']=1; 
f['chieshika']=0; 
f['pain_tenshi']=0; 
f['runa_coin']=''; 
f['bel_name_first']=0; 
f['end_complete']=0; 
f['BBB_kidoku']=0; 
f['kupya_tap']=0; 
f['totalMP']=0; 
f['marusu_tenshi']=0; 
f['koukai_kidoku']=0; 
f['kupya_ninchi']=0; 
f['kupya_meteor']=0; 
f['wedding_kidoku']=0; 
f['blueberry']=0; 
f['photoPose']=1; 
f['photoDeviPose']=1; 
f['photoNonFixedPose']=1; 
f['ne']=0; 
f['kupya_inori']=0; 
f['past_name']=''; 
f['autoSave']=1; 
f['ne_kidoku']=0; 
f['kupya_owari']=0; 
f['subtitle']=''; 
f['END_ogg']=0; 
f['neodebi_TAP']=0; 
f['nise']=0; 
f['kupya_kyo']=0; 
f['bel_call']=0; 
f['debirun2']=0; 
f['kill_muumuu']=0; 
f['fuga_mp']=0; 
f['Lamia_kill']=0; 
f['comp30']=''; 
f['amoribon']=0; 
f['kupya_hata']=''; 
f['hutanari']=0; 
f['syo']=0; 
f['maki_cony']=0; 
f['zeroPoint']=0; 
f['mp0_jewelry']=''; 
f['day_epilogue']=0; 
f['kupya_syouziki']=0; 
f['neodebi_nade']=0; 
f['mp_100']=0; 
[endscript] 
