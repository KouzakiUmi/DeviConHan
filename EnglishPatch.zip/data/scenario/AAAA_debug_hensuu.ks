﻿[_tb_system_call storage=system/_AAAA_debug_hensuu.ks]

[tb_start_text mode=1 ]
Playthrough 0, Day 1[p]

[_tb_end_text]

[tb_eval  exp="f.day=1"  name="day"  cmd="="  op="t"  val="1"  ]
