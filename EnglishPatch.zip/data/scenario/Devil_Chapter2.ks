﻿[_tb_system_call storage=system/_Devil_Chapter2.ks]

[cm  ]
[tb_eval  exp="f.photoPose=0"  name="photoPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[playse  volume="100"  time="1000"  buf="5"  storage="night.ogg"  loop="true"  fadein="true"  ]
*x

[tb_start_text mode=1 ]
#Kupyadel
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w7.webp"  ]
[wait  time="1000"  ]
[free layer=4 name="kuro" time="3000"  ]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Kupyadel
You've worked hard today.[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w8.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
Cupya, um...[delay speed=100]...[resetdelay][r]This form is[delay speed=100]...[resetdelay]well...[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
When I thought of what Devi-kun said[delay speed=100]...[resetdelay][r]somehow, I wanted to stay this way[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=300]...[resetdelay]I only just warned Devi-kun about it,[r]and now I'm doing the same thing myself. I'm sorry.[p]

[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w9.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
What[delay speed=100]...[resetdelay]happened?[p]
[_tb_end_text]

[tb_hide_message_window  ]
[skipstop]

[tb_start_tyrano_code]
[preload  storage="./data/image/waku2.png"  ]
[glink name="waku_small" font_color="white" storage="" target="*kupya" face="craftmincho"  text="Kupyadel" x="464" y="690" width="352" height="79" size="24" graphic="ui/waku_small.png" enterimg="ui/waku_small_.png" enterse="tap.ogg" clickse="OK.ogg"]
[_tb_end_tyrano_code]

[s  ]
*kupya

[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[bg  time="0"  method="crossfade"  storage="w10.webp"  ]
[camera  time="10"  zoom="1.4"  wait="false"  layer="layer_camera"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="sasu.ogg"  ]
[reset_camera  time="500"  wait="false"  layer="layer_camera"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
C-c-could those be potato-chip crumbs!?[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
C-Cupya...[delay speed=100]...[resetdelay]I'm sorry for eating potato chips[r]in bed while half-asleep just now.[p]

[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
I'll be more careful from now on. This is so embarrassing.[r]I'll use the lint roller next time, okay?[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w11.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
It's been a full week since I made a contract with [emb exp="f.name"],[r]and life down here is so much fun.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
At last, I've found a happiness beyond compare[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w12.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
If only this happiness could last forever[delay speed=100]...[resetdelay][r]That would be so nice[delay speed=100]...[resetdelay]I really hope it does[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w13.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
Zzz[delay speed=100]...[resetdelay]zzz[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[chara_show  name="TAP"  time="500"  wait="false"  storage="chara/18/TAP.png"  width="400"  height="200"  left="673"  top="91"  reflect="false"  ]
[clickable  storage="Devil_Chapter2.ks"  x="213"  y="312"  width="1066"  height="338"  target="*tap1"  _clickable_img=""  ]
[clickable  storage="Devil_Chapter2.ks"  x="227"  y="112"  width="489"  height="198"  target="*tap1"  _clickable_img=""  ]
[clickable  storage="Devil_Chapter2.ks"  x="971"  y="651"  width="222"  height="225"  target="*tap1"  _clickable_img=""  ]
[s  ]
*tap1

[flash  time="50"  effect="fadeIn"  color="0x000000"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="mp.ogg"  ]
[chara_hide  name="TAP"  time="500"  wait="false"  pos_mode="false"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[bg  time="0"  method="crossfade"  storage="w14.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
When I'm in my small form, my eyes are closed,[r]so people often say they can't[r]tell whether I'm asleep or awake.[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w11.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
[delay speed=100]...[resetdelay]These big, bright eyes I have now[r]are my favorite.[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w12.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
Because Devi-kun[delay speed=100]...[resetdelay][r]likes me[delay speed=100]...[resetdelay]this way[delay speed=100]...[resetdelay]after all.[p]
[_tb_end_text]

[bg  time="0"  method="crossfade"  storage="w13.webp"  ]
[tb_start_text mode=1 ]
#Kupyadel
Zzz[delay speed=100]...[resetdelay]zzz[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[chara_show  name="TAP"  time="500"  wait="false"  storage="chara/18/TAP.png"  width="400"  height="200"  left="673"  top="91"  reflect="false"  ]
[clickable  storage="Devil_Chapter2.ks"  x="213"  y="312"  width="1066"  height="338"  target="*tap2"  _clickable_img=""  ]
[clickable  storage="Devil_Chapter2.ks"  x="227"  y="112"  width="489"  height="198"  target="*tap2"  _clickable_img=""  ]
[clickable  storage="Devil_Chapter2.ks"  x="971"  y="651"  width="222"  height="225"  target="*tap2"  _clickable_img=""  ]
[s  ]
*tap2

[flash  time="50"  effect="fadeIn"  color="0x000000"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="mp.ogg"  ]
[chara_hide  name="TAP"  time="500"  wait="false"  pos_mode="false"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
Heehee[delay speed=100]...[resetdelay]Good night [emb exp="f.name"],[p]
[_tb_end_text]

[stopse  time="1000"  buf="0"  ]
[layopt layer=4 visible="true"]

[image name="kuro" layer=4 folder="fgimage" storage="default/kuro.webp" time="4000"  wait="false"  ]

[stopse  time="4000"  buf="5"  fadeout="true"  ]
[tb_start_text mode=1 ]
#Kupyadel
I hope you have[delay speed=100]...[resetdelay][r]sweet dreams[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[tb_start_tyrano_code]
[position layer="message0" frame="Message4.png"  height="258"  ]
[_tb_end_tyrano_code]

[hide_photo_button]

[tb_start_text mode=1 ]
#Devilun
[_tb_end_text]

[wait  time="4000"  ]
[bg  time="300"  method="crossfade"  storage="yume1.webp"  wait="false"  ]
[wait  time="2000"  ]
[playbgm  volume="50"  time="3000"  loop="true"  storage="5_theater.ogg"  fadein="true"  ]
[free layer=4 name="kuro" time="2000"  ]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=34]Heeey, [emb exp="f.name"]![resetfont][p]
[_tb_end_text]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="osu.ogg"  ]
[bg  time="100"  method="crossfade"  storage="yume2.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=34]Dagya![resetfont][p]
[_tb_end_text]

[tb_hide_message_window  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="taoreru.ogg"  ]
[bg  time="50"  method="crossfade"  storage="yume8.webp"  wait="false"  ]
[wait  time="500"  ]
[l  ]
[bg  time="100"  method="crossfade"  storage="yume3.webp"  wait="false"  ]
[wait  time="1000"  ]
[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
[emb exp="f.name"]![p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="yume4.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
[emb exp="f.name"].[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="yume5.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#BBB
[emb exp="f.name"]![p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="yume6.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Amoamo
[emb exp="f.name"]~♥[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="yume7.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Nazar
...[p]
[_tb_end_text]

[bg  time="100"  method="crossfade"  storage="yume11.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
Hold it, you guys![r][emb exp="f.name"] is MY partner![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Amoamo
It's not nice to hog them all to yourself, Mmyu~[p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="yume9.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Amoamo
That's right! Fighting over them isn't good,[r]so let's split into pairs, Mmyu~[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[font size=34]C-Cupyaaa!?[resetfont][p]
[_tb_end_text]

[bg  time="300"  method="crossfade"  storage="yume10.webp"  wait="false"  ]
[tb_start_text mode=1 ]
#Devilun
Then I'll team up with Levi.[r]You don't want anyone but me, do you?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Nazar
...Shut up.[p]
[_tb_end_text]

[tb_hide_message_window  ]
[tb_start_tyrano_code]
[position layer="message0" frame="Message.png"  height="258"  ]
[_tb_end_tyrano_code]

[bg  time="100"  method="crossfade"  storage="yume12.webp"  wait="false"  ]
[wait  time="500"  ]
[l  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[stopbgm  time="0"  ]
[playse  volume="100"  time="0"  buf="1"  storage="tukamu.ogg"  ]
[bg  time="50"  method="crossfade"  storage="yume13.webp"  wait="false"  ]
[l  ]
[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[open_omake  category="gallery"  name="yume"  ]
[camera  time="1"  zoom="1.1"  wait="true"  layer="layer_camera"  ]
[bg  time="0"  method="crossfade"  storage="yume14.webp"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="kowai.ogg"  ]
[reset_camera  time="3000"  wait="false"  layer="layer_camera"  ]
[flash_off  time="1000"  effect="fadeOut"  ]

[wait  time="1000"  ]
[tb_eval  exp="f.day_epilogue=2"  name="day_epilogue"  cmd="="  op="t"  val="2"  val_2="undefined"  ]
[flash  time="0"  effect="fadeIn"  color="0x000000"  ]

[call  storage="me.ks"  target="*meclose_kioku2"  ]
[bg  time="0"  method="crossfade"  storage="w15.webp"  ]
[tb_filter_blur  layer="all"  blur="10"  ]
[wait  time="500"  ]
[flash_off  time="0"  effect="fadeOut"  ]

[playse  volume="100"  time="0"  buf="2"  storage="gauru3.ogg"  ]
[tb_free_filter  layer="undefined"  time="3000"  ]
[call  storage="me.ks"  target="*meopen_kioku2"  ]
[show_photo_button]

[playse  volume="100"  time="0"  buf="5"  storage="tori2.ogg"  ]
[wait  time="3000"  ]
[tb_start_text mode=1 ]
#Kupyadel
[_tb_end_text]

[fadein_window  time="300"  ]
[tb_start_text mode=1 ]
#Kupyadel
Good morning [emb exp="f.name"],[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
Judging by the look of you, maybe[delay speed=100]...[resetdelay][r][emb exp="f.name"] had a strange dream too[delay speed=100]...[resetdelay]?[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Kupyadel
[delay speed=300]...[resetdelay]We may not have gotten much rest, but let's[r]pull ourselves together and do our best today too.[p]
[_tb_end_text]

[tb_hide_message_window  ]
[stopse  time="1000"  buf="5"  fadeout="true"  ]
[flash  time="500"  effect="fadeIn"  color="0xFFFFFF"  ]

[playse  volume="100"  time="0"  buf="1"  storage="doa4.ogg"  ]
[bg  time="0"  method="crossfade"  storage="haikei2.webp"  ]
[chara_show  name="でびるん"  time="0"  wait="false"  storage="chara/1/46.png"  width="1280"  height="960"  left="2"  top="-151"  reflect="false"  ]
[chara_show  name="プレイヤー"  zindex="2"  layer="1"  time="0"  wait="false"  storage="chara/2/yubiwa.png"  width="1280"  height="960"  ]
[tb_start_tyrano_code]
[keyframe name="fuwa"]
[frame p="0%" y="0"]
[frame p="50%" y="-10"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="でびるん" keyframe="fuwa" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_eval  exp="f.photoPose=1"  name="photoPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_eval  exp="f.photoDeviPose=0"  name="photoDeviPose"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[wait  time="1000"  ]
[playbgm  volume="50"  time="1000"  loop="true"  storage="1_debirun_no_theme.ogg"  ]
[flash_off  time="1000"  effect="fadeOut"  ]

[wait  time="1000"  ]
[tb_start_text mode=1 ]
#Devilun
[_tb_end_text]

[fadein_window  time="1000"  ]
[tb_start_text mode=1 ]
#Devilun
Zzz~[delay speed=100]...[resetdelay][p]
[_tb_end_text]

[tb_hide_message_window  ]
[tb_start_tyrano_code]
[play_apng name="kupya_fuki_show" layer="2" x="7" y="308" width="384" height="400"]
[_tb_end_tyrano_code]

[wait  time="350"  ]
[chara_show  name="コマえる"  layer="0"  zindex="2"  time="0"  wait="false"  storage="chara/21/7.png"  width="383"  height="400"  left="7"  top="308"  ]
[tb_start_tyrano_code]
[free_apng name="kupya_fuki_show" ]
[_tb_end_tyrano_code]

[tb_start_tyrano_code]
[keyframe name="erukoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマえる" keyframe="erukoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=34]Devi-kuuun![resetfont][r]Looks like you had quite a night.[p]
[_tb_end_text]

[flash  time="50"  effect="fadeIn"  color="0x000000"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="sasu2.ogg"  ]
[chara_hide  name="でびるん"  time="0"  wait="false"  pos_mode="false"  ]
[chara_show  name="サブでび"  time="0"  wait="false"  storage="chara/30/koumori.png"  width="1280"  height="960"  ]
[flash_off  time="20"  effect="fadeOut"  ]

[tb_show_message_window  ]
[tb_start_text mode=1 ]
#Devilun
[font size=34]Dagya![resetfont][wait time=500][p]

[_tb_end_text]

[flash  time="50"  effect="fadeIn"  color="0x000000"  ]

[chara_hide  name="サブでび"  time="0"  wait="false"  pos_mode="false"  ]
[chara_show  name="でびるん"  time="0"  wait="false"  storage="chara/1/44.png"  width="1280"  height="960"  ]
[tb_start_tyrano_code]
[keyframe name="fuwa"]
[frame p="0%" y="0"]
[frame p="50%" y="-50"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="でびるん" keyframe="fuwa" count="infinite" time="2000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="20"  effect="fadeOut"  ]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="sasu.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=32]Don't just start talking to me out of nowhere![resetfont][r]Jeez, I was having such a nice dream.[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/8.png"  ]
[tb_start_text mode=1 ]
#Devilun
Huh? You guys look awfully tired[r]for this early in the morning.[p]
[_tb_end_text]

[playse  volume="100"  time="0"  buf="1"  storage="aseru.ogg"  ]
[chara_mod  name="コマえる"  time="0"  cross="false"  storage="chara/21/30.png"  ]
[tb_start_tyrano_code]
[keyframe name="erukoma"]
[frame p="0%" y="0"]
[frame p="50%" y="-5"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="コマえる" keyframe="erukoma" count="infinite" time="1000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[tb_start_text mode=1 ]
#Kupyadel
D-Devi-kun wasn't around, so we had a little[r]fun of our own and didn't get enough sleep~[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/53.png"  ]
[tb_start_text mode=1 ]
#Devilun
That's not fair![r]You had a party while I was gone!?[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/11.png"  ]
[tb_start_text mode=1 ]
#Devilun
Oh, right! Since everyone's short on sleep,[r]let's have one of those pajama parties today![p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Devilun
You wear pajamas, laze around, and chat...[r]Apparently it's an event made for sloths like us![p]
[_tb_end_text]

[chara_mod  name="コマえる"  time="0"  cross="false"  storage="chara/21/11.png"  ]
[tb_start_text mode=1 ]
#Kupyadel
[font size=32]Nooooo![resetfont][p]Today, as always, you'll be working hard[r]to reclaim the remaining demons' mana, okay?[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/31.png"  ]
[tb_start_text mode=1 ]
#Devilun
We're summoning more troublesome ones today too?[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/10.png"  ]
[tb_start_text mode=1 ]
#Devilun
But I'm only tied up, right?[r]No one would notice if I slept through it, right?[p]
[_tb_end_text]

[chara_mod  name="コマえる"  time="0"  cross="false"  storage="chara/21/12.png"  ]
[tb_start_tyrano_code]
[keyframe name="erukoma"]
[frame p="0%" y="-10"]
[frame p="50%" y="0"]
[frame p="100%" y="-1"]
[endkeyframe]
[kanim name="コマえる" keyframe="erukoma" count="infinite" time="400" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[tb_start_text mode=1 ]
#Kupyadel
If you fall asleep, I'll tighten[r]the bindings immediately and twist you apart.[p]
[_tb_end_text]

[chara_mod  name="でびるん"  time="0"  cross="false"  storage="chara/1/33.png"  ]
[quake  time="300"  count="5"  hmax="3"  wait="false"  ]
[playse  volume="100"  time="0"  buf="1"  storage="sasu2.ogg"  ]
[tb_start_text mode=1 ]
#Devilun
[font size=32]Twist me apart!?[r]Don't say such gruesome things, you moron-![resetfont][p]
[_tb_end_text]

[tb_eval  exp="f.photoDeviPose=1"  name="photoDeviPose"  cmd="="  op="t"  val="1"  val_2="undefined"  ]
[tb_hide_message_window  ]
[tb_hide_message_window  ]
[call  storage="maku.ks"  target="*close"  ]
[chara_hide  name="でびるん"  time="0"  wait="false"  pos_mode="false"  ]
[chara_hide  name="コマえる"  time="0"  wait="false"  pos_mode="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[free_layermode  time="1000"  wait="true"  ]
[jump  storage="syoukan_Devil.ks"  target=""  ]
