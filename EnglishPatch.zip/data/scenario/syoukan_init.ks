﻿[_tb_system_call storage=system/_syoukan_init.ks]

[stopbgm  time="3000"  fadeout="true"  cond="f.finished.length==0||f.finished.length%3!=0"  ]
*init
[clearstack stack="macro"]

[eval exp="globalThis.gc&&globalThis.gc()"]

[skipstop]

[reset_camera  time="10"  wait="false"  ]
[comment  c="あもあもは通常ルートでは解禁しない（ここは通常ルートでしか通らない）"  ]
[clearlog]

[eval exp="f.zeroPoint=0" cond="f.finished.length%3==0"]

[jump  storage="mp_hantei1.ks"  cond="f.day==0&&f.finished.length==3"  target=""  ]
[jump  storage="mp_hantei2.ks"  cond="f.day==1&&f.finished.length==6"  target=""  ]
[jump  storage="mp_hantei3.ks"  cond="f.day==2&&f.finished.length==9"  target=""  ]
[jump  storage="mp_hantei4.ks"  cond="f.day==3&&f.finished.length==12"  target=""  ]
[eval exp="f.forceMessage2=true"]

[chara_hide_all  time="0"  wait="false"  ]
[chara_hide  name="プレイヤー"  layer="1"  time="0"  wait="false"  pos_mode="false"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="2_jingle1.ogg"  cond="f.day==0"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="2_jingle2.ogg"  cond="f.day==1"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="2_jingle3.ogg"  cond="f.day==2"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="2_jingle4.ogg"  cond="f.day==3"  ]
[tb_eval  exp="f.kansou1=0"  name="kansou1"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.kansou2=0"  name="kansou2"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.kansou3=0"  name="kansou3"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.zyagan1_search=0"  name="zyagan1_search"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.zyagan2_search=0"  name="zyagan2_search"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.zyagan3_search=0"  name="zyagan3_search"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.HANYOU=0"  name="HANYOU"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.RANSUU=0"  name="RANSUU"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.fue=0"  name="fue"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[tb_eval  exp="f.goal=0"  name="goal"  cmd="="  op="t"  val="0"  val_2="undefined"  ]
[eval  exp="f.photoPose=1"]

[eval  exp="f.photoDeviPose=1"]

[eval  exp="f.photoNonFixedPose=1"]

[eval  exp="f.sawaru=0"]

[eval  exp="f.tuno=0"]

[eval  exp="f.mimi=0"]

[eval  exp="f.atama=0"]

[eval  exp="f.crown=0"]

[eval  exp="f.nemumiInterval=(f.finished.slice(-1)[0]=='ルビー'?30000:180000)"]

[loadjs storage="master_data.js"]

[iscript]
tf.tipsList = sf.kill == 0 ? [
//サモナールート0日目
  'The mark shows<br>their danger level.<br>I read their mana.',
  'Who to summon? ♪<br>Start with someone<br>weak~',
  'Gathering mana?<br>Timing and insight!<br>Miss it--0%!',
//サモナールート1日目
  "Done shopping?<br>Summon three, then<br>let's feast!",
  'Dangerous foe?<br>Save some mana<br>before you try.',
  'Evil Eye Scan<br>reads minds.<br>Focus--color shifts.',
//サモナールート2日目
  'All right--summon<br>about three today!<br>Restore true form!',
  'Evil Eye Scan<br>Low MP blocks it.<br>Watch out.',
  'I noticed something.<br>Dangerous ones<br>follow a pattern~',
//サモナールート3日目
  'Hah... hah... More...!<br>Connect with more<br>Steal their mana...!',
  "No slacking, okay?<br>A useless familiar<br>isn't worthy of me.",
'More...!<br>I need more mana.<br>Get to it. Now.',
] : [
//ファナティックルート0日目
  'Come, fanatic,<br>Gather mana, now!<br>Get to work!',
  "Gather less mana<br>than I expect--<br>you'll pay, got it?",
  'Not new to this...<br>You must be devout<br>to demons, huh?',
//ファナティックルート1日目
  'That flower...<br>Lily of the valley?<br>Creepy. Toss it.',
  'Keep connecting!<br>Drain every drop<br>of mana!',
  "A fanatic's familiar<br>is a fine thing.<br>Obey--body and soul♥",
//ファナティックルート2日目
  'That lily--<br>The horse got it.<br>Good. Stoke evil.',
  'The Root of Sloth<br>Mana piles up fast!<br>You have talent~',
  'More mana, better...<br>One after another!<br>Drain this world!',
//ファナティックルート3日目
  'Hah... hah...<br>More mana--seize it!<br>Mightiest god...!',
  f.kill_muumuu == 1 ? 'Next time--take it!<br>I have enough,<br>but it feels <span style="font-family:KaiseiDecol-Bold">wrong</span>!' : 'Enough mana...<br>More is better...<br>Next sacrifice?',
  f.kill_muumuu == 1 ? 'Another failure...?<br>Damn it--frustrating!<br>Nail it next time!' : 'Next time--take it!<br>It still feels <span style="font-family:KaiseiDecol-Bold">wrong</span>.<br>Damn it--frustrating...',
]
[endscript]

[iscript]
if (sf.kill) f.tutorial_finished = 1
// 今日のキャラクター（水晶に表示するもの）
f.currentCharacters = dc.characters().filter(c => c.day == f.day)
if (f.currentLoop == 1) {
// 1周目はリリカを水晶に表示しない
f.currentCharacters = f.currentCharacters.filter(c => c.name !== 'リリカ')
}
// 現時点で選べるキャラクター（全日）
// 2周目はペインを選択できない
f.choosable = f.currentLoop == 2 ? ['リリカ'] : ['ペイン', 'リリカ']
// ペインが終わったら選択可能にする
if (f.tutorial_finished) {
f.choosable = f.choosable.concat(dc.characters().filter(c => c.cond(f)).map(c => c.name))
}
if (f.chara) f.index = Math.max(f.currentCharacters.findIndex((c) => c.name == f.chara.name), 0);
else f.index = 0
[endscript]

[layopt layer="1" visible="true"]

[image name="suisyou_hatena" layer="1" folder="image" storage="hatena.png" x="165" y="397" width="430" height="530"]

[cm  ]
[call  storage="mp.ks"  target="*show"  ]
[call  storage="phase.ks"  target="*hide"  ]
[call  storage="phase.ks"  target="*show_bottom"  ]
[return  ]
