﻿[_tb_system_call storage=system/_gekizyou_END41.ks]

[cm  ]
[bg_loop name="gekizyo2"]

[chara_show  name="劇場でび"  time="0"  wait="false"  storage="chara/15/dagya53.png"  width="523"  height="551"  left="598"  top="164"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="DEBI"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="劇場でび" keyframe="DEBI" count="infinite" time="3300" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_show  name="ちび悪魔"  time="0"  wait="false"  storage="chara/72/14.png"  width="487"  height="475"  left="203"  top="221"  reflect="false"  ]
[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-10"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="3000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[flash_off  time="0"  effect="fadeOut"  ]

[stopse  time="300"  buf="1"  fadeout="true"  ]
[wait  time="500"  ]
[call  storage="maku.ks"  target="*open_gekizyou"  ]
[playbgm  volume="60"  time="0"  loop="true"  storage="5_theater.ogg"  ]
[fadein_window  time="1000"  ]
[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/15.png"  ]
[tb_start_text mode=1 ]
#Maneko
What kind of house is this?![r]I was sure it was some rich man's mansion...[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya54.png"  ]
[tb_start_text mode=1 ]
#Devilun
Yo, Mammon, this place ain't got anything[r]but scraps of paper. Go on, leave your mana[r]and get out, get out.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/16.png"  ]
[tb_start_text mode=1 ]
#Maneko
Belphegor...[r]The whole Demon Realm is buzzing about you.[p]
[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
You're a demon of sloth, so I[r]figured you'd have gone over to some rich[r]contractor and spent your days lazing around...[p]


[_tb_end_text]

[tb_start_text mode=1 ]
#Maneko
How can you be this poor?![r]I can't believe it![p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya41.png"  ]
[tb_start_text mode=1 ]
#Devilun
Mammon... money isn't[r]everything in this world, y'know?[p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/15.png"  ]
[tb_start_text mode=1 ]
#Maneko
Grrr! Don't get cocky![r]That's exactly what I least wanted to hear![p]
[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-10"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="3000" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/14.png"  ]
[tb_start_text mode=1 ]
#Maneko
...Y-you... I heard you recently awakened[r]an Evil God ability.[p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya40.png"  ]
[tb_start_text mode=1 ]
#Devilun
That's right! If I wanted to, I could grow[r]roots that drain all the mana around me.[p]
[_tb_end_text]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/16.png"  ]
[tb_start_text mode=1 ]
#Maneko
I-I can't believe a lesser demon like you[r]could have an ability like that![p]
[_tb_end_text]

[chara_mod  name="劇場でび"  time="0"  cross="false"  storage="chara/15/dagya29.png"  ]
[tb_start_text mode=1 ]
#Devilun
Oh-ho, jealous, huh?[r]Maybe you'll awaken a new power of your own[r]besides your impersonation act, lol.[p]

[_tb_end_text]

[tb_start_tyrano_code]
[keyframe name="akuma"]
[frame p="0%" y="0"]
[frame p="50%" y="-20"]
[frame p="100%" y="0"]
[endkeyframe]
[kanim name="ちび悪魔" keyframe="akuma" count="infinite" time="600" direction="alternate" easing="linear"]
[_tb_end_tyrano_code]

[chara_mod  name="ちび悪魔"  time="0"  cross="false"  storage="chara/72/15.png"  ]
[tb_start_text mode=1 ]
#Maneko
Nyaaah! I wanna steal every last[r]bit of your luck and skill![p]

[_tb_end_text]

[jump  storage="gekizyou_END_menu.ks"  target=""  ]
